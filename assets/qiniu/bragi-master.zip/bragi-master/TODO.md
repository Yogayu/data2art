
@TODO release
  1. isProduction = -> process.env.NODE_ENV === 'production'
  2. Compiler optimizations:
      optimisation.react.inlineElements
        {type: 'div', props: ...}
      optimisation.react.constantElements
        {}
@TODO test all `request({}).failure`

@DONE update to React@0.14
  1. - `React.initializeTouchEvents`
  2. - `this.getDOMNode(this)` -> `ReactDOM.findDOMNode(this)``
  3. 'stateless function components'
    bring most component to 'Stateless function components'
    Button = (props) -> {
      return <div class="hello world"></div>
    }
  5. PureRenderMixin, use `shallowCompare` instead of `shallowEqual`
    'react/lib/shallowCompare'
