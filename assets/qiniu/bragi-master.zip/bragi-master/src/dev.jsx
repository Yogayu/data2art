import "scss/app.scss"
import Perf from 'react-addons-perf'
window.Perf = Perf

window.ga = function () {}

import 'reduxify'

// register service worker
if('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service.js').then((registration) => {
    console.log('ServiceWorker registration successful with scope: ',    registration.scope)
  }).catch((err) => {
    console.log('ServiceWorker registration failed: ', err)
  })
}
