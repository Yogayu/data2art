import React from 'react'
import { storiesOf, action } from '@kadira/storybook'
import Dialog from '../components/dialog/simple'
import random from "lodash/random"

import Login from 'views/login'
import Confirm from 'views/login/confirm'

class RandomSize extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      width: 0
      , height: 0
    }
  }

  componentDidMount() {
    this.randomSize()
  }

  randomSize() {
    this.setState({
      width: random(10, 400)
      , height: random(10, 600)
      , backgroundColor: `rgb(${random(255)}, ${random(255)}, ${random(255)})`
    })
  }

  render() {
    return <Dialog>
      <div onClick={::this.randomSize} style={this.state}></div>
    </Dialog>
  }

}


storiesOf('Popup', module)
  .add('fix-size dialog', () => (
    <Dialog
      width={100}
      height={100}
    >
      Text
    </Dialog>
  ))

  .add('random size', () => {
    return <RandomSize></RandomSize>
  })

  .add('with login iframe', () => {
    return <Dialog>
      <Login
        height={392}
        src={'http://doubandev2.intra.douban.com:7878/popup/login?use_post_message=1#popup_login'}
      ></Login>
    </Dialog>
  })

  .add('confirm after login success', () => {
    return <Dialog
      innerStyle={{
        width: 478
        , height: 384
        , padding: '60px 39px 0 39px'
        , boxSizing: 'border-box'
      }}
    >
      <Confirm></Confirm>
    </Dialog>
  })
