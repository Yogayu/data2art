import React from 'react'
import { storiesOf, action } from '@kadira/storybook'

let story = storiesOf('Icon', module)

const icons = ['heart']

icons.map((i) => {
  let moduleName = 'icons/icon-' + i

  require([moduleName], (require) => {
    let component = require (moduleName)

    story.add('icon-' + i, () => {
      return React.createElement(component, {})
    })


  })
})
