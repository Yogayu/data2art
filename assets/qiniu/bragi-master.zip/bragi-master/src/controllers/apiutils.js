// utils for
import douradio from "douradio"
import Backbone from "backbone"


export function enableApiRouter(router) {
  router.route(
  'login/success?code=:code',
  'getAccessCode',
  function getAccessCode(code) {
    let redirectUrl = location.origin + '/#/login/success'
    douradio.getAccessCode(code, false, redirectUrl).then(() => {
      if(code) {
        Backbone.history.navigate('/', {trigger: true})
      } else if (douradio.isLogin()) {
        console.log('douradio start successfully!')
      } else {
        console.log('The authrization url is: ', douradio.oauthUrl())
      }
    }, (err) => {
      console.error('OAuth Error', err)
      this.navigate('/')
    })
  })
}
