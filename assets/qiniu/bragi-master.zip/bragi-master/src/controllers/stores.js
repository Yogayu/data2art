import douradio from "douradio"
import simpleStorage from "simplestorage"

const ONE_HOUR = 60 * 60 * 1000
// const ONE_DAY = 24 * ONE_HOUR
// const ONE_WEEK = 7 * ONE_DAY

export const KEY_SEARCH_HISTORY = 'bragi-search-history'

// old key by mispell
export const KEY_IS_SHOW_RELEASE_NOTE = 'bragi:userguide:displayed'
//
export const KEY_IS_SHOWED_USERGUIDE = 'bragi:userguide:is_showed_userguide'

export class SearchHistory {

  get() {
    return simpleStorage.get(KEY_SEARCH_HISTORY) || []
  }

  // clear all
  clear() {
    simpleStorage.set(KEY_SEARCH_HISTORY, [])
  }

  push(value) {
    value = value.trim()

    if(!value) {
      return
    }
    const maxLength = 5
    let originValue = this.get()

    if(originValue.indexOf(value) >= 0) {
      // value already exists
      return
    }

    if(originValue.length > maxLength) {
      originValue.pop()
    }
    originValue.unshift(value)
    return simpleStorage.set(KEY_SEARCH_HISTORY, originValue)
  }

}

const KEY_PLAYER_STATE = 'douradio-player-state'
const KEY_SETTINGS = 'douradio-settings'
export class PlayerState {
  // manager all local store

  constructor() {
    douradio.on('switch_song', this.savePlayerState)
    window.onunload = this.savePlayerState
  }

  onPlayerUnload() {
    // Keep only one player available
  }

  savePlayerState() {
    simpleStorage.set(
      KEY_PLAYER_STATE
      , douradio.getPlayerState()
      , {TTL: ONE_HOUR}
    )

    simpleStorage.set(KEY_SETTINGS, {
      bitrate: douradio.getKbps()
      , volume: douradio.getVolume()
    })

  }

  get() {
    return Object.assign(
      {},
      simpleStorage.get(KEY_PLAYER_STATE),
      simpleStorage.get(KEY_SETTINGS)
    )
  }

}

export default simpleStorage
// init player state
