import douradio from "douradio"

export let hasNotification = !!window.Notification

let notifyCloseHandler = null

function notifyMe(song) {
  // only active when document is inactive
  if(!document.hidden) {
    return
  }

  let notify = new Notification(song.get('title'), {
    icon: song.get('picture'),
    body: song.get('artist') + " - " + song.get('albumtitle'),
    tag: 'current-song'
  })

  if(notifyCloseHandler) {
    window.clearTimeout(notifyCloseHandler)
  }

  let notifyCloseHandler = window.setTimeout(() => {
    notify.close()
  }, 5000)
}

let _isEnabled = true;

var notir = {

  startNotification: function () {
    if(notir.isEnabled()) {
      douradio.on('switch_song', notifyMe)
    }
  },

  enable: function () {
    if(window.Notification.permission == 'granted') {
      _isEnabled = true
      notir.startNotification()
    } else {
      Notification.requestPermission((permission) => {
        notir.startNotification()
      })
    }
  },

  stop: function () {
    _isEnabled = false;
    douradio.off('switch_song', notifyMe);
  },

  isEnabled: function () {
    return _isEnabled &&
           hasNotification && window.Notification.permission == 'granted'
  }

}

export default notir;
