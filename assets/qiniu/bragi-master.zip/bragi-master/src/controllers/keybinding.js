import douradio from "douradio"
import { addEventListener } from 'utils/domutils'

const attachHandler = addEventListener

// export function attachHandler(target, event, handler) {
//   if(target.addEventListener) {
//     target.addEventListener(event, handler)
//   } else if(target.attachEvent){
//     target.attachEvent("on" + event, handler)
//   }
//   return handler
// }

// prevent space bar from scrolling page
attachHandler(window, 'keydown', (e) => {
  if(e.keyCode === 32 && e.target === document.body) {
    e.preventDefault()
    return false
  }
})

attachHandler(window, 'keyup', (event) => {
  if(event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) {
    return
  }

  let tagName = event.target.tagName.toLowerCase()
  if(tagName === 'textarea' || tagName === 'input') {
    return
  }

  if(event.keyCode === 32) { // 'space'
    event.preventDefault()
    event.stopPropagation()
    douradio.togglePause()
  } else if(event.keyCode === 70){ // 'f'
    douradio.toggleLike()
  } else if(
    event.keyCode === 83 ||
    event.keyCode === 39 ||
    event.keyCode === 76
  ) {  // 's', right, 'l'
    douradio.skip()
  } else if(event.keyCode === 72 || event.keyCode === 37){ // 'h', left
    douradio.prev()
  } else {
    // console.debug(event.keyCode)
  }
})
