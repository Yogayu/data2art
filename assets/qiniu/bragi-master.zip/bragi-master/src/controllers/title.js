import douradio from "douradio"

douradio.on('switch_song play pause resume', () => {
  let prefix = '豆瓣FM'

  if(!douradio.currentSong || !douradio.currentSong.get('sid')) {
    document.title = prefix
  } else {
    // document.title = (douradio.isPlaying() ? '' : '') +
    document.title = douradio.currentSong.get('title') + ' - ' + prefix
  }
})
