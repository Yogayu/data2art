/* global describe, before, it*/

import Audio from "douradio/audio"
import sinon from "sinon"
import Song from "douradio/song"
import assert from "assert"

/* currentSong `length`, `id`,
 * apiClient
 * getNextSong
 *
 * -----------------
 * trigger('event')
 * onFinish
 */

// in douaudio, these douradio method will be called
describe('Audio', function () {
  let audio
  , douradio
  , requestSpy = sinon.spy()
  , getNextSongSpy = sinon.spy()
  , onFinishSpy = sinon.spy()
  , triggerSpy = sinon.spy()

  before(function before() {
    let song = new Song({sid: '123456'})
    douradio = {
      currentSong: sinon.spy(song, 'get')
      , trigger: triggerSpy
      , _onFinish: onFinishSpy
      , apiClient: {
        request: requestSpy
      }
      , getNextSong: getNextSongSpy
    }
    audio = new Audio({}, douradio)
  })

  it('should call `getNextSong` after three error', function (done) {
    // disable timeout for this test
    this.timeout(0)

    let defer = Promise.defer()
    douradio.getNextSong = sinon.stub()
    douradio.getNextSong.returns(defer.promise)
    audio.play('http://wrongmp3')

    window.setTimeout(function () {
      assert(douradio.getNextSong.called)
      done()
    }, 10000)
  })

})


describe('PlayRecords', function () {
  let playRecord = new PlayRecord()

  it('should able to fetch init dataset', function (done) {
    playRecord.fetch().then(() => {
      // @todo fake response
      assert(playRecord.length > 0)
    })
  })



})
