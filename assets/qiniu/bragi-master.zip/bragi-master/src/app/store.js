import { createStore, combineReducers, applyMiddleware, compose } from 'redux'
import thunk from "redux-thunk"
import reducers from './reducers/index'
import {
  syncHistoryWithStore
  , routerReducer
  , routerMiddleware
} from 'react-router-redux'

import { browserHistory, hashHistory } from 'react-router'

let fallbackHistory = !!window.history.pushState ? browserHistory : hashHistory

const enhancer = compose(
  applyMiddleware(thunk)
  , applyMiddleware(routerMiddleware(fallbackHistory))
  , window.devToolsExtension ? window.devToolsExtension() : f => f
)

const store = createStore(
  combineReducers({...reducers, routing: routerReducer})
  , enhancer
)

export const history = syncHistoryWithStore(fallbackHistory, store)

// listen to router change and dispatch actions
import { setAp } from './actions/player'
history.listen((location) => {
  if(location.pathname === '/') {
    store.dispatch(setAp(0))
  } else {
    store.dispatch(setAp(1))
  }
})

export default store
