# Redux App

Reduxify `rewrite` of the bragi app

Due to the complexity of currently app, here we store our app state in two place:

1. douradio, ApiClient + AuidoPlayer + PlayerLogic

2. app state
  all other state comes here, but mainly ui related state, for example:
  popup showed, routing, has user click a button?

3. views' internal state

## Data flow

### two data flow(currently)
Currently, app(UI) will read state directly from two states.

```
douradio -> (action -> reducer) -> store -> view -> douradio
```

### single direction data flow (in the future)
```
douradio -> (action -> reducer) -> store -> view

```
