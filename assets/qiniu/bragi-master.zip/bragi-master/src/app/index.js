import "scss/app.scss"

import React from 'react'
import Backbone from "backbone"
import _isEmpty from "lodash/isEmpty"
import _get from 'lodash/get'
import douradio from "douradio"
// import renderApp from 'reduxify'

import simpleStorage, {
  SearchHistory, PlayerState
  , KEY_IS_SHOW_RELEASE_NOTE
  , KEY_IS_SHOWED_USERGUIDE
} from "controllers/stores"
import ControllerKeyBinding from "controllers/keybinding" // eslint-disable-line
import ControllerTitle from "controllers/title" // eslint-disable-line
import defer from "promise-defer"
import ga from "utils/analytics" // eslint-disable-line
import initErrorReporter from "utils/reporterror"

/*
import SystemNotification from "controllers/notification"
SystemNotification.startNotification()
*/

// Redux Related
import store, { history } from './store'
import { push } from 'react-router-redux'


// bind douradio and redux-store
import setupDouradio from './setup-douradio'

// setup router view
import setupRouterView from './router'

// Action Creators
import {
  displaySnack
} from './actions/snacks'
import * as actions from './actions'
import {DLG_CTX_MENU} from './actions'

/*
class AppRouter extends Backbone.Router {
  get routes() {
    return {
      '': 'index'

      , 'channel/:channel_id': 'channel'
      , 'songlist/:songlist_id': 'songlist'

      // explore page
      , 'explore': 'channels'
      , 'explore/channels': 'channels'
      , 'explore/songlists': 'songlists'

      , 'search': 'search'
      , 'search/': 'search'
      , 'search/:query': 'search'

      // popup
      , 'song/:id': 'song'
      , 'artist/:id': 'artist'
      // 'album/:id': 'album'
      , 'mine/banned': 'banned'
      , 'mine/played': 'played'

      // mine section
      , 'mine': 'mine'
      , 'mine/:section': 'mine'
    }
  }

  parseQueryString(search) {
    if(!search) {
      return search
    }
    return _object(search.split('&').map((pair) => pair.split('=')))
  }

  execute(callback, args) {
    // auto parse query strings
    args.push(this.parseQueryString(args.pop()))
    if(callback) {
      callback.apply(this, args)
    }
  }

  mine(subpage) {
    app.root.scrollTo(app.root.getGapHeight())
    app.root.closePopup()
    // this.hideOverlay('default')
  }

  songlist(songlistId) {
    // please check popup-manager
  }

  channel(channelId, search={}) {
    let {start, context} = search || {}
    douradio.switchChannel(channelId, {start, context}).then(() => {
      this.navigate('/')
    })
  }

}
*/

export default class BragiApplication {
  // main interface of the application
  constructor(options) {
    this.options = options
    this.searchHistory = new SearchHistory()
    this.playerState = new PlayerState()

    this.store = store

    this.root = {
      displayOverlay: (...args) => store.dispatch(actions.displayOverlay.apply(null, args))
      , hideOverlay: (...args) => store.dispatch(actions.hideOverlay.apply(null, args))
      , fullPlayerHeight: function () { return window.innerHeight - 100 }
      , scrollTo: (y) => { window.scrollTo(0, y) }
    }
  }

  // this is release notes
  displayReleaseNotes() {
    let defered = defer(Promise)

    require(['views/guide'], (GuidePage) => {
      this.root.displayOverlay(
        <GuidePage onClose={() => {
          this.root.hideOverlay('guide')
          simpleStorage.set(KEY_IS_SHOW_RELEASE_NOTE, true)
          defered.resolve()
          // onClose && onClose()
        }}></GuidePage>
        , 'guide'
      )
    })

    return defered.promise
  }

  // user feedback dialog
  displayFeedback(feedback=true) {
    require(['views/guide/feedback'], (Feedback) => {
      this.root.displayOverlay(
        <Feedback feedback={feedback} onClose={() => {
          this.root.hideOverlay('feedback')
        }}></Feedback>, 'feedback'
      )
    })
  }

  initReduxApp(props={}) {
    this.store = store

    // bind douradio to store
    setupDouradio(this.store)
    return setupRouterView(this.store, history)
  }

  start() {
    // Backbone.history.start({pushState: this.options.pushState})
    initErrorReporter();
    douradio.getCurrentUser().then((userinfo) => {
      // 是否能开启私人兆赫
      let hasPersonalChannel = douradio.hasPersonalService()
      // 判断是不是在首页
      // , isRoot = Backbone.history.atRoot()
      , isRoot = location.pathname.replace(/[^\/]/, '$&/') === '/'
      // 之前是不是有选过艺术家
      , hasPreviousChoosedArtists = !!simpleStorage.get(KEY_IS_SHOWED_USERGUIDE)
      // 之前的新版说明的key, 是否要展示新版说明
      , showNewVersionGuide = !_get(window, ['bootstrap', 'is_fm_new_user']) && !simpleStorage.get(KEY_IS_SHOW_RELEASE_NOTE)
      // 是否开启新用户引导
      , showUserGuide = true

      if(!isRoot) {
        // 不是首页，忽略一切guide
        showUserGuide = false
        showNewVersionGuide = false
      } else if (!hasPersonalChannel){
        // 没有私人兆赫权限
        if(hasPreviousChoosedArtists) {
          // 之前进行过新用户引导
          showUserGuide = false
        }
      } else {
        // 老用户
        showUserGuide = false
      }

      if(!showUserGuide && showNewVersionGuide) {
        // 展示新版介绍
        this.initReduxApp({newVersionGuide: false})

        return this.displayReleaseNotes().then(() => {
          this.initDouradio()
        })
      }

      // render main interface
      this.initReduxApp()

      if(showUserGuide) {
        store.dispatch(push('/user-guide'))
      } else {
        this.initDouradio()
      }
    }, () => {
      // get user failed
      this.initReduxApp()
      this.initDouradio()
    })

  }

  clearCache() {
    return simpleStorage.flush()
  }

  // init douradio and play the current song
  initDouradio(router) {
    if(this.douradio) {
      console.warn('!!!app.js!!! call initDouradio more than once!')
      return
    }

    if(douradio._playlist) {
      return
    }

    // init douradio and start play
    let playerState = this.playerState.get()

    // playerState = null

    if(playerState && ! _isEmpty(playerState)) {
      douradio.restorePlayerState(playerState || {})
    } else {
      douradio.switchChannel(
        douradio.hasPersonalService() ? 0 : -10
        , true
      )
    }
  }

  navigate = (fragment) => {
    console.log('fragment', fragment)
    if(fragment.indexOf('/') !== 0) {
      fragment = '/' + fragment
    }

    return this.store.dispatch(actions.navigate(fragment))
  }

  displayContextMenu = (m) => {
    this.store.dispatch(actions.displayOverlay(m, DLG_CTX_MENU))
  }

  hideContextMenu = () => {
    this.store.dispatch(actions.hideOverlay(DLG_CTX_MENU))
  }

  /**
   *  there are mainly three different share mode
   *  ShareSong from `SpecialChannel/Playlist`
   */
  share = (model=null, playlist=null) => {
    return this.store.dispatch(actions.share(model, playlist))
  }

  /**
   * push song to mobile phone(only song is supported currently)
   */
  push2Device = (model, e) => {
    if(!model) { return }
    return this.store.dispatch(actions.push2Device(model, e))
  }

  add2songlist = (song, e) => {
    return this.store.dispatch(actions.add2songlist(song, e))
  }

  showLogin = (register=false) => {
    require(['views/login/dialog'], (LoginDialog) => {
      this.root.displayOverlay(
        <LoginDialog register={register}></LoginDialog>
        , 'login'
      )
    })
  }

}
