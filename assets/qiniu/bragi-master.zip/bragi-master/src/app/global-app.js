// Dropped
// this is a compatible layer for the old bragi app
import { bindActionCreators } from 'redux'
import {DLG_CTX_MENU} from './actions'
import * as actions from './actions'

export default function setupGlobalApp (store) {
  const boundedActions = bindActionCreators(actions, store.dispatch)

  function nof () {
    console.warn('@todo', arguments)
  }

  // fake global view actions
  global.app = {
    displayUserGuide: nof
    , displayFeedback: nof

    , showLogin: nof

    , searchHistory: {
      get: nof
    }

    , push2Device: boundedActions.push2Device
    , add2songlist: boundedActions.add2songlist

    , share: boundedActions.share

    , displayContextMenu: function (m) { boundedActions.displayOverlay(m, DLG_CTX_MENU) }

    , root: {
      displayOverlay: boundedActions.displayOverlay
      , hideOverlay: boundedActions.hideOverlay

      , fullPlayerHeight: function () { return 1000 }
    }
    , navigate: boundedActions.navigate
  }

}
