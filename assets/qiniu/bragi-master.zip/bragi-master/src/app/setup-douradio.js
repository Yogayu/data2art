// Connect Douradio with Redux
import douradio from 'douradio'
import {
  SWITCH_PLAYLIST
  , SWITCH_SONG
  , CHANGE_PLAYER_STATUS
  , PLAYER_STATUS_LOADING
} from './actions/douradio'

import { NO_PERMISSION_TO_SWITCH_PLAYLIST } from 'douradio/consts'

import {
  displaySnack
} from './actions/snacks'

import { fetchPlayerAd } from './actions/player'

import { push } from 'react-router-redux'

export default function setupDouradio(store) {
  // bind douradio event 2 redux actions
  // douradio.on('switch_song')

  // proxy douradio events to redux events
  douradio.on(SWITCH_SONG, function () {
    store.dispatch({
      type: SWITCH_SONG
      , song: douradio.currentSong
    })
    fetchPlayerAd(douradio.currentSong.get('sid'))(store.dispatch)
  })

  douradio.on('switch_channel switch_songlist', function () {
    let pl = douradio._playlist

    pl.fetch().then(() => {
      store.dispatch({
        type: SWITCH_PLAYLIST
        , playlist: pl
      })
    })

  })

  douradio.on('play pause resume', function () {
    store.dispatch({
      type: CHANGE_PLAYER_STATUS
      , paused: !douradio.isPlaying()
    })
  })

  douradio.on('error', function (e) {
    // notification level error
    store.dispatch(displaySnack(e))
  })

  douradio.on(NO_PERMISSION_TO_SWITCH_PLAYLIST, function (e) {
    store.dispatch(push('/user-guide'))
  })
}
