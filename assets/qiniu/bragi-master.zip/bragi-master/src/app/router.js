import 'babel-polyfill'
import React from 'react'
import douradio from 'douradio'

import { render } from 'react-dom'
import { Router, Route, IndexRoute, Redirect } from 'react-router'

import {Provider} from 'react-redux'
import Container from './containers'

// import store, { history } from './store'
// import { goBack, } from 'react-router-redux'

// explorers pages
import ExploreChannels from './containers/explore/channels'

import ExploreSonglists from "views/explore/songlists"

import MineContainer from './containers/mine'

// import { ExploreChannels } from "views/explore/channels"
import PopupWrapper from "./containers/popups"

export default function setupRouterView(store, history) {
  render((
    <Provider store={store} key="provider">
      <Router history={history}>
        <Route
          path="/user-guide"
          getComponent={function (nextState, cb) {
            require(['./containers/userguide'], (UG) => {
              cb(null, UG)
            })
          }}
        ></Route>

        <Route path="/" component={Container}>
          <IndexRoute component={ ExploreChannels }></IndexRoute>

          <Route path="/explore">
            <IndexRoute
              component={ ExploreChannels }
            ></IndexRoute>
            <Route
              path="songlists"
              component={ ExploreSonglists }
            ></Route>
          </Route>

          <Route
            path="mine"
            component={MineContainer}
          >
            <IndexRoute
              getComponent={(nextState, cb) => {
                require(['views/mine/hearts'], (Component) => { cb(null, Component) })
              }}
            ></IndexRoute>

            <Route
              path="hearts"
              getComponent={(nextState, cb) => {
                require(['views/mine/hearts'], (Component) => { cb(null, Component) })
              }}
            ></Route>

            <Route
              path="favartists"
              getComponent={(nextState, cb) => {
                require(['views/mine/favartists'], (Component) => { cb(null, Component) })
              }}></Route>

            <Route
              path="collection"
              getComponent={(nextState, cb) => {
                require(['views/mine/collection'], (Component) => { cb(null, Component) })
              }}></Route>

            <Route
              path="creation"
              getComponent={(nextState, cb) => {
                require(['./containers/mine/creation'], (Component) => {
                  cb(null, Component)
                })
              }}></Route>

            <Redirect
              from="played"
              to="/history/played"></Redirect>

            <Redirect
              from="banned"
              to="/history/banned"></Redirect>
          </Route>

          <Route
            path="search"
            getComponent={(nextState, cb) => {
              require(['views/search'], (Component) => { cb(null, Component) })
            }}></Route>

          <Route component={PopupWrapper}>
            <Route
              path="history/played"
              getComponent={(nextState, cb) => {
                require(['views/playrecord'], ({PlayRecords}) => {
                  cb(null, PlayRecords)
                })
              }}
            ></Route>

            <Route
              path="history/banned"
              getComponent={(nextState, cb) => {
                require(['views/playrecord'], ({BannedSongs}) => {
                  cb(null, BannedSongs)
                })
              }}
            ></Route>

            <Route
              getComponent={(nextState, cb) => {
                require(['./containers/popups/songlist'], (Songlist) => {
                  cb(null, Songlist)
                })
              }}
              onEnter={(route, replace) => {
                if(route.params.id === 'redheart') {
                  return replace('/mine/hearts')
                }
              }}
              path="/songlist/:id"
            ></Route>

            <Route
              getComponent={(nextState, cb) => {
                require(['./containers/popups/artist'], (Artist) => {
                  cb(null, Artist)
                })
              }}
              path="/artist/:id"
            ></Route>

            <Route
              getComponent={(nextState, cb) => {
                require(['./containers/popups/song'], (Song) => {
                  cb(null, Song)
                })
              }}
              path="/song/:id"
            ></Route>
          </Route>

          <Route
            path={"channel/:id"}
            onEnter={(route, replace) => {
              let channelId = route.params.id
              douradio.switchChannel(channelId, route.location.query)
              replace('/')
            }}
          ></Route>

          <Route
            path="*"
            component={ ExploreChannels }
          ></Route>
        </Route>
      </Router>
    </Provider>
  ), document.getElementById('app'))
}
