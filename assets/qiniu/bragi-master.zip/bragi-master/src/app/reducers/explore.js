// explore channels
import { combineReducers } from 'redux'
import { Map, List } from 'immutable'

import {
  RESPONSE_RESOURCE
  , REQUEST_RESOURCE

  // all channels
  , RESOURCE_CHANNELS

} from '../actions/explore'

function channels(state, action) {
  if(!state) {
    const el = Map({
      isFetching: false
      , channels: List()
    })

    return Map({
      'artist': el
      , 'brand': el
      , 'genre': el
      , 'language': el
      , 'scenario': el
      , 'track': el
    })
  }

  if(action.resource !== RESOURCE_CHANNELS) {
    return state
  }

  if(action.type === REQUEST_RESOURCE) {
    return state.map((v, k) => {
      return v.set('isFetching', true)
    })
  } else if(action.type === RESPONSE_RESOURCE) {
    let respChannels = action.channels
    return state.map((v, k) => {
      if(respChannels[k]) {
        return Map({
          isFetching: false
          , channels: respChannels[k]
        })
      }
      return v
    })
  }

  return state
}


export default combineReducers({
  'channels': channels
})
