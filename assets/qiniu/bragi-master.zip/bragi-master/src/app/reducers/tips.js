import { combineReducers } from 'redux'

import {
  SHOW_TOOLTIP_GUIDE
  , DIAPLAY_NEXT_TOOLTIP_GUIDE
} from "../actions/tips"

import { SET_PLAYER_AP } from '../actions/player'

// so available steps range is: [0, 1, 2]
const MAX_STEPS = 2
// 滚动屏幕试试那一步
const LAST_STEP = 2

function tooltipGuide(state, action) {
  // set the default state
  if(!state) {
    state = {step: 0, display: false}
  }

  if(action.type === SHOW_TOOLTIP_GUIDE) {
    return {
      step: 0
      , display: true
    }
  }

  if(action.type === DIAPLAY_NEXT_TOOLTIP_GUIDE) {
    const ns = state.step + 1

    if(ns > MAX_STEPS) {
      // mark as finish user guide
      return {
        step: 0
        , display: false
      }
    }

    return {
      step: state.step + 1
      , display: true
    }
  }

  // detect page scroll for last step
  if(
    action.type === SET_PLAYER_AP && state.step === LAST_STEP
    && action.ap === 1
  ) {
    return {
      step: 0
      , display: false
    }
  }

  return state
}

export default combineReducers({
  tooltipGuide
})
