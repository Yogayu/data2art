import {
  WINDOW_SCROLL
  , WINDOW_RESIZE
} from '../actions'

export default function win (state, action) {
  if(!state) {
    return {
      width: window.innerWidth
      , height: window.innerHeight
    }
  }

  if(action.type === WINDOW_RESIZE) {
    return {
      width: action.width
      , height: action.height
    }
  }

  return state
}
