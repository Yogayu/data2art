// notify level
import {
  DISPLAY_SNACK
  , HIDE_SNACK
} from '../actions/snacks'


export default function snacks(state = null, action) {
  // if(action.type === RESOLVE_ERROR) {}
  // {type: NOTIFY_LEVEL}

  if(action.type === DISPLAY_SNACK) {
    return {
      message: action.message
    }
  } else if(action.type === HIDE_SNACK) {
    return null
  }

  return state
}
