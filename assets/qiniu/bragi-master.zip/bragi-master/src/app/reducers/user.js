// User related
import { combineReducers } from 'redux'

import {
  REQUEST_CREATED_SONGLISTS
  , RESPONSE_CREATED_SONGLISTS
} from '../actions/user'


function userinfo(state, action) {
  return {
    isLoading: true
  }
}

function createdSonglists(state, action) {
  if(!state) {
    return {
      isFetching: false
      , error: false
      , total: 0
      , songlists: []
    }
  }

  if(action.type === REQUEST_CREATED_SONGLISTS) {
    return Object.assign({}, state, {
      isFetching: true
    })
  } else if(action.type === RESPONSE_CREATED_SONGLISTS) {
    let {total, songlists} = action.payload

    return {
      isFetching: false
      , error: false
      , total
      , songlists
    }
  }

  return state
}


export default combineReducers({
  userinfo
  , createdSonglists
})
