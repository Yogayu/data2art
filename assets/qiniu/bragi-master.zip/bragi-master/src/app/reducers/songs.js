// it's keep all song information in one place

export default function () {
  return {}
}
