/* global describe, expect, it */
import playerReducer from '../player'

describe('recently playlists', () => {

  it('should able to init state', () => {
    let playerState = playerReducer({}, {})
    expect(playerState.recentPlaylists).toBeTruthy()
  })

})
