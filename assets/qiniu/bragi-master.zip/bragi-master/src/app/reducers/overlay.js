// overlay is global dialog/popup/contextmenu and else
import {Map} from 'immutable'
import {
  DISPLAY_OVERLAY, HIDE_OVERLAY, CLICK_OUTSIDE
  , DLG_PUSH_TO_DEVICES, DLG_SHARE, DLG_ADD_TO_SONGLIST, DLG_CTX_MENU
  , DLG_MINI_SONGLIST
} from '../actions'

import { SET_PLAYER_AP } from '../actions/player'

export default function overlay (state, action) {
  if(!state) {
    return Map({})
  }

  if(action.type === DISPLAY_OVERLAY) {
    return state.set(action.name, action.component)
  } else if(action.type === HIDE_OVERLAY) {
    return state.delete(action.name)
  } else if(
    action.type === CLICK_OUTSIDE || action.type === SET_PLAYER_AP
  ) {
    return state.delete(DLG_PUSH_TO_DEVICES)
      .delete(DLG_ADD_TO_SONGLIST)
      .delete(DLG_SHARE)
      .delete(DLG_CTX_MENU)
      .delete(DLG_MINI_SONGLIST)
  }

  return state
}
