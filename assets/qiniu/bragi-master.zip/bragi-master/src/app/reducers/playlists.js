import Immutable from 'immutable'

// a playlist should be a songlist or
//
// import {
//   ADD_PLAYLIST
//   , PLAYLIST_COLLECT
//   , PLAYLIST_TOGGLE_COLLECT
// } from '../actions/playlists'
//
import {
  RESPONSE_RECENT_PLAYSOURCE
} from '../actions/player'

import {
  SWITCH_PLAYLIST
} from '../actions/douradio'

export const DEFAULT_PLS = [
  {type: 'channel', id: 0, title: '我的私人'} // smaller
  , {type: 'songlist', id: 'redheart', title: '我的红心歌曲'} // middler
  , {type: 'songlist', id: 'user_daily', title: '每日私人歌单'} // current
  , {type: 'channel', id: -10, title: '豆瓣精选'} // fadeout
]

export function getPlKey(pl) {
  return `${pl.type}|${pl.id}`
}

export default function (state, action) {
  // update Map with keys
  if(!state) {
    return Immutable.Map(DEFAULT_PLS.map(pl => [getPlKey(pl), pl]))
  }

  if(action.type === RESPONSE_RECENT_PLAYSOURCE) {
    return state.merge(Immutable.Map(
      action.records.map(pl => [getPlKey(pl), pl])
    ))
  }

  if (action.type === SWITCH_PLAYLIST) {
    let pl = action.playlist

    let item = {
      type: pl.type
      , id: pl.id
      , title: pl.getTitle()
      , avatar: pl.getCover()
    }

    return state.set(getPlKey(item), item)
  }

  return state
}
