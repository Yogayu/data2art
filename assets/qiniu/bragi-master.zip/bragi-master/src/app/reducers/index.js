// import { combineReducers } from 'redux'
import player from './player'
import overlay from './overlay'

import explore from './explore'

import user from './user'
import songs from './songs'

import win from './win'
import snacks from './snacks'

import tips from './tips'
import playlists from './playlists'

export default {
  inited: function () { return true }
  , win
  , player
  , overlay

  // data
  , playlists

  // explore page
  , explore

  // user related
  , user
  , songs

  // global notify
  , snacks

  // global tooltips
  , tips
}
