import { combineReducers } from 'redux'

import {
  SET_PLAYER_AP

  , SET_PLAYER_AH

  , TOGGLE_LYRIC
  , TOGGLE_PLAYER_SONGLIST
  , TOGGLE_PL_CHOOSER

  , RESPONSE_RECENT_COLLECT
  , RESPONSE_RECENT_PLAYSOURCE

  , SET_PLAYER_TEXT_AD
} from '../actions/player'

import {
  CLICK_OUTSIDE
} from '../actions'

import {
  SWITCH_SONG
  , SWITCH_PLAYLIST

  , CHANGE_PLAYER_STATUS
  // , PLAYER_STATUS_LOADING
} from '../actions/douradio'

import Immutable from 'immutable'

function ap(oldAp = 0, action) {
  switch (action.type) {

  case SET_PLAYER_AP:
    return action.ap
    break

  default:
    return oldAp
  }
}

function isFixed (state = false, action) {
  if(action.type === 'fixed') {
  }
  return state
}

function leftArea(state, action) {
  if(!state) {
    return {
      showLyric: false
      , showPlayerSonglist: false
    }
  }

  let {showLyric, showPlayerSonglist} = state

  if(action.type === TOGGLE_PLAYER_SONGLIST) {
    // Close lyric if there is no lyrics inside
    if(showLyric) {
      showLyric = false
      showPlayerSonglist = true
    } else {
      showPlayerSonglist = !showPlayerSonglist
    }
  } else if(action.type === TOGGLE_LYRIC) {
    showLyric = !showLyric
  }

  return { showLyric, showPlayerSonglist }
}




function currentSong(state = null, action) {
  if(action.type == SWITCH_SONG) {
    return action.song
  }

  return state
}

function currentPlaylist (state = null, action) {
  if(action.type === SWITCH_PLAYLIST) {
    return action.playlist
  }

  return state
}

function showPlChooser(state = false, action) {

  if(
    action.type === CLICK_OUTSIDE ||
    action.type === SET_PLAYER_AP
  ) {
    return false
  }

  if(action.type === TOGGLE_PL_CHOOSER) {
    return !state
  }

  return state
}

function paused(state=false, action) {
  if(action.type === CHANGE_PLAYER_STATUS) {
    return action.paused
  }
  return state
}

function dailySonglistCover(state = "", action) {
  if(action.type === RESPONSE_RECENT_PLAYSOURCE) {
    return action.user_daily_avatar
  }

  return state
}

import { getPlKey, DEFAULT_PLS } from './playlists'
let DEFAULT_PL_KEYS = DEFAULT_PLS.map(getPlKey)

function recentPlaylists(state, action) {
  if(!state) {
    state = Immutable.OrderedSet(DEFAULT_PL_KEYS)
  }

  if(action.type === RESPONSE_RECENT_PLAYSOURCE) {
    return Immutable.OrderedSet([state.first()])
      .concat(Immutable.OrderedSet(action.records.map(getPlKey)))
      .concat(state)
      .slice(0, 4)
      .concat(DEFAULT_PL_KEYS)
  }

  // list recent played channels
  if (action.type === SWITCH_PLAYLIST) {
    let pl = action.playlist
    return Immutable.OrderedSet([getPlKey(pl)]).union(state).slice(0, 4).union(DEFAULT_PL_KEYS)
  }

  return state
}

function recentCollected(state, action) {
  if(action.type === RESPONSE_RECENT_COLLECT) {
    return {
      error: action.error
      , errorMsg: null
      , playlists: action.playlists
    }
  }

  if(!state) {
    return {
      error: false
      , errorMsg: null
      , playlists: []
    }
  }

  return state
}

// AD height
function ah (state = 0, action) {
  if(action.type === SET_PLAYER_AH) {
    return action.ah
  }

  return state
}


function textAd(state = null, action) {
  if (action.type === SET_PLAYER_TEXT_AD && action.textAd) {
    return action.textAd
  }

  return state
}

const playerReducer = combineReducers({
  ap

  , ah
  , isFixed

  // , showLyric
  // , showPlayerSonglist
  , leftArea
  , showPlChooser

  // playlists
  , recentPlaylists
  , dailySonglistCover

  , recentCollected

  // player states
  , paused
  , currentSong
  , currentPlaylist

  //
  , textAd
})

export default playerReducer
