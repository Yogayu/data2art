import { SectionSwitcherHeader } from 'ui/section-switcher'
import React from 'react'
import findIndex from "lodash/findLastIndex"
import cls from 'classnames'

class ExploreNav extends React.Component {

  static defaultProps = {
    className: 'section-switcher'
  }

  onSwitchSection(section) {
    this.props.navigate(section.url)
  }

  render() {
    let routing = this.props.routing
    , pathname = routing && routing.locationBeforeTransitions && routing.locationBeforeTransitions.pathname
    , sections = this.props.sections
    , currIndex = null

    if(pathname) {
      currIndex = findIndex(sections, function (section) {
        return pathname.indexOf(section.url) == 0
      })
    }

    return <div className={cls('section-switcher', this.props.className)}>
      <SectionSwitcherHeader
        sections={sections}
        currIndex={currIndex}
        onSwitchSection={this.onSwitchSection.bind(this)}
        lineStyle={null}
      >{this.props.children}</SectionSwitcherHeader>
    </div>
  }

}

import { connect } from 'react-redux'
import { navigate } from '../actions'
import { bindActionCreators } from "redux"

export default connect((state) => {
  return {
    routing: state.routing
  }
}, (dispatch) => {
  // dispatch2props
  return bindActionCreators({
    navigate
  }, dispatch)
})(ExploreNav)
