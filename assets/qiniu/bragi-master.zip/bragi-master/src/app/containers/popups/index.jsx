// Switch Manager
import React from "react"
import Popup from 'ui/popup'
import Icon from "ui/icon"
// import IconClose from 'icons/icon-close'

class PopupWrapper extends React.Component {
  // Location Before OpenPopup

  componentDidMount() {
    this.navCount = 1
    // console.log('PW:', 'didMount')
  }

  componentDidUpdate() {
    this.navCount += 1
  }

  componentWillUnmount() {
    // console.log('PW:', 'willUnmount')
  }

  onPrev() {
    this.navCount -= 2
    this.props.history.goBack()
  }

  onClose() {
    // @TODO history.length may not work
    if(this.props.history.length && this.props.history.length > 1) {
      this.props.history.go(this.navCount * -1)
    } else {
      this.props.history.push('/')
    }
  }

  render () {
    // console.info('render popup', this.props.children.type)
    let hasPrev = this.navCount >= 1

    return <Popup
      onClose={null}
      hidden={false}
      height={this.props.height}
    >
      <div className="popup-wrapper container">
        {this.props.children}
      </div>
      {hasPrev ? <a
          href="#"
        onClick={this.onPrev.bind(this)}
        className={'link-prev'}>&lt; 返回</a> : null}
      <a href="#"
        className={'link-close'}
        onClick={this.onClose.bind(this)}
      ><Icon i={'close'}></Icon></a>
  </Popup>
  }
}

import { connect } from 'react-redux'
import { bindActionCreators } from "redux"

export default connect((state) => {
  return {
    height: state.win.height - 100
  }
}, (dispatch) => {
  return bindActionCreators({}, dispatch)
})(PopupWrapper )
