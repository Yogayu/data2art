import React from 'react'
import ArtistPage from 'views/artist'

export default function RoutedArtist ({routeParams}) {
  let arid = routeParams.id

  return React.createElement(ArtistPage, {
    key: 'artist-' + arid
    , aid: arid
    , onClose: function (e) { console.log('onClose') }
  })
}
