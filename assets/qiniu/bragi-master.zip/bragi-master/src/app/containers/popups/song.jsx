import React from 'react'
import SongPage from 'views/song'


export default class PopupSong extends React.Component {

  render () {
    let routeParams = this.props.routeParams

    console.info('render - PopupSong')
    let sid = routeParams.id
    return React.createElement(SongPage, {
      key: 'song-' + sid
      , sid: sid
      , onClose: function (e) { console.log('onClose') }
    })
  }
}
