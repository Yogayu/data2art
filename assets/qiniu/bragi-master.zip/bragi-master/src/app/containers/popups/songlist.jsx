// songlist wrapper
import Songlist from 'views/songlist'
import React from 'react'
import douradio from 'douradio'

export default function RoutedSonglist ({history, routeParams}) {
  let slid = routeParams.id

  // console.log('Render Songlist:', slid)

  return React.createElement(Songlist, {
    key: 'songlist-' + slid
    , songlist: douradio.getSonglist(slid)
    , onClose: function (e) {
        console.log('onClose')
      }
    , onError : (e) => {
        douradio.trigger('error', '歌单不存在')
        history.goBack()
      }
  })
}
