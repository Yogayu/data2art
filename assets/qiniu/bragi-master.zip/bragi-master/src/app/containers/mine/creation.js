import { connect } from 'react-redux'
import { bindActionCreators } from "redux"
import * as actions from '../../actions/user'

import CreationPage from 'views/mine/creation'

export default connect((state) => {
  return {
    createdSonglists: state.user.createdSonglists
  }
}, (dispatch) => {
  return bindActionCreators(actions, dispatch)
})(CreationPage)
