import React from 'react'
// create key-value based view
import createFragment from "react-addons-create-fragment"
import { connect } from 'react-redux'

function Overlays(props) {
  // console.log('overlays', props.overlays)
  if(!props.overlays) {
    return null
  }

  let overlays = props.overlays.map(function (el, key) {
    let {
      type, props
    } = el
    return React.createElement(type, props)
  }).toObject()

  return <div className="overlays">
    {createFragment(overlays || {})}
  </div>
}

export default connect(function mapStateToProps(state) {
  return {
    overlays: state.overlay.size > 0 ? state.overlay : null
  }
}, function mapDispatchToProps() {
  return {}
})(Overlays)
