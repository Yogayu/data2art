import FMPlayer from 'views/player'

import { connect } from 'react-redux'
import * as playerActions from '../actions/player'
import * as globalActions from '../actions'

import { bindActionCreators } from "redux"

export default connect((state) => {
  const steps = 2

  let ap = state.player.ap
  , targetAp = Math.round(ap * steps) / steps
  // , targetAp = Math.round(ap)
  // console.log(targetAp)

  return Object.assign({}, state.player, { win: state.win , ap: targetAp})
}, (dispatch) => {
  // action2props
  return bindActionCreators(
    Object.assign({}, playerActions, globalActions)
  , dispatch)
})(FMPlayer)
