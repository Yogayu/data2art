import { ExploreChannels } from "views/explore/channels"
// import ExploreSonglists from "views/explore/songlists"

import { connect } from 'react-redux'
// import { navigate } from '../actions'
import { bindActionCreators } from "redux"
import * as exploreActions from '../../actions/explore'

export default connect((state) => {
  return {
    channels: state.explore.channels
  }
}, (dispatch) => {
  return bindActionCreators(exploreActions, dispatch)
})(ExploreChannels)
