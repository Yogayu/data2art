import React from 'react'
import douradio from 'douradio'
import NoLoginTips from 'views/login/tips/PlayingTips'
import TooltipGuide from 'views/tooltip-guide/Component'

// Copy from 'playing/tips'
class Tips extends React.Component {
  static defaultProps = {}

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    return <div className="tips" style={{
      position: 'absolute'
      , top: '50%'
      , marginTop: 180
      , left: '50%'
      , marginLeft: -220
    }}>
      {this.props.children}
    </div>
  }
}

class NextTips extends React.Component {
  // dep douradio

  onCancel() {
    douradio.unplayNext()
    return this.forceUpdate()
  }

  render() {
    let np = douradio.getNextPlaylist()

    if(!np) {
      return null
    }

    return <div style={{
      display: 'block'
      , height: 28
      , borderRadius: 2
      , backgroundColor: '#e7e7e7'
      , fontSize: 13
      , color: '#4a4a4a'
      , height: 36
      , lineHeight: '36px'
      , padding: '0 10px'
      // , marginTop: 50
      , marginBottom: 32
    }}>
      下一首将播放相似歌曲 &nbsp;&nbsp; <span style={{
        color: '#2f9842'
        , cursor: 'pointer'
      }} onClick={this.onCancel.bind(this)}>撤销</span>
    </div>
  }

}

function TipsWrapper(props) {
  const isLogin = douradio.isLogin()
  const { tooltipGuide } = props

  return <div>
    <Tips>
      {tooltipGuide.display ? <div style={{height: 30}}></div> : null}
      <NextTips></NextTips>
      {!isLogin ? <NoLoginTips
        redHeartCount={douradio.userinfo('liked_num')}
      ></NoLoginTips> : null}
    </Tips>
    {tooltipGuide.display ?
      <TooltipGuide
        step={tooltipGuide.step}
        onNextStep={props.onNextStep}
      ></TooltipGuide> : null}
  </div>
}

import { connect } from 'react-redux'
import { bindActionCreators } from "redux"
import { nextStep } from '../actions/tips'

export default connect((state) => {
  return {tooltipGuide: state.tips.tooltipGuide}
}, (dispatch) => {
  return bindActionCreators({onNextStep: nextStep}, dispatch)
})(TipsWrapper)
