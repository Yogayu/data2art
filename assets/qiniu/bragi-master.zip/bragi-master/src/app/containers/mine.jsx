// Class Mine
import React from 'react'
import Nav from './nav'

export default class MineContainer extends React.Component {
  render () {
    return <div className="mine-page">
      <Nav className="section-switcher-mine"
      sections={
        [
          {
            title: '我的红心'
            , url: '/mine'
            , name: 'hearts'
          }, {
            title: '我的收藏'
            , url: '/mine/collection'
            , name: 'collection'
          }, {
            title: '我制作的歌单'
            , url: '/mine/creation'
            , name: 'created'
          }, {
            title: '我喜欢的艺术家'
            , url: '/mine/favartists'
            , name: 'favartists'
          }
        ]
      }></Nav>
      <div
        className="section-content"
        style={{paddingTop: 30}}>
        {this.props.children}
      </div>
    </div>
  }
}
