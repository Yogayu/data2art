import React from 'react'
import { Motion, spring } from 'react-motion'

import Overlays from './overlays'
import PlayerView from './player'

import { windowScrollY, getDeltaFromEvent, transform } from 'utils/domutils'

import Header from './header'
import Footer from 'views/common/footer'
import TogglePlayer from 'views/playing/TogglePlayer'

import ExploreNav from './nav'
import IconSonglist from 'icons/icon-songlist'
import IconRadio from 'icons/icon-radio'
import IconHeartEmpty from 'icons/icon-heart-empty'
import IconSearch from 'icons/icon-search'

import Snackbar from 'components/snackbar'
import DoubanAD from "components/douban-ad"
import douradio from 'douradio'
import PlayerTips from './tips'

import isNumber from "lodash/isNumber"
import debounce from 'lodash/debounce'

import { supportTransform } from 'utils/feature-detect'
const SUPPORT_TRANSFORM = supportTransform

import { fromTo } from 'utils/motion'


const isIE = navigator.userAgent.indexOf('Trident') > 0

class Container extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      // offset related to scrollY
      offsetY: 0
    }
  }

  componentDidMount() {
    window.addEventListener('scroll', this.onScroll)
    window.addEventListener('resize', this.onWindowResize)

  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll)
    window.removeEventListener('resize', this.onWindowResize)
  }

  togglePlayer() {}

  onClickExplorer() {}

  onWheel(e) {
    let deltaY = getDeltaFromEvent(e)
    , ap = this.props.player.ap
    , sy = windowScrollY()

    if(
      (ap === 1 && deltaY > 0) || (ap === 0 && deltaY < 0) || sy > 0
    ) {
      return
    }

    e.preventDefault()

    this.onDrag(deltaY)

    // trigger when/wheel/event stopped
    if(this.onWheelHandler) {
      window.clearTimeout(this.onWheelHandler)
      this.onWheelHandler = null
    }
    this.onWheelHandler = window.setTimeout(
      this.onDragStopped.bind(this), 300
    )
  }

  onDrag(deltaY) {
    if(!isNumber(this._startAp)) {
      this.onDragStart()
    }

    const wh = this.props.win.height
    , ap = this.props.player.ap
    , mh = 100
    , ph = wh - mh
    let targetAp = (ph * ap + deltaY) / ph
    this.props.setAp(targetAp)
  }

  onDragStart() {
    // set direction, etc...
    this._startAp = this.props.player.ap
  }

  onDragStopped() {
    let startAp = this._startAp || 0
    , apDiff = this.props.player.ap - startAp

    if(apDiff > 0.2) {
      this.props.setAp(1)
    } else if(apDiff < -0.2) {
      this.props.setAp(0)
    } else {
      this.props.setAp(startAp)
    }

    this._startAp = null
  }

  onScroll = (e) => {
    if(isIE) {
      return
    }

    this.onScrollDebounced()
    // window.scrollTo(0, 0)
  }

  onScrollDebounced = debounce(() => {
    let wsy = windowScrollY()
    this.onDrag(window.scrollY)

    if(this.props.player.ap === 1) {
      return
    }

    if(wsy > 50) {
      this.props.setAp(1)
    } else {
      this.props.setAp(0)
    }

    window.scrollTo(0, 0)
  }, 200)

  onWindowResize = () => {
    this.props.resize(window.innerWidth, window.innerHeight)
  }

  onClickBody(e) {
    e.preventDefault()
    // if(this.props.overlay.size > 0) {}
    this.props.clickOutside()
  }

  onClick(url) {
    console.log('jump', url)
    window.open(url, '_blank')
  }

  render () {
    let ap = this.props.player.ap
    , wh = this.props.win.height
    , hasAd = !douradio.isPro()
    // , mh = hasAd ? 200 : 100
    , mh = 100 // miniplayer height
    , nh = 100 // nav height
    , ah = hasAd ? this.props.player.ah : 0 // ad height

    // full player height
    , fph = wh - nh - ah

    return <div
      className="app"
      onClick={this.onClickBody.bind(this)}
      onWheel={this.onWheel.bind(this)}
      onScroll={this.onScroll.bind(this)}
    >
      <Header style={{
        position: 'fixed'
        , top: 0
        , zIndex: 2000
      }}>
        <Motion
          style={{
            y: spring(
              fromTo(
                0, -1 * (fph - mh)
                , ap
                , this.state.offsetY
              )
            )
            , height: spring(fph)
          }}
        >{(motionStyle) => {
          return <div
            className="player-wrapper"
            style={Object.assign({
              position: 'fixed'
              , top: 0
              , left: 0
              , zIndex: 0
              , height: motionStyle.height
              , width: '100%'
            }, SUPPORT_TRANSFORM ? transform(0, motionStyle.y) : { top: motionStyle.y })}
          >
            <PlayerView mh={mh + ah}></PlayerView>
            {ap < 0.1 ?
              <PlayerTips></PlayerTips>
              : null}
          </div>
        }}</Motion>

        <Motion
          style={{
            top: spring(
              fromTo(
                wh - mh - ah - 66
                , 39
                , ap
                , this.state.offsetY
              )
            )
          }}
        >{({top}) => {
          return <TogglePlayer
            togglePlayer={this.props.togglePlayer}
            animationProgress={ap}
            isMiniPlayer={ap > 0.7}
            top={top}
          ></TogglePlayer>
        }}</Motion>
      </Header>

      <Motion
        style={{
          y: spring(
            fromTo(
              fph - nh, 0,
              ap, this.state.offsetY)
          )
          , ap: spring(ap)
        }}
      >{(motionStyle) => {
        let y = mh + motionStyle.y

        return <div className="explore"
          style={Object.assign({ marginTop: 0 }, SUPPORT_TRANSFORM ? transform(0, y) : { marginTop: y })}
        >
          <ExploreNav
            className="section-switcher-explore"
            sections={
              [{
                title: "兆赫"
                , icon: IconRadio
                , url: '/explore/channels'
                , name: 'channels'
              }, {
                title: "歌单"
                , icon: IconSonglist
                , url: '/explore/songlists'
                , name: 'songlists'
              }, {
                title: "我的FM"
                , icon: IconHeartEmpty
                , url: '/mine'
                , name: 'mine'
              }, {
                title: "搜索"
                , icon: IconSearch
                , url: '/search'
                , name: 'search'
              }]
            }
          ></ExploreNav>

          {hasAd && ap < 1 ? <DoubanAD
            onUpdate={(width, height) => {
              // this.setState({fullplayerOffsetY: -1 * (height + 22) / 2})
              this.props.setAh(height)
            }}
            unit="dale_fm_channel_new"
            style={Object.assign({
              position: 'relative'
              , height: 100
              , left: 0
              , right: 0
              , zIndex: 0
              , opacity: 1 - ap
              , bottom: 0
            }, SUPPORT_TRANSFORM ? transform(0, ap * -200) : {
              bottom: ap * -200
            })}
          >
          <p style={{textAlign: 'center'}}>
            <a
              onClick={this.onClick.bind(this, '//douban.fm/upgrade')}
              style={{
                fontSize: 12
                , fontWeight: 'normal'
                , textAlign: 'center'
                , color: '#977e42'
              }}
              href="//douban.fm/upgrade"
              target="_blank"
            >一键购买豆瓣FM PRO，高音质无广告 ➝</a>
          </p>
          </DoubanAD> : null}

          {this.props.children}

          <Footer></Footer>
        </div>
      }}</Motion>

      <Overlays></Overlays>

      {this.props.snacks ? <Snackbar>{this.props.snacks.message}</Snackbar>: null}
    </div>
  }
}

import { connect } from 'react-redux'
import { clickOutside, resize, scroll} from '../actions'
import { togglePlayer, setAp, setAh } from '../actions/player'
import { bindActionCreators } from "redux"

export default connect((state) => {
  return state
}, (dispatch) => {
  // dispatch2props
  return bindActionCreators({
    clickOutside, resize, scroll, togglePlayer, setAp, setAh
  }, dispatch)
})(Container)
