// wrapper for userguide
import initUserguide from 'userguide'
import React from 'react'
import douradio from 'douradio'

function UserGuideWrapper(props) {

  if(douradio.isPlaying()) {
    douradio.togglePause()
  }

  return initUserguide(Object.assign({}, {
    onFinish: () => {
      // console.info('ON_FINISH: userguide')
      props.history.replace('/')
      props.showTooltipGuide()
    }
  }))
}

import { connect } from 'react-redux'
import { bindActionCreators } from "redux"
import { showTooltipGuide } from '../actions/tips'

export default connect(
  function (state) {
    return {}
  }
  , (dispatch) => bindActionCreators({ showTooltipGuide }, dispatch)
)(UserGuideWrapper)
