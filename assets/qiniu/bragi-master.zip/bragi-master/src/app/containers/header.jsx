import { connect } from 'react-redux'
import { bindActionCreators } from "redux"

import Header from 'views/playing/header'
import douradio from 'douradio'

// <Header
//   style={{
//     position: 'absolute'
//     , top: motionStyle.top
//   }}
//   ap={ap}
//   renderTips={this.renderTips.bind(this)}
//   isLogin={douradio.isLogin()}
//   onLogin={this.onLogin.bind(this)}
//   username={userinfo.name}
//   avatar={userinfo.icon}
//   playedNum={userinfo.played_num}
//   isPro={douradio.isPro()}
// ></Header>

// const nof = () =>  { return { type: 'NOT_IMPLEMENT_ERROR'} }
// const nof = () =>  { return { type: 'NOT_IMPLEMENT_ERROR'} }

let rt = function () {
  return null
}

export default connect((state) => {
  return {
    isLogin: douradio.isLogin()
    // , isMiniPlayer: state.player.ap == 1
    , ap: state.player.ap < 1 ? 0 : 1
    , renderTips: rt
    , username: douradio.userinfo('name')
    , avatar: douradio.userinfo('icon')
    , playedNum: douradio.userinfo('played_num')
    , isPro: douradio.isPro()
  }
}, (dispatch) => {
  // dispatch2props
  return {
    onLogin: function () { window.app.showLogin() }
  }
  // return bindActionCreators({
  //   onLogin: window.app.showLogin()
  // }, dispatch)
})(Header)
