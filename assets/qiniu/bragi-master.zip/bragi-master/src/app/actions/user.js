// Reqeust Resource
export const REQUEST_CREATED_SONGLISTS = "REQUEST_CREATED_SONGLISTS"
export const RESPONSE_CREATED_SONGLISTS = "RESPONSE_CREATED_SONGLISTS"

import { createAsyncDispatcher } from './utils'
import douradio from 'douradio'

export function requestCreatedSonglists () {
  return createAsyncDispatcher(
    REQUEST_CREATED_SONGLISTS
    , RESPONSE_CREATED_SONGLISTS
    , () => {
      return douradio.apiClient.request({
        url: 'songlist/mine'
      })
    }
  )
}
