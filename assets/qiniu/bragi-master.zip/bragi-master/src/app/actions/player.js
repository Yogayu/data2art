// everything action about player(UI)
export const SET_PLAYER_AP = "SET_PLAYER_AP"

export const SET_PLAYER_AH = "SET_PLAYER_AH"

export const USE_FIXED_PLAYER = 'USE_FIXED_PLAYER'
export const TOGGLE_LYRIC = "TOGGLE_LYRIC"
export const TOGGLE_PL_CHOOSER = "TOGGLE_PL_CHOOSER"
export const TOGGLE_PLAYER_SONGLIST = "TOGGLE_PLAYER_SONGLIST"
export const RESPONSE_RECENT_COLLECT = "RESPONSE_RECENT_COLLECT"

export const REQUEST_RECENT_PLAYSOURCE = "REQUEST_RECENT_PLAYSOURCE"
export const RESPONSE_RECENT_PLAYSOURCE = "RESPONSE_RECENT_PLAYSOURCE"

export const SWITCH_SONG = "SWITCH_SONG "

export const SET_PLAYER_TEXT_AD = "SET_PLAYER_TEXT_AD"

import request from 'utils/request'
import { displayOverlay, DLG_MINI_SONGLIST } from './index'

// export function switchSong() {}

export function togglePlayer () {
  return function (dispatch, getState) {
    let ap = getState().player.ap
    dispatch(setAp(ap < 1 ? 1 : 0))
  }
}

export function setAh(ah) {
  return {
    type: SET_PLAYER_AH
    , ah: ah
  }
}

export function setAp(ap) {
  if(ap > 1) {
    ap = 1
  } else if(ap < 0) {
    ap = 0
  }

  return {
    type: SET_PLAYER_AP
    , ap: ap
  }
}

export function useFixed (fixed=false)  {
  return {
    type: USE_FIXED_PLAYER
    , isFixed: fixed
  }
}

export function toggleLyric () {
  return {
    type: TOGGLE_LYRIC
  }
}

export function togglePlChooser () {
  return {
    type: TOGGLE_PL_CHOOSER
  }
}

import React from 'react'

export function togglePlayerSonglist () {


  return (dispatch, getState) => {
    let state = getState()
    , x = state.win.width / 2 + 288
    , y = 60
    , isMiniPlayer = state.player.ap === 1

    if(isMiniPlayer) {
      let pl = state.player.currentPlaylist // douradio.getCurrentPlaylist()

      require(['views/songlist/mini'], function (MiniSonglist) {
        dispatch(displayOverlay(
          <MiniSonglist
            x={x}
            y={y}
            songlist={pl}></MiniSonglist>, DLG_MINI_SONGLIST))
      })

    } else {
      dispatch({
        type: TOGGLE_PLAYER_SONGLIST
      })
    }
  }

}

export function fetchRecentCollect() {
  return (dispatch) => {
    request({url: 'recent_collected'}).then((response) => {
      dispatch({
        type: RESPONSE_RECENT_COLLECT
        , error: 0
        , playlists: response
      })
    }, (error) => {
      dispatch({
        type: RESPONSE_RECENT_COLLECT
        , error: 1
        , msg: error
      })
    })
  }
}

export function fetchRecentPlaysource() {
  return (dispatch, getState) => {
    request({
      url: 'recent_playsource'
    }).then(({ records, user_daily_avatar }) => {
      dispatch({
        type: RESPONSE_RECENT_PLAYSOURCE
        , error: 0
        , records
        , user_daily_avatar
      })
    })
  }
}

export function fetchPlayerAd(songId) {
  return (dispatch) => {
    request({url: '/j/v2/song/' + songId + '/promo'}).then((response) => {
      dispatch({
        type: SET_PLAYER_TEXT_AD
        , error: 0
        , textAd: response
      })
    }, (error) => {
      dispatch({
        type: SET_PLAYER_TEXT_AD
        , error: 1
        , msg: error
      })
    })
  }
}
