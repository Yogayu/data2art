export const DISPLAY_SNACK = "DISPLAY_SNACK"
export const HIDE_SNACK = "HIDE_SNACK"

let hideHandler = null

export function displaySnack(msg, autoHideTime = 3000) {
  return function (dispatch) {
    if(hideHandler) {
      window.clearTimeout(hideHandler)
    }

    dispatch({
      type: DISPLAY_SNACK
      , message: msg
    })

    hideHandler = window.setTimeout(function () {
      dispatch(hideSnack())
    }, autoHideTime)

  }
}

export function hideSnack() {
  return { type: HIDE_SNACK }
}
