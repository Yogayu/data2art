// these actions will and only be trigger by douradio lib

export const SWITCH_SONG = 'switch_song'

// switch_playlist
// export const SWITCH_CHANNEL = 'switch_channel'
// export const SWITCH_SONGLIST = 'switch_songlist'

// switch playlist
export const SWITCH_PLAYLIST = 'switch_playlist'

export const CHANGE_PLAYER_STATUS = 'CHANGE_PLAYER_STATUS'

// list of player status
// 正在载入播放列表
export const PLAYER_STATUS_LOADING = "PS_LOADING "
// 载入播放列表错误
export const PLAYER_STATUS_LOADING_ERROR = "PS_LOADING_ERROR "

// 播放列表已经载入, 音频文件 buffering
export const PLAYER_STATUS_BUFFERING = "PS_BUFFERING"
// 音频文件出错
export const PLAYER_STATUS_BUFFERING_ERROR = "PS_BUFFERING_ERROR"

// 正常播放中
export const PLAYER_STATUS_SUCCESS = "PS_SUCCESS"
