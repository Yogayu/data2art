export const REQUEST_RESOURCE = 'REQUEST_RESOURCE'
export const RESPONSE_RESOURCE = 'RESPONSE_RESOURCE'

// resourceS
export const RESOURCE_CHANNELS = "RESOURCE_CHANNELS"

// collection
export const RESOURCE_COLLECTION_CHANNELS = "RESOURCE_COLLECTION_CHANNELS"
export const RESOURCE_COLLECTION_SONGLISTS = "RESOURCE_COLLECTION_SONGLISTS"

export const RESOURCE_CREATED_SONGLISTS = "RESOURCE_CREATED_SONGLISTS"

import douradio from 'douradio'

export function requestChannels () {
  return (dispatch, getState) => {
    let { explore } = getState()
    , artistChannel = explore.channels.get('artist').toObject()
    if(artistChannel && (
      artistChannel.isFetching || artistChannel.channels.length > 0
    )) {
      return
    }

    dispatch({
      type: REQUEST_RESOURCE
      , resource: RESOURCE_CHANNELS
    })

    douradio.apiClient.request({
      url: 'rec_channels'
      , data: {
        specific: 'all'
      }
    }).then((response) => {
      dispatch({
        type: RESPONSE_RESOURCE
        , resource: RESOURCE_CHANNELS
        , channels: response.data.channels
      })
    }, () => {
      dispatch({
        type: RESPONSE_RESOURCE
        , resource: RESOURCE_CHANNELS
        , channels: []
      })
    })
  }
}

function createDispatcher(resource, req) {
  return (dispatch, getState) => {
    dispatch({
      type: REQUEST_RESOURCE
      , resource: resource
    })

    req().then((data) => {
      dispatch({
        type: RESPONSE_RESOURCE
        , resource: resource
        , err: null
        , data: data
      })
    }, (err) => {
      dispatch({
        type: RESPONSE_RESOURCE
        , resource: resource
        , err: err
      })
    })
  }
}


export function requestCollection() {
  createDispatcher(
    RESOURCE_COLLECTION_SONGLISTS
    , () => {
      return douradio
        .request({url: 'programme/collection'})
        .then((response) => {
          return {
            'songlists': response.programmes
            , 'total': response.total
          }
        })
    }
  )

  createDispatcher(
    RESOURCE_COLLECTION_CHANNELS
    , () => {
      return douradio
        .request({url: 'channel_collection'})
        .then(({total, channels}) => {
          return {total, channels}
        })
    }
  )
}

export function requestCreatedSonglists () {
  createDispatcher(RESOURCE_CREATED_SONGLISTS, () => {
    return douradio.request({url: 'songlist/mine'}).then((response) => {
      return response
    })
  })
}
