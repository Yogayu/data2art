// Redux Action Utils

/**
 * Common helper for create promise based async(ajax) action type
 * @param  {string} requestActionType
 * @param  {string} responseActionType
 * @param  {function -> Promise} req  - a function that returns a function
 * @return {function}
 */
export function createAsyncDispatcher(
  requestActionType,
  responseActionType,
  req
) {
  return (dispatch, getState) => {
    dispatch({type: requestActionType})

    req().then((data) => {
      dispatch({
        type: responseActionType
        , err: null
        , payload: data
      })
    }, (err) => {
      dispatch({
        type: responseActionType
        , err: err
      })
    })
  }
}
