export const SHOW_TOOLTIP_GUIDE = "SHOW_TOOLTIP_GUIDE"
export const DIAPLAY_NEXT_TOOLTIP_GUIDE = "DIAPLAY_NEXT_TOOLTIP_GUIDE"

export function showTooltipGuide () {
  return { type: SHOW_TOOLTIP_GUIDE }
}

export function nextStep() {
  return { type: DIAPLAY_NEXT_TOOLTIP_GUIDE }
}
