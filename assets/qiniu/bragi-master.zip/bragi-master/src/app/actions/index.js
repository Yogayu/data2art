/* define all your consts here */
export const WINDOW_RESIZE = 'WINDOW_RESIZE'
export const WINDOW_SCROLL = 'WINDOW_SCROLL'

export const DISPLAY_OVERLAY = "DISPLAY_OVERLAY"
export const HIDE_OVERLAY = "HIDE_OVERLAY"
export const CLICK_OUTSIDE = "CLICK_OUTSIDE"

// popup names
export const DLG_PUSH_TO_DEVICES = "PUSH_TO_DEVICES "
export const DLG_ADD_TO_SONGLIST = "ADD_TO_SONGLIST"
export const DLG_SHARE = "SHARE"
export const DLG_CTX_MENU = "CTX_MENU"

export const DLG_MINI_SONGLIST = "MINI_SONGLIST"

import { push } from 'react-router-redux'

export function navigate(path) {
  return push(path)
}

export function resize(width, height) {
  return {
    type: WINDOW_RESIZE
    , width, height
  }
}

export function scroll(y) {
  return {
    type: WINDOW_SCROLL
    , scrollY: y
  }
}

export function displayOverlay (component, name) {
  let {
    type, props
  } = component

  return {
    type: DISPLAY_OVERLAY
    , name: name
    , component: {type, props}
  }
}

export function hideOverlay(name) {
  return {
    type: HIDE_OVERLAY
    , name: name
  }
}

function hideOverlayDispatch(dispatch, name) {
  return dispatch(hideOverlay(name))
}

export function clickOutside () {
  return function (dispatch, getState) {
    let {overlay, player} = getState()
    if(overlay.size > 0 || player.showPlChooser) {
      dispatch({ type: CLICK_OUTSIDE })
    }
  }
}

/**
 * push song to mobile phone(only song is supported currently)
 */
export function push2Device(model, e) {
  e.preventDefault()
  e.stopPropagation()

  let x, y
  // @hack item is: .context-menu -> li
  if(e.currentTarget && e.currentTarget.tagName === 'LI') {
    let target = e.currentTarget.offsetParent
    x = target.offsetLeft
    y = target.offsetTop
  } else {
    x = e.clientX
    y = e.clientY
  }

  return function (dispatch) {
    if(!model) {
      return
    }

    require(['views/share/push'], (PushBox) => {
      return dispatch({
        type: DISPLAY_OVERLAY
        , name: DLG_PUSH_TO_DEVICES
        , component: {
          type: PushBox
          , props: {
            song: model
            , x: x
            , y: y
            , onClose: hideOverlayDispatch.bind(dispatch, DLG_PUSH_TO_DEVICES)
          }
        }
      })
    })
  }
}

// open a dialog that user can add song to songlists
import {SonglistChooser} from "views/actions/add2songlist"

export function add2songlist(model, e) {
  e.preventDefault()
  e.stopPropagation()

  let x = e.pageX
  , y = e.pageY

  return function (dispatch) {
    return dispatch({
      type: DISPLAY_OVERLAY
      , name: DLG_ADD_TO_SONGLIST
      , component: {
        type: SonglistChooser
        , props: {
          song: model
          , x: x
          , y: y
          , onClose: hideOverlayDispatch.bind(dispatch, DLG_ADD_TO_SONGLIST)
        }
      }
    })
  }
}

// share song or playlist or whatever
import douradio from 'douradio'

export function share(model, playlist) {
  return function (dispatch) {
    // nothing to share, ignore
    if(!model && !playlist) {
      return
    }


    require(['views/share'], function (shareKit) {
      let data

      if(!model && playlist) {
        // share playlist
        data = shareKit.sharePlaylist(playlist)
      }

      if(model instanceof douradio.Song) {
        data = shareKit.shareSong(model, playlist)
      } else if(model instanceof douradio.Artist) {
        data = shareKit.shareArtist(model)
      }

      return dispatch(displayOverlay({
        type: data.type
        , props: Object.assign({}, data.props, {
          onClose: hideOverlayDispatch.bind(dispatch, DLG_SHARE)
        })
      }, DLG_SHARE))
    })
  }
}
