// Common actions for logging
import request from 'utils/request'

export function adLog(type) {
  // type in ['show', 'click']

  return (dispatch, getState) => {
    const state = getState()
    , ta = state.player.textAd
    , cs = state.player.currentSong

    if(!ta || !cs) { return }

    return request({
      url: 'log_ad'
      , data: {
        ad_id: ta.id
        , track_id: cs.id
        , status: 'on_player'
        , action: type
      }
    })

  }

}
