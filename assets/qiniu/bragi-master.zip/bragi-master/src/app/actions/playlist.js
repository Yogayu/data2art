export const TOGGLE_COLLECT = "TOGGLE_COLLECT"

`{
  user(id: "id") {
    name
  }
}`

// Connect
function toggleCollect() {
  return
  // TOGGLE_COLLECT
}


// Apollo Client and React, the
