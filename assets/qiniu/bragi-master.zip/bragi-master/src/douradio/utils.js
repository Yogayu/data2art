import object from "lodash/fromPairs"
import map from "lodash/map"

export function parseCookie(cookieString=null) {
  if(!cookieString) {
    cookieString = document.cookie
  }
  return object(map(cookieString.split(';'), (s) => {
    return s.trim().replace(
      /\"/g, ''
    ).split('=')
  }))
}
