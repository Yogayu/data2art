import Model from "./model"
import isNumber from "lodash/isNumber"
import isString from "lodash/isString"
import findIndex from "lodash/findIndex"

/**
 * Base Model for all song in this application
 */
export default class Song extends Model {

  constructor(attrs, options) {
    // parse `sid`
    let sid = attrs.sid
    if(sid && sid.indexOf('g') > 0) {
      // <sid>g<ssid> format
      let [_sid, _ssid] = sid.split('g')
      attrs.sid = _sid
      attrs.ssid = _ssid
    }

    // get item_id
    let item_info = attrs.item_info
    if (item_info && item_info.item_id) {
      attrs.item_id = item_info.item_id
    }
    super(attrs, options)
  }

  static getObjectId(sid, ssid) {
    if(ssid) {
      return `${sid}g${ssid}`
    } else {
      return sid
    }
  }

  /**
   * Check if the song is playable
   * @return {Boolean}
   */
  isPlayable() {
    // banned song is also not playable
    if(this.isBan()) {
      return false
    }

    if(this.get('subtype') === 'T') {
      return true
    }

    return this.get('playable') || this.get('status') === 0
  }

  objectId() {
    return Song.getObjectId(this.get('sid'), this.get('ssid'))
  }

  url(endpoint) {
    if(endpoint) {
      return 'song/' + this.objectId() + '/' + endpoint
    }
    return 'song/' + this.objectId() + '/'
  }

  getArtists() {
    return this.get('singers')
  }

  relatedSonglists() {
    return this.get('related_songlists') || []
  }

  getItemId() {
    return this.get('item_id')
  }

  /**
   * @return {Boolean}
   */
  isLike() {
    let taste_status = this.get('taste_status')
    if(isNumber(taste_status) || isString(taste_status)) {
      return taste_status == 1
    }

    let like = this.get('like')
    if(isString(like)) {
      return (like === '1')
    } else {
      // typeof like == (number||int)
      return !!like
    }
  }

  isBan() {
    return this.get('taste_status') == 2
  }

  checkIsChannelSong() {
    if(this.collection && this.collection.isChannel && this.collection.isChannel()) {
      return console.warn('do not call toggleLike/toggleBan in ChannelSong')
    }
  }

  toggleLike(request) {
    // toggle like can be called in three different ways
    // 1. when playing channel toggleLike will be used in algorighm, so
    //    toggleLike muse be called in `playlist?` api
    this.checkIsChannelSong()

    let isLike = this.isLike()
    , liked_count = this.get('liked_count')

    this.set({
      taste_status: isLike ? 0 : 1
      , liked_count: liked_count >= 0 ? (liked_count + (isLike ? -1 : 1)) : null
    })

    // 2. other usecase
    return request({
      url: this.url('like')
      , method: isLike ? 'delete' : 'put'
    }).then((response) => {
      // Change this to `response.taste_status` when @seanlee is ready
      this.set({
        taste_status: response.taste_status
      })
    })
  }

  toggleBan(request) {
    this.checkIsChannelSong()

    return request({
      url: this.url('ban')
      , method: this.isBan() ? 'delete' : 'put'
    }).then((response) => {
      // Change this to `response.taste_status` when @seanlee is ready
      this.set({
        taste_status: (this.isBan() ? 0 : 2)
      })
    })
  }

  albumLink() {
    // 'http://site.douban.com/xiaozhou/'
    let album = this.get('album')
    if(!album) {
      return ""
    }

    if((new RegExp('^https?\:\/\/(.*)')).test(album)) {
      return album
    } else {
      return '//music.douban.com' + album
    }
  }

  relatedChannelId() {
    return (parseInt(this.get('sid')) + 2000000) || 0
  }

  shareUrl(oldStyle=false) {
    // @todo modify this for develop
    const host = 'http://douban.fm'

    if(oldStyle) {
      return `${host}/?start=${this.objectId()}&cid=${this.relatedChannelId()}`
    }

    if(!this.collection) {
      return `${host}/song/${this.objectId()}`
    }

    let isChannel = this.collection.isChannel()
    if(!isChannel && this.collection.info.type !== 1) {
      return `${host}/song/${this.objectId()}`
    }

    // channel or special songlist
    if(isChannel || this.collection.info.type != 0) {
      let channel = this.collection
      let start = [
        this.get('sid')
        , this.get('ssid')
        , (channel && channel.id) || '0'
      ].join('g')
      return `${host}/channel/${this.relatedChannelId()}?start=${start}`
    } else {
      return `${host}/songlist/${channel.id}?sid=${this.get('sid')}`
    }
  }

  formatedIndex(index) {
    if(!isNumber(index)) {
      index = this.get('index')
    } else if(this.collection){
      index = findIndex(this.collection.models, this)
    }

    if(isNumber(index) && index >= 0) {
      return (index + 1).toString()
    } else {
      return null
    }
  }

  isReady() {
    return this.has('title')
  }

  /**
   * @override
   * @param  {[type]} request [description]
   * @return {[type]}         [description]
   */
  fetch(request) {
    if(this.collection && this.collection.fetchSong) {
      return this.collection.fetchSong(this.id)
    } else {
      // the song is not belong to any playlist
      return super.fetch(request)
    }
  }

  isAd() {
    return this.get('subtype') === 'T'
  }

}

Song.prototype.idAttribute = 'sid'
