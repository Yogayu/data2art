import ApiClient from "./apiclient"
import includes from "lodash/includes"
import {parseCookie} from "./utils"

const promiseable = (wrapped) => {
  return new Promise(function (resolve, reject) {
    wrapped.then(resolve, reject)
  })
}

export default class WebApiClient extends ApiClient {

  request(ajaxOptions) {
    if(
      ajaxOptions.url.indexOf('/j') != 0
      && ajaxOptions.url.indexOf(this.options.apiroot) != 0
    ) {
      ajaxOptions.url = this.options.apiroot + ajaxOptions.url
    }

    // auto ck
    if(includes(
      ['post', 'put', 'delete'],
      (ajaxOptions.method || 'get').toLowerCase())
    ) {
      if(!ajaxOptions.data) {
        ajaxOptions.data = {}
      }
      ajaxOptions.data.ck = parseCookie().ck
    }

    return this.ajax(ajaxOptions)
  }

  isLogin() {
    return !!(this.authinfo && this.authinfo.user_id)
  }

  checkLogin({
    ajax_sig
    , douban_host
    , login_check_url
  }) {
    const getUserInfo = () => {
      return this.request({
        url: "user_info?avatar_size=large"
      })
    }

    window.show_login = function () {
      // resolve(getUserInfo())
      if(window._login_check_callback) {
        window._login_check_callback({
          login: false
        })
      }
    }

    return promiseable(
      this.ajax({
        url: `${douban_host}/service/account/check_with_js`
        , type: 'jsonp'
        , data: {
          'return_to': login_check_url
          , 'sig': ajax_sig
          , 'r': Math.random()
        }
        , jsonpCallback: 'callback'
        , jsonpCallbackName: '_login_check_callback'
      })
    )
    .then((result) => {
      if(result.url) {
        return promiseable(this.ajax({
          url: result.url
        })).then((result) => {
          return result.user_info
        })
      } else {
        return promiseable(getUserInfo())
      }
    })

  }

  oauthUrl() {
    return '/common_login?redir=' + encodeURIComponent(location.href)
  }

  logout() {
    location.href = `/partner/logout?source=radio&ck=${parseCookie().ck}&no_login=y`
  }

}
