import Audio from "./audio"
import logAudioError from "./logAudioError"

function getAudioDuration(audio, currentSong) {
  // let audio = this.audio
  // , currentSong = this.douradio.currentSong
  if(audio.isHTML5 || audio.loaded) {
    return audio.duration
  } else if(currentSong.get('length')) {
    return currentSong.get('length') * 1000
  } else {
    return audio.durationEstimate
  }
}

// this is a util function that connect douradio object with the Audio object
function createDouaudio(douradio, audioOptions={}) {

  let loadNextSong = function () {
    return douradio.getNextSong('n').then((song) => {
      return douradio._switchSong(song)
    })
  }

  let callbacks = {
    onplay: function () {douradio.trigger('play')}
  , onpause: function () {douradio.trigger('pause')}
  , onresume: function () {douradio.trigger('resume')}
  , onFinish: function () { douradio._onfinish() }
  , whileloading: function (daudio) {
      douradio.trigger('loading', daudio.audio)
    }
  , whileplaying: function (daudio) {
      let audio = daudio.audio
      if(!audio) {
        return
      }

      douradio.trigger('playing', {
        position: audio.position
        , duration: getAudioDuration(audio, douradio.currentSong)
      })
    }
  /**
   * @return {Promise} promsise of whether to load
   */
  , loadNextSong: loadNextSong
  , logError: function (daudio, kind, options) {
      if(!douradio.currentSong) {
        return
      }
      options.trackId = douradio.currentSong.id
      options.url = douradio.currentSong.get('url')
      return logAudioError(douradio.apiClient.request, kind, options)
    }
  , onError: function () {
      douradio.trigger('error', '「请检查网络环境后继续收听」')
      // alert('「请检查网络环境后继续收听」')
    }
  , onLoadQuickly: function () {
      let kbps = douradio.getKbps()
      if(douradio.getKbps() === 'auto') {
        douradio.setKbps('+1')
        console.debug('load too quick, try a higher bitrate: ', douradio.apiClient.kbps, ' k')
      }
    }
  , onLoadSlowly: function (audio) {
      let realKbps = douradio.apiClient.kbps

      if(realKbps == '128') {
        console.debug('already the lowest bitrate, will switch song after 5s')
        return loadNextSong()
      }

      douradio.setKbps('128')
      console.debug('downgrade kbps to', douradio.apiClient.kbps, ' k')
      loadNextSong()
    }
  }

  return new Audio(audioOptions, callbacks)
}

export default createDouaudio
