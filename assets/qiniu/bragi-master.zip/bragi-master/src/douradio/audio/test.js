/* global describe, before, it, afterEach, beforeEach */

import Audio from "./audio"
import sinon from "sinon"
import assert from "assert"
import qs from "querystring"

let buildAudioUrl = (path, queryArgs={}) => {
  let host = 'http://fm.me.douban.com:3000/'
  return host + path + '?' + qs.stringify(queryArgs)
}

describe('TestHTML5Audio', function () {
  let audio
  , callbacks = {}

  before(function() {
    for(let key of Audio.RequiredOptions) {
      callbacks[key] = sinon.spy()
    }

    audio = new Audio({}, callbacks)
  })

  beforeEach(function () {
  })

  afterEach(function () {
    audio.unloadAudio()
  })

/*
  it(`will retry three times (interval 2s) after failure,
      and will skip song after three failure`, function (done) {
    this.timeout(0)
    // let startTime = Date.now()
    sinon.spy(audio, "reloadAudio")

    audio.retryWaitime = 10

    audio.play(buildAudioUrl('500'))

    let retryCount = 0

    callbacks.loadNextSong = function () {
      if(retryCount == 0) {
        assert(audio.reloadAudio.callCount == 3)
        audio.reloadAudio.restore()
      }
      // console.debug('retry for the ', retryCount, ' time')

      retryCount += 1
      return audio.play(buildAudioUrl('500', {retry: retryCount}))
      // return Promise.resolve(buildAudioUrl('500', {retry: audio._skipCount}))
    }

    // call this after retry 3 times
    callbacks.onerror = function() {
      // make sure player is stopped
      assert(audio.isPlaying() === false)

      // make sure retry for 3 times
      assert(retryCount === 3)

      done()
    }
  })
*/

  it('will call onSlowly after three lags(>1s)', function (done) {
    this.timeout(0)

    let audioUrl = 'fbcfbdc06191f59cb171d6f7603aae17/0/fm/song/p2021622_320k.mp3'
    audio.play(buildAudioUrl(audioUrl, {bandelay: 100}))

    // let audioUrl = 'slow.mp4'
    // audio.play(buildAudioUrl(audioUrl))

    callbacks.onSlowly = function (msg) {
      console.error(msg)
      done()
    }
  })

  it('will call onSlowly when loading time > 10s', function (done) {
    this.timeout(20000)
    let audioUrl = 'fbcfbdc06191f59cb171d6f7603aae17/0/fm/song/p2021622_320k.mp3'

    // build a url with latency 15s
    audio.play(buildAudioUrl(audioUrl, {latency: 15000}))

    callbacks.onSlowly = function (msg) {
      console.error(msg)
      done()
    }
  })


})
