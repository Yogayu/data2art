import defaults from "lodash/defaults"

/**
 * log error to server
 * @param  {function({})}             reqwest function of api client
 * @param  {String|Number} trackId    song id
 * @param  {String} reason            Extra reason of an audio error
 * @param  {[type]} kind="san-common" Error name
 * @param  {[type]} extraEnv=[]       Extra information
 * @return {Promise}                  ajax promise
 */
function logError(request, kind, options={}) {
  options = defaults(options, {
    readyState: 'uninitialised'
    , playState: 'uninitialised'
    , userAgent: navigator.userAgent
    , engine: 'html5'
    , trackId: null
    , reason: '' // audio.url
  })

  // user-agent,
  let requestData = {
    kind: kind || 'san-common'
    , env: [
      options.engine
      , options.userAgent
      , options.readyState
      , options.playState
    ].join('|')
    , track_id: options.trackId
    , url: options.url
    , reason: options.reason
  }

  console.debug('logAudioError:', requestData)

  return request({
    url: 'audio_err_report'
    , data: requestData
    , method: 'post'
  })
}

export default logError
