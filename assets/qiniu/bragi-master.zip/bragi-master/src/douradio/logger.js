import {getCurrentTime} from "utils"
import debounce from "lodash/debounce"

export default class Logger {

  constructor(apiClient) {
    this.logs = []
    this.doLog = debounce(this.doLog.bind(this), 1000)
    this.apiClient = apiClient

/*  douradio.on('finish', (song) => {
      this.log(song, song.collection, 'p')
    })
    douradio.on('switch_song', (song, prevSong) => {
      this.log(song, song.collection, 'j')
    })*/

  }

  log(song, songlist, type) {
    if(!song) {
      return
    }

    if(songlist.isChannel()) {
      return
    }

    // make sure type in [
    //  'j', // 下一首
    //  'k', // 上一首
    //  'p', // 播完
    //  's'  // 点播切歌

    //  'r'  // 红心
    //  'u'  // 取消红心
    // ]

    let playSource
    , pid
    , ptype = songlist.info.type

    if(ptype == -1) { // 红心歌单
      playSource = 'h'
      pid = 0
    } else if(ptype == 1) { // 每日私人歌单
      playSource = 'd'
      let time = songlist.info.updated_time
      pid = time.slice(0, 10).split('-').join('')
    } else if(ptype == 2) { // 用户
      playSource = 's'
      pid = 0
    } else  {
      playSource = 'n'
      pid = songlist.id
    }

    let info = {
      'sid': song.id
      , 'type': type
      , 'pid': pid // d: daily_songlist, 日期
      , 'time': getCurrentTime()
      , 'play_source': playSource
      , 'play_mode': 'o'
    }

    this.logs.push(info)
    this.doLog()
  }

  doLog() {
    console.debug('Post logs', this.logs)
    let logs = this.logs
    this.logs = []

    return this.apiClient.request({
      url: 'play_log'
      , data: {
        records: JSON.stringify(logs)
        , client: this.apiClient.options.client
      }
      // , type: 'json'
      , method: 'post'
      // , contentType: 'application/json'
    }).then(() => {
      console.debug('Post log finshed')
    })
  }

}
