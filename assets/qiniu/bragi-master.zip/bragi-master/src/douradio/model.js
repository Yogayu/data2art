import Backbone from "backbone"

export default class Model extends Backbone.Model {

  constructor(attrs, options) {
    super(attrs, options)
    if(options && options.douradio) {
      this.douradio = options.douradio
    }
  }

 /**
  * @emits sync
  */
  fetch(request) {
    if(this._request) {
      return
    }
    this._request = request({
      url: this.url()
      , method: 'get'
    }).then((props) => {
      this.set(props)
      this.trigger('sync')
      this._request = null
    })
    return this._request
  }

}
