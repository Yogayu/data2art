import createDouaudio from "./audio"
import Artist from "./artist"
import Song from "./song"
import Channel from "./channel"
import ApiClient from "./apiclient.web"
import Songlist from "./songlist"
import Logger from "./logger"
import MineSonglists from "./songlist/mine"
import {parseCookie} from "./utils"
import defer from "promise-defer"
import {UserPlayRecords, BannedSongs} from "./songlist/playrecord"
import includes from "lodash/includes"
import get from 'lodash/get'
import isEmpty from 'lodash/isEmpty'

// Events Consts

import {
  NO_PERMISSION_TO_SWITCH_PLAYLIST
  , DEFAULT_VOLUME
} from './consts'

var {
  isNumber,
  isString,
  isObject,
  extend,
  defaults
} = require("underscore")

let isObjectId = (id) => {
  return isNumber(id) || isString(id)
}

// kbps list for pro users
export const PRO_KBPS = ['128', '192', '320']

// kbps list for normal users
export const NORMAL_KBPS = ['128']

module.exports = class Douradio {
  Channel = Channel
  Songlist = Songlist
  Artist = Artist
  Song = Song

  defaultOptions = {
    ajax: null
    , apiClient: null
    , Events: null
    , domready: null
    , apiroot: "/v2/fm/"
    , apikey: ""
    , apisecret: ""
    , udid: ""
    , bid: ""
    , bitrate: "auto"
    , userinfo: null
    , maxErrorLimit: 2
  }

  _playlist = null
  _nextPlaylist = null
  _audioErrorCount = null
  _actionLoading = false

  constructor(options = {}) {
    this.options = defaults(options, this.defaultOptions)

    for (let rOpt of ["Events"]) {
      !this.options[rOpt] ? console.error("Option ", rOpt, " is not exists!") : undefined
    }

    options.apiClient ? this.apiClient = options.apiClient : this.apiClient = new ApiClient(this.options)

    options.Events ? extend(this, options.Events) : undefined

    for (let i of ["oauthUrl", "getLyric"]) {
      this.apiClient[i] ? this[i] = this.apiClient[i].bind(this.apiClient) : undefined
    }

    options.bitrate ? this.setKbps(options.bitrate) : undefined
    this.logger = new Logger(this.apiClient)
    this.mineSonglists = new MineSonglists(this)
    !options.bid ? this.options.bid = parseCookie().bid : undefined
    this.currentAudio = createDouaudio(this, this.options.audio)
    this.playRecords = new UserPlayRecords([], {apiClient: this.apiClient})
    this.bannedSongs = new BannedSongs([], {apiClient: this.apiClient})
  }

  // helper function
  reportError(error) {
    console.error('[Douradio]', error)
    this.trigger('error', error)
  }

  isLogin() {
    return !!(this.options.userinfo && this.options.userinfo.user_id)
  }

  logout() {
    this.trigger("logout")
    return this.apiClient.logout()
  }

  getAccessCode() {
    return this.apiClient.getAccessCode.apply(this.apiClient, arguments).then(response => {
      this.trigger("token:update", response)
      return response
    })
  }

  xauth() {
    return this.apiClient.xauth.apply(this.apiClient, arguments).then(response => {
      this.trigger("token:update", response)
      return response
    })
  }

  /**
   * [getCurrentUser description]
   * @trigger 'login'
   * @param  {boolean} force=false force update userinfo or not
   * @return
   */
  getCurrentUser(force=false) {
    if (this.options.userinfo && !force) {
      return Promise.resolve(this.options.userinfo)
    } else {
      return (this.apiClient.checkLogin &&
        window.bootstrap &&
        window.bootstrap.login_configs ?
        this.apiClient.checkLogin(window.bootstrap.login_configs) :
        this.apiClient.request({
          url: "user_info?avatar_size=large"
        })
      ).then(userinfo => {
        // @todo remove this line for debug only
        // userinfo.is_personal_service_enabled = false
        this.options.userinfo = userinfo
        this.trigger('login', userinfo)
        return userinfo
      })
    }
  }

  isPlaying() {
    return this.currentAudio.isPlaying()
  }

  _onfinish() {
    this.getNextSong().then(theNextSong => {
      return this._switchSong(theNextSong)
    })

    this.trigger("finish", this.currentSong)
    return this.logger.log(this.currentSong, this._playlist, "p")
  }

 /**
  * [getNextSong description]
  * @param  {[type]} type set force
  * @return {[type]}
  */
  getNextSong(type) {
    if(this._nextPlaylist) {
      if(this._playlist) {
        this._playlist.destroy()
      }
      this._playlist = this._nextPlaylist
      this._nextPlaylist = null
    }
    let pms = this._playlist.getNextSong(type)
    return pms.catch((msg) => {
      return this.switchToFallbackChannel()
    })
  }

  /**
   * [_switchSong description]
   * @param  {[type]} songModel [description]
   * @param  {[type]} play      =             true [description]
   * @param  {[type]} position  [description]
   * @return {[type]}           [description]
   */
  _switchSong(songModel, play = true, position) {
    var ref

    if (!songModel.isReady()) {
      return songModel.fetch().then(() => {
        return this._switchSong(songModel, play, position)
      })
    }

    var dfed = defer(Promise)

    if (!songModel.isPlayable()) {
      console.error("Song is not playeable!", songModel)
      return dfed.reject("Song is not playable!")
    }

    // if (songModel.id === (((ref = this.currentSong) != null ? ref.id : void 0))) {
    //   console.error("Song is already playing!", songModel)
    //   return dfed.reject("song already playing")
    // }

    var songUrl = songModel.get("url")

    if (!songUrl) {
      return this.getNextSong().then(theNextSong => {
        return this._switchSong(theNextSong)
      })
    }

    position = position || songModel.get("position") || 0
    this.currentAudio.play(songUrl, position)
    var prevSong = this.currentSong
    this.currentSong = songModel

    songModel.set({
      isPlaying: true
    })

    if(prevSong) {
      prevSong.set({
        isPlaying: false
      })
    }

    this.trigger("switch_song", songModel)
    dfed.resolve()
    return dfed.promise
  }

  restorePlayerState(playState) {
    var ref1
    var ref
    playState.bitrate ? this.setKbps(playState.bitrate) : undefined
    this.setVolume(playState.volume || DEFAULT_VOLUME)

    if (isObjectId(playState.channel_id)) {
      if (playState.current_song && playState.current_song.sid) {
        this.switchChannel(playState.channel_id, false)
        return this._switchSong(new Song(playState.current_song), true)
      } else {
        return this.switchChannel(playState.channel_id, true)
      }
    } else if (isObjectId(playState.songlist_id)) {
      return this.switchSonglist(
        playState.songlist_id,
        (ref = playState.current_song) != null ? ref.sid : void 0,
        (ref1 = playState.current_song) != null ? ref1.position : void 0
      )
    } else {
      return this.switchToFallbackChannel()
    }
  }

  getPlayerState() {
    var ref
    var state = {}

    this.currentSong ? state["current_song"] = extend(this.currentSong.toJSON(), {
      position: (ref = this.currentAudio.audio) != null ? ref.position : void 0
    }) : undefined

    this._playlist ? state[this._playlist.type + "_id"] = this._playlist.id : undefined

    // bitrate and volume are settings
    // state.bitrate = this.getKbps()
    // state.volume = this.getVolume()
    return state
  }

  destroy() {}

  isShuffle() {
    if (this._playlist.isChannel()) {
      return false
    }

    return this._playlist.isShuffle
  }

  toggleShuffle() {
    if (this._playlist.isChannel()) {
      return false
    }

    var value = this._playlist.toggleShuffle()
    this.trigger("change:shuffle", value)
    return value
  }

  togglePause() {
    return this.currentAudio.togglePause()
  }

  isLoading() {
    return this._actionLoading
  }

  /**
   * this method will call everytime
   */
  _beginLoading() {
    this.currentAudio.audio.pause()
    this._actionLoading = true
    return this.trigger("request")
  }

  _endLoading() {
    return this._actionLoading = false
  }

  skip() {
    if (this._actionLoading) {
      return Promise.reject("Previous action is requesting")
    }

    if (!this._playlist) {
      return this.switchToFallbackChannel()
    }

    this.currentSong ? this.logger.log(this.currentSong, this._playlist, "j") : undefined
    this.trigger("skip")
    var pms = null

    if (this._playlist.skip) {
      pms = this._playlist.skip()
      this._nextPlaylist ? pms = this.getNextSong() : undefined
    } else {
      pms = this.getNextSong()
    }

    this._beginLoading()

    return pms.then(theNextSong => {
      this._endLoading()
      return this._switchSong(theNextSong)
    }, error => {
      this._endLoading()
      return this.reportError("切歌出错")
    })
  }

  prev() {
    var pms
    var pms

    if (this._actionLoading) {
      return Promise.reject("Previous action is requesting")
    }

    this.currentSong ? this.logger.log(this.currentSong, this._playlist, "k") : undefined

    if (this.isProgramme()) {
      this._nextPlaylist ? pms = this.getNextSong() : pms = this._playlist.getPrevSong()
      this._beginLoading()

      return pms.then(thePrevSong => {
        this._endLoading()
        return this._switchSong(thePrevSong)
      }, error => {
        this.reportError("[prev] error")
        return this._endLoading()
      })
    } else {
      return console.warn("Call prev in non programme playlist is not allowed!")
    }
  }

  toggleLike() {
    var ref
    return (ref = this._playlist) != null ? ref.toggleLike() : void 0
  }

  ban() {
    if (this._actionLoading) {
      return Promise.reject("Previous action is requesting")
    }

    if (!this._playlist) { return }

    let pms = this._playlist && this._playlist.ban()

    if(this._nextPlaylist) {
      pms = this.getNextSong()
    }

    this._beginLoading()

    return pms.then(song => {
      this._endLoading()
      return this._switchSong(song)
    }, (error) => {
      // switch to fallback channel
      this.switchToFallbackChannel()
      this.reportError(error)
      return this._endLoading()
    })
  }

  playNext(id, type = "channnel") {
    var pl = null

    if (!this._playlist) {
      if (type === "songlist") {
        return this.switchProgramme(id)
      } else {
        return this.switchChannel(id)
      }
    }

    type === "songlist" ? pl = this.getSonglist(id) : pl = new Channel(id, {
      douradio: this
    })

    this._nextPlaylist = pl

    return pl.fetch().then(() => {
      return this.trigger("will_switch_playlist")
    })
  }

  unplayNext() {
    this._nextPlaylist.destroy()
    this._nextPlaylist = null
    return this.trigger("will_switch_playlist")
  }

  getCurrentPlaylist() {
    return this._playlist
  }

  getNextPlaylist() {
    return this._nextPlaylist
  }

  /**
   * if something error when swtich channel/songlist, switch to the fallback channel instead
   * @return
   */
  switchToFallbackChannel() {
    return this.switchChannel(this.hasPersonalService() ? 0 : -10)
  }

  /**
   * decide whether a user can switch personal channel or can display userguide
   * @return {Boolean}
   */
  hasPersonalService() {
    let canPlayPersonalChannel = !!get(this, [
      'options', 'userinfo', 'is_personal_service_enabled'
    ])
    return canPlayPersonalChannel
  }

  canSwitchPlaylist(type, id) {
    if(id instanceof Songlist || id instanceof Channel) {
      type = id.type
      id = id.id
    }

    let canPlayPersonalChannel = this.hasPersonalService()

    if(!canPlayPersonalChannel && ((
      type === 'songlist' && id == 'user_daily')
      || (type === 'channel' && id == '0'))) {
      this.trigger(NO_PERMISSION_TO_SWITCH_PLAYLIST)
      return false
    }

    return true
  }

  switchChannel(channel_id, play = true) {
    if(!this.canSwitchPlaylist('channel', channel_id)) {
      return
    }

    if (!isObjectId(channel_id)) {
      console.error("wrong channel id type", channel_id)
      channel_id = 0
    }

    var start = null
    var context = null

    if (isString(play)) {
      start = play
      var play = true
    } else if (isObject(play)) {
      var {
        start,
        context
      } = play

      play = true
    }

    // if (this._playlist && (channel_id.toString() === this._playlist.id.toString()) && this._playlist.isChannel()) {
    //   if (start) {
    //     this._playlist.options.start = start
    //     return this.skip()
    //   }

    //   if (play && !this.isPlaying()) {
    //     this.togglePause()
    //   }

    //   return Promise.resolve()
    // }

    if (this.currentSong) {
      this.currentSong.set({
        isPlaying: false
      })

      this.currentSong = null
    }

    this._playlist ? this._playlist.destroy() : undefined

    this._playlist = this.getChannel(channel_id, {
      start: start
      , context: context
    })

    this.trigger("switch_channel")

    return this._playlist.fetch().then(channelModel => {
      if (play) {
        return this.getNextSong().then(theNextSong => {
          return this._switchSong(theNextSong)
        })
      }

      return null
    }, err => {
      return console.error("switch-channel-error" + err)
    })
  }

  getSonglist(slid) {
    return Songlist.getSonglist(this, slid)
  }

  getProgramme(pid) {
    console.warn("get Programme is no-longer supported, please use getSonglist")
    return this.getSonglist(pid)
  }

  getChannel(channel_id, opts) {
    return new Channel(channel_id, extend({
      douradio: this
    }, opts))
  }

  getHeartlist() {
    return this.getSonglist("redheart")
  }

  switchProgramme() {
    console.warn("swtichProgramme is no-longer support, please switchSonglist instead")
    return this.switchSonglist.apply(this, arguments)
  }

  switchSonglist(programme_id, play = true, position) {
    if(!this.canSwitchPlaylist('songlist', programme_id)) {
      return
    }

    var sidToPlay = null

    if (play && isNumber(parseInt(play))) {
      sidToPlay = play
      var play = true
    }

    var songlist = programme_id

    if (this._playlist && songlist && sidToPlay && (songlist === this._playlist.id || songlist.id === this._playlist.id)) {
      var songToPlay = this._playlist.get(sidToPlay)

      if (!songToPlay) {
        return Promise.reject("Song not in the playlist, do nothing")
      }

      this.logger.log(this.currentSong, this._playlist, "s")
      this._playlist.pushRecord(songToPlay.id)
      return this._switchSong(songToPlay)
    }

    if (programme_id instanceof Songlist) {
      if(this._playlist && this._playlist.id !== programme_id.id) {
        this._playlist.destroy()
      }

      this._playlist = programme_id

      if (!play) {
        return
      }

      if (sidToPlay) {
        songToPlay = this._playlist.get(sidToPlay)

        if (songToPlay) {
          this.trigger("switch_songlist")
          return this._switchSong(songToPlay, true, position)
        }
      }

      this.trigger("switch_songlist")
      return this.getNextSong().then(theNextSong => {
        return this._switchSong(theNextSong, true, position)
      })
    } else {
      if (!isObjectId(programme_id)) {
        return this.switchToFallbackChannel()
      }

      this._playlist ? this._playlist.destroy() : undefined
      this._playlist = this.getSonglist(programme_id)

      if (this.currentSong) {
        this.currentSong.set({
          isPlaying: false
        })

        this.currentSong = null
      }

      this.trigger("switch_songlist")

      return this._playlist.fetch().then(programmeModel => {
        if (!play) {
          this.currentSong = this._playlist.get(this.currentSong.get("sid"))
          return Promise.reject('Song is already playing')
        }

        this.trigger("switch_programme", programmeModel)

        if (sidToPlay) {
          var currentSong = this._playlist.get(sidToPlay)

          if (currentSong) {
            return this._switchSong(currentSong, true, position)
          }
        }

        return this.getNextSong().then(theNextSong => {
          return this._switchSong(theNextSong, true, position)
        })
      }, err => {
        console.error("switch programme error" + err)
        return this.switchToFallbackChannel()
      })
    }
  }

  isProgramme() {
    return !this._playlist.isChannel()
  }

  isPro() {
    var ref
    return (((ref = this.options.userinfo) != null ? ref.pro_status : void 0)) === "S"
  }

  setKbps(bitrate = "128") {
    let kbpsList = this.isPro() ? PRO_KBPS : NORMAL_KBPS

    if(bitrate == '+1' || bitrate == '-1') {
      let realKbps = this.apiClient.kbps
      , index = kbpsList.indexOf(realKbps)

      if(bitrate == '+1') {
        if(index < (kbpsList.length - 1)) {
          index = index + 1
        } else {
          index = kbpsList.length - 1
        }
      } else {
        if(index > 0) {
          index = index - 1
        } else {
          index = 0
        }
      }

      let targetKbps = kbpsList[index]

      if(targetKbps != realKbps) {
        this.apiClient.kbps = targetKbps
      }
    } else {
      this.options.bitrate = bitrate
      if(includes(kbpsList, bitrate)) {
        this.apiClient.kbps = bitrate
      } else if (bitrate === "auto") {
        this.apiClient.kbps = "192"
      } else {
        this.apiClient.kbps = "128"
      }
    }

    if(this._playlist) {
      this._playlist.onBitRateChange()
    }

    return Promise.resolve()
  }

  getKbps() {
    return this.options.bitrate
  }

  setVolume(volume) {
    if (volume > 100) {
      volume = 100
    } else if (volume < 0) {
      volume = 0
    }

    this.options.volume = volume
    return this.currentAudio.setVolume(volume)
  }

  getVolume() {
    return this.currentAudio.getVolume() || this.options.volume
  }

  userinfo(key=null, value=null) {
    // get or set userinfo
    if(!this.options.userinfo) {
      return
    }

    if(key && value) {
      this.options.userinfo[key] = value
    }

    if (key && !value) {
      if(key === 'liked_num') {
        let hl = this.getHeartlist()
        if(
          hl.length > 0 || (hl.info && hl.info.updated_time)
        ) {
          return hl.length
        }
      }

      return this.options.userinfo[key]
    }

  }

}
