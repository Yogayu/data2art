import ApiClient from "./apiclient"
import extend from "lodash/extend"
import isObject from "lodash/isObject"
import map from "lodash/map"

let params = (o) => {
  // ### parse the request param ###
  return map(o, (value, key) => {
    return encodeURIComponent(key) + '=' + encodeURIComponent(value)
  }).join('&')
}

export default class OauthApiClient extends ApiClient {

  /**
   * @override
   * @param  {URL} redirect_uri
   * @return {URL}
   */
  oauthUrl(redirect_uri) {
    if(!redirect_uri) {
      redirect_uri = location.origin
    }

    let url = 'https://www.douban.com/service/auth2/auth?' + params({
      client_id: this.options.apikey
      , redirect_uri: redirect_uri
      , response_type: 'code'
      , scope: 'music_fm_private,douban_basic_common'
      , state: ''
    })
    return url
  }

  _oauthSuccess(response) {
    response.expires_in = Date.now() + response.expires_in * 1000
    extend(this.authinfo, response)
    return response
  }

  /**
   * [getAccessCode description]
   * @param  {String} code
   * @param  {String} refresh_code
   * @param  {String} redirect_uri
   * @return {ReqPromise}
   */
  getAccessCode(code, refresh_code, redirect_uri) {
    var postData
    if (refresh_code == null) {
      refresh_code = false
    }
    if (redirect_uri == null) {
      redirect_uri = null
    }
    if (!redirect_uri) {
      redirect_uri = location.origin
    }
    postData = extend(refresh_code ? {
      grant_type: 'refresh_token',
      refresh_token: code
    } : {
      grant_type: 'authorization_code',
      code: code
    }, {
      client_id: this.options.apikey,
      client_secret: this.options.apisecret,
      redirect_uri: redirect_uri
    })
    return this.ajax({
      url: '/service/auth2/token',
      dataType: 'json',
      method: 'post',
      data: postData,
      success: this._oauthSuccess.bind(this)
    })
  }

/**
 * @override
 * @return {Boolean}
 */
  isLogin() {
    return !!(this.authinfo && this.authinfo.access_token)
  }

  /**
   * auth with username and password
   * @param  {[type]} username [description]
   * @param  {[type]} password [description]
   * @return {[type]}          [description]
   */
  xauth(username, password) {
    // post https://www.douban.com/service/auth2/token
    this.ajax({
      method: 'post'
      , url: 'https://www.douban.com/service/auth2/token'
      , data: {
        client_id: this.options.apikey
        , client_secret: this.options.apisecret
        , redirect_uri: ''
        , grant_type: 'password'
        , username: username
        , password: password
      }
    }).then(this._oauthSuccess)
  }

  request(ajaxOptions) {
    if (ajaxOptions.url.indexOf(this.options.apiroot) !== 0) {
      ajaxOptions.url = this.options.apiroot + ajaxOptions.url
    }

    if (!this.authinfo.access_token) {
      return this.ajax(ajaxOptions)
    } else if (Date.now() < this.authinfo.expires_in) {
      ajaxOptions.headers = extend(ajaxOptions.headers || {}, {
        'Authorization': 'Bearer ' + this.authinfo.access_token
      })

      return this.ajax(ajaxOptions).then((response) => {
        return response
      },  (error) => {
        try {
          response = isObject(error.response) || JSON.parse(error.response)
        } catch (e) {
          return e
        }

        if (response.code === 103) {
          this.logout()
        }
        // console.error(error, response)
        return [error, response]
      })
    } else {
      return this.getAccessCode(this.authinfo.refresh_token, true).then(() => {
        return this.request(ajaxOptions)
      }, this.logout.bind(this))
    }
  }

  /**
   * @override
   * @return
   */
  logout() {
    this.authinfo = {}
  }

}
