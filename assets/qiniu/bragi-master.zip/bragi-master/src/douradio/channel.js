var {
  isEmpty,
  isObject,
  extend
} = require("underscore")
import includes from "lodash/includes"

import Playlist from "./playlist"
import promiseDefer from "promise-defer"

var SPECIAL_CHANNEL = {
  "0": {
    name: "我的私人"
    , id: 0
  }
  , "-3": {
    name: "红心"
    , id: -3
  }
  , "-10": {
    name: "豆瓣精选"
    , id: -10
    , intro: "豆瓣好评音乐精选"
    , shareable: true
  }
}

export const CHNNAL_TYPE_NORMAL = 0
, CHNNAL_TYPE_ARTIST = 1
, CHNNAL_TYPE_SONG = 2

export default class Channel extends Playlist {
  constructor(id, models) {
    super(id, models)
    this.toggleLike = this.toggleLike.bind(this)
    this.like = this.like.bind(this)
    this.unlike = this.unlike.bind(this)
    this.ban = this.ban.bind(this)
    this.skip = this.skip.bind(this)
  }

  getChannelType() {
    return this.info.channel_type
  }

  type = "channel"

  shareable() {
    let specialChannel = SPECIAL_CHANNEL[this.id]
    return !specialChannel || specialChannel.shareable
  }

  collectable() {
    return !SPECIAL_CHANNEL[this.id]
  }

  getTitle() {
    var ref
    return (((ref = this.info) != null ? ref.name : void 0)) || ""
  }

  fetch() {
    if(this.promiseChannel) {
      return this.promiseChannel
    }

    let promiseChannel

    (SPECIAL_CHANNEL[this.id] ? promiseChannel = Promise.resolve({
      status: true

      , data: {
        channels: [SPECIAL_CHANNEL[this.id]]
      }
    }) : promiseChannel = this.apiClient.request({
      url: "channel_info"

      , data: {
        id: this.id
      }
    }))

    this.promiseChannel = promiseChannel.then(channelResponse => {
      var channel = null

      if (channelResponse.status && channelResponse.data.channels.length > 0) {
        channel = channelResponse.data.channels[0]
      } else {
        return Promise.reject()
      }

      (channel ? this.info = extend(channel, {
        type: "channel"
      }) : undefined)

      return channel
    })

    return this.promiseChannel
  }

  isCollect() {
    return this.info.collected === "true"
  }

  collect() {
    return this.apiClient.request({
      method: "post"
      , url: "app_collect_channel"
      , data: {
        id: this.id
      }
    }).then(() => {
      this.info.collected = "true"
      return this
    })
  }

  uncollect() {
    return this.apiClient.request({
      url: "app_uncollect_channel"
      , method: "post"
      , data: {
        id: this.id
      }
    }).then(() => {
      this.info.collected = "false"
      return this
    })
  }

  playlist(kwargs) {
    var defered = promiseDefer()

    var query_args = {
      channel: this.id
      , kbps: this.apiClient.options.kbps
      , client: this.apiClient.options.client
      , app_name: this.apiClient.options.app_name
      , version: this.apiClient.options.version
    }

    if (this.douradio.currentSong) {
      var currentSong = this.douradio.currentSong

      query_args = extend(query_args, {
        type: currentSong.status
        , sid: currentSong.get("sid")
        , pt: currentSong.get("position")
        , pb: currentSong.get("kbps")
        , apikey: this.apikey
      })

      query_args.type = "p"
    } else {
      query_args.type = "n"
    }

    if (this.options.start) {
      query_args.start = this.options.start
      this.options.start = null
    }

    if(this.options.context) {
      query_args.context = this.options.context
      this.options.context = null
    }

    query_args = extend(query_args, kwargs)

    this.apiClient.request({
      url: "playlist"
    , method: "get"
    , data: query_args
    , success: result => {
        if (!isObject(result) || result.r === !0) {
          return defered.reject(result)
        }

        if (query_args.type !== "e" && (!result.song || isEmpty(result.song))) {
          return defered.reject("songlist is empty", result)
        }

        var songs = this.parseSongs(result.song)

        if (includes(["s", "r", "u", "b", "n"], query_args.type)) {
          this.reset(songs)
        } else if (query_args.type === "p") {
          this.append(songs)
        }

        return defered.resolve("returned songlist", result)
      }

    , error: function(err) {
        return defered.reject("request error", err)
      }
    })

    return defered.promise
  }

  /**
   * @param currently support `n`
   * @return Promsie(theNextSong)
   */
  getNextSong(forceType) {
    let deferred = promiseDefer()

    if (!this.models || isEmpty(this.models)) {
      this.playlist(
        forceType ? {type: forceType} : {}
      ).then(results => {
        return deferred.resolve(this.models.shift())
      }, function(reason) {
        return deferred.reject("Request playlist error." + reason)
      })
    } else {
      // @todo {type: 'e'} is needed? or other common report url?
      // 报告一首歌播放完成, 仅报告用。
      // 不返回播放列表。客户端不对返回值做处理。

      // Original CoffeeScript Code:
      // if @douradio.currentSong?.get('sid') and \
      //    @douradio.currentSong.status not in ['b', 's']
      //   this.playlist({type: 'e'})
      // deferred.resolve(this.models.shift())
      let ref = this.douradio.currentSong
      if(
        ref && ref.get('sid') && !includes(['b', 's'], ref.status)
      ) {
        this.playlist({type: "e"})
      }

      deferred.resolve(this.models.shift())
    }

    return deferred.promise
  }

  onBitRateChange() {
    return this.models = []
  }

  toggleLike() {
    return (this.douradio.currentSong.isLike() ? this.unlike() : this.like())
  }

  like() {
    var song = this.douradio.currentSong
    song.set("like", 1)
    this.douradio.trigger("like", song)
    this.douradio.getHeartlist().addSong(song)

    return this.playlist({
      "type": "r"
    }).then(() => {})
  }

  unlike() {
    var song = this.douradio.currentSong
    song.set("like", 0)
    this.douradio.trigger("unlike", song)
    this.douradio.getHeartlist().removeSong(song)

    return this.playlist({
      "type": "u"
    }).then(result => {})
  }

  ban() {
    return this.playlist({
      "type": "b"
    }).then(result => {
      if(this.douradio.currentSong) {
        this.douradio.currentSong.status = 'b'
      }
      return this.getNextSong()
    })
  }

  skip() {
    if(this.douradio.currentSong) {
      this.douradio.currentSong.status = 'b'
    }

    return this.playlist({
      "type": "s"
    }).then(result => {
      return this.getNextSong()
    })
  }
}
