var {
  union,
  map,
  isObject
} = require("underscore")

import SongModel from "./song"
import Collection from "./collection"

module.exports = class Playlist extends Collection {
  model = SongModel
  models = []

  constructor(id, options) {
    super()
    var ref
    this.options = options

    if (isObject(id)) {
      var attrs = id
      this.id = attrs.id
      this.info = attrs
    } else {
      this.id = id.toString()
      this.info = {}
    }

    if ((ref = this.options) != null ? ref.douradio : void 0) {
      this.douradio = this.options.douradio
      this.apiClient = this.douradio.apiClient
    }
  }

  destroy() {}

  toModel(song, index, songs) {
    if (song instanceof this.model) {
      return song
    } else {
      return new this.model(song, {
        collection: this
      })
    }
  }

  append(songs) {
    return this.models = union(this.models, map(songs, this.toModel.bind(this)))
  }

  parseSongs(songs) {
    return songs
  }

  toggleCollect() {
    if (this.isCollect()) {
      return this.uncollect()
    } else {
      return this.collect()
    }
  }

  isCollect() {
    return false
  }

  getTitle() {
    return ""
  }

  getCover() {
    return this.info && this.info.cover
  }

  play() {
    return new Promise(function(receive, reject) {
      return (this.douradio.currentSong ? receive(this.douradio.currentSong) : this.nextSong())
    })
  }

  ban() {}
  like() {}
  unlike() {}
  skip() {}

  shareUrl() {
    return ("http://douban.fm/" + ((this.isChannel() ? "channel" : "songlist")) + "/" + (this.id))
  }

  shareable() {
    return true
  }

  collectable() {
    return true
  }

  onBitRateChange() {}

  isChannel() {
    return this.type === "channel"
  }
}
