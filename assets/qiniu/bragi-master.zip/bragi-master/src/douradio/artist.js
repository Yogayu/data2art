import Model from "./model"
import Songlist from "./songlist"

class Artist extends Model {

  url() {
    return 'artist/' + this.id + '/'
  }

  shareUrl() {
    return 'http://douban.fm/' + this.url()
  }

  getSonglist(douradio) {
    if(!this.get('songlist')) {
      return null
    }
    if(this._songlist) {
      return this._songlist
    }
    let response = this.get('songlist')
    this._songlist = Songlist.songlistFromDict(douradio, response)
    return this._songlist
  }

  toggleLike(request) {
    let originLike = this.get('like')

    this.set({
      like: !originLike
    })

    return request({
      url: this.url() + 'like'
      , method: originLike ? 'delete' : 'put'
    }).then((response) => {
      let count = this.get('liked_count') + (originLike ? -1 : 1)
      if(count < 0) {
        count = 0
      }
      this.set({
        liked_count: count
      })

    }, (err) => {
      this.set({
        like: originLike
      })
      return err
    })
  }

}

export default Artist
