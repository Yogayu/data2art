// apiclinet.js
//  apiclient.oauth.js
//  apiclient.web.js
import defaults from "lodash/defaults"
import omits from "lodash/omit"

export default class ApiClient {
  get kbps() {
    return this.options.kbps
  }

  set kbps(value) {
    this.options.kbps = value
  }

  constructor(options) {
    const defaultOptions = {
      from: 'partner'
      , formats: 'aac,mp3'
      , kbps: 64
      , app_name: 'radio_website'
      , version: 100
      , client: 's:mainsite|y:3.0'
    }

    this.ajax = options.ajax
    this.authinfo = options.authinfo || {}

    this.options = defaults(
      omits(options, 'ajax', 'authinfo'),
      defaultOptions
    )

    this.request = this.request.bind(this)

    // for(oName of [
    //   'apikey', 'apisecret', 'ajax', 'apiroot', 'kbps', 'client', 'app_name', 'version'
    // ]) {
    //   if(options[oName]) {
    //     this[oName] = options[oName]
    //   }
    // }
  }

  isLogin() {
    return !!(this.authinfo && this.authinfo.douban_user_id)
  }

  /* @todo more this to songModel */
  getLyric(model) {
    let lyric = model.get('lyric')

    if(lyric) {
      return Promise.resolve(lyric)
    }

    return this.request({
      url: 'lyric',
      data: {
        sid: model.get('sid'),
        ssid: model.get('ssid')
      }
    }).then((response) => {
      model.set('lyric', response.lyric)
      return response.lyric
    })
  }

  request(ajaxOptions) {}

  oauthUrl() {
    return ''
  }

  logout() {
    return ''
  }

}
