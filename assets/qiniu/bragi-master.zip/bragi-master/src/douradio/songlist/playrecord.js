import Collection from "../collection"
import SongModel from "../song"

export class UserPlayRecords extends Collection {
  model = SongModel
  url = 'recent_played_songs'

  constructor(models, options) {
    super(models, options)

    if(options.apiClient) {
      this.apiClient = options.apiClient
    }
  }

  mapSong(attrs) {
    // attrs['sid'] = attrs['id']
    // delete attrs['id']
    // attrs['picture'] = attrs['cover']
    // delete attrs['cover']
    return attrs
  }

  // allow pagination here
  fetch() {
    return this.apiClient.request({
      url: this.url
      , data: {
        start: 0 // init request
        , limit: 100
      }
    }).then((result) => {
      let {total, songs} = result
      this.total = total
      this.reset(songs.map(this.mapSong))
    })
  }

}

export class BannedSongs extends UserPlayRecords {
  url = 'banned_songs'

  mapSong(attrs) {
    return Object.assign({}, super.mapSong(attrs), {
      taste_status: 2
    })
  }

}
