// 用户分享过的歌单
// {type = 2}
import Songlist from "./index"

export default class UserShare extends Songlist {
  constructor(options) {
    super('user_share', options)
  }

  shareable() {return false}

  collectable() {return false}

}
