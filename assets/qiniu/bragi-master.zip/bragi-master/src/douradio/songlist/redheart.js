import Songlist from "./index"
import isNumber from "lodash/isNumber"
import isString from "lodash/isString"
import omit from "lodash/omit"

// there is only one heartlist in the application
export default class HeartList extends Songlist {

  constructor(options) {
    super('redheart', options)
    this.isShuffle = true
  }

  // getSlice(begin, end) {}

  isEditable() {
    return false
  }

  shareable() {return false}

  collectable() {return false}

  fetch() {
    let data = {}
    if(this.info && this.info.updated_time) {
      data = {
        updated_time: this.info.updated_time
      }
    }

    return this.apiClient.request({
      url: 'redheart/basic'
      , data
    }).then((response) => {
      if(!response.songs) {
        return
      }
      this.info = omit(response, 'songs')

      /**
       * @see http://backbonejs.org/index.html#Collection-set
       */
      this.set(response.songs, {
        add: true
        , remove: true
        , merge: true
      })
    })
  }

  addSong(song) {
    let attributes = song.toJSON()
    
    delete attributes.isPlaying
    delete attributes.item_info

    return this.unshift(attributes, {at: 0})
  }

  removeSong(song) {
    if(isString(song) || isNumber(song)) {
      return this.remove(song.toString())
    } else {
      return this.remove(song.id)
    }
  }
}
