import Songlist from "./index"

export default class UserDaily extends Songlist {
  constructor(options) {
    super('user_daily', options)
  }
  shareable() {return false}
  collectable() {return false}
}
