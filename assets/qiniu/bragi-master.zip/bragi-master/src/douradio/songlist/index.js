import Playlist from "../playlist"
import find from "lodash/find"
import findIndex from "lodash/findIndex"
import isNumber from "lodash/isNumber"
import isNaN from "lodash/isNaN"
import isEmpty from "lodash/isEmpty"
import sample from "lodash/sampleSize"
import isArray from "lodash/isArray"
import debounce from "lodash/debounce"
import clone from "lodash/clone"
import map from "lodash/map"
import omit from "lodash/omit"
import filter from "lodash/filter"
import promiseDefer from "promise-defer"

import {
  ERROR_NO_ENOUGH_SONG_IN_PLAYLIST
} from '../consts'


class FixedArray {

  constructor(maxLength = 100) {
    this.maxLength = maxLength
    this.array = []
  }

  push(val) {
    if(!val) {
      return
    }
    if(this.array.length > 100) {
      this.array.shift()
    }
    return this.array.push(val)
  }

  pop() {
    return this.array.pop()
  }

  print() {console.log('PlayHistory:', this.array)}

}

let heartList = null
, sharedList = null
, dailyList = null
, MaxCacheLength = 5
, cachedSonglists = []
, _pushCached = (songlist) => {
  // @todo do not pop current playing programme
  if(cachedSonglists.length > MaxCacheLength) {
    cachedSonglists.shift()
  }
  cachedSonglists.push(songlist)
}

class Songlist extends Playlist {
  /**
   * create a new playlist
   * return Promise(Songlist)
   */
  static create(douradio, {title, description, is_public}) {
    return douradio.apiClient.request({
      url: 'songlist/'
      , method: 'post'
      , data: {title, description, is_public}
    }).then((response) => {
      response.songs = []
      let sl = Songlist.songlistFromDict(douradio, response)
      douradio.mineSonglists.refresh()
      return sl
    })
  }

  static songlistFromDict(douradio, response) {
    // let sl = new Songlist(response.id, {douradio: douradio})
    let sl = Songlist.getSonglist(douradio, response.id)
    sl.fromDict(response)
    return sl
  }

  static getSonglist(douradio, id) {
    id = id.toString()
    let cached = find(cachedSonglists, (p) => p.id == id)

    let currPl = douradio.getCurrentPlaylist()
    if(currPl && !currPl.isChannel() && currPl.id == id) {
      return currPl
    }

    if(cached) {
      return cached
    }

    if(id == 'redheart'){
      let RedHeart = require('./redheart')
      if(!heartList) {
        heartList = new RedHeart({douradio: douradio})
      }
      return heartList
    } else if(id == 'user_share') {
      let UserShare = require('./usershare')
      if(!sharedList) {
        sharedList = new UserShare({douradio: douradio})
      }
      return sharedList
    } else if(id === 'user_daily') {
      let UserDaily = require('./userdaily')
      if(!dailyList) {
        dailyList = new UserDaily({douradio: douradio})
      }
      return dailyList
    }

    let songlist = new Songlist(id, {douradio: douradio})
    _pushCached(songlist)
    return songlist
  }

  constructor(id, options) {
    super(id, options)
    this.isShuffle = false
    this.playRecords = new FixedArray()
    this.sidFetchDefer = null
    this.sidFetchList = []
    this.type = 'songlist'
  }

  isSpecialSonglist() {
    return isNaN(parseInt(this.id))
  }

  getTitle() {
    return (this.info && this.info.title) || ""
  }

  fromDict(response) {
    let songs = map(response.songs, (song, index) => {
      song.index = index
      return song
    })
    this.reset(songs, {douradio: this.douradio})
    this.info = omit(response, 'songs')
    return [this.info, songs]
  }

  fetch(force=false) {
    if(this.request) {
      return this.request
    }

    if(this.info && !isEmpty(this.info) && this.length > 0) {
      return Promise.resolve(this.info, null)
    }

    this.request = this.apiClient.request({
      url: 'songlist/' + this.id + '/',
      data: {
        kbps: this.apiClient.kbps
      }
    }).then((response) => {
      if(response.code && response.msg) {
        return Promise.reject(response.msg)
      }
      return this.fromDict(response)
    })

    return this.request
  }

  isCollect() {
    return this.info.is_collected
  }

  collect() {
    return this.apiClient.request({
      url: 'programme/collect'
      , method: 'post'
      , data: {
        id: this.id
      }
    }).then((response) => {
      if(response.r == 0) {
        this.info.is_collected = true
        this.info.collected_count = response.collected_count
        return response
      } else {
        return Promise.reject(response.msg)
      }
    })
  }

  uncollect() {
    return this.apiClient.request({
      url: 'programme/uncollect'
      , method: 'post'
      , data: {
        id: this.id
      }
    }).then((response) => {
      if(response.r == 0) {
        this.info.is_collected = false
        this.info.collected_count = this.info.collected_count - 1
        return response
      } else {
        return Promise.reject(response.msg)
      }
    })
  }

  toggleCollect() {
    return this.isCollect() ? this.uncollect() : this.collect()
  }

  isCurrent() {
    return this.douradio._playlist == this
  }

  skip() {
    return this.getNextSong()
  }

  toggleLike() {
    let currentSong = this.douradio.currentSong
    , isLike = currentSong.isLike()
    , ev = isLike ? 'unlike' : 'like'
    , hl = this.douradio.getHeartlist()

    if(isLike) {
      hl.removeSong(currentSong)
    } else {
      hl.addSong(currentSong)
    }

    this.douradio.logger.log(
      currentSong,
      this,
      isLike ? 'u' : 'r'
    )

    currentSong.set({
      taste_status: isLike ? 0 : 1
    })

    this.douradio.trigger(ev, this.douradio.currentSong)
    // return currentSong.toggleLike(this.apiClient.request).then(() => {
    //   this.douradio.trigger(ev, this.douradio.currentSong)
    // })
  }

  ban() {
    let currentSong = this.douradio.currentSong

    if(currentSong.isBan()) {
      return this.getNextSong()
    }

    if(!currentSong) {
      return Promise.reject()
    }

    return new Promise((resolve, reject) => {
      currentSong.toggleBan(this.apiClient.request).then(resolve, reject)
    }).then(() => {
      return this.getNextSong()
    })
  }

  onBitRateChange() {
    return this.fetch()
  }

  fetchSong = (sid) => {
    // console.debug('hl:fetch', sid)
    if(!this.sidFetchDefer) {
      this.sidFetchDefer = promiseDefer()
    }
    this.sidFetchList.push(sid)
    this.doFetchSong()
    return this.sidFetchDefer.promise
  }

  doFetchSong = debounce((sid) => {
    if(isArray(this.sidFetchList) && this.sidFetchList.length > 0) {
      let sids = clone(this.sidFetchList)
      , url
      , defer = this.sidFetchDefer

      this.sidFetchList = []
      this.sidFetchDefer = null

      if(this.id === 'redheart') {
        url = 'redheart/songs'
      } else {
        url = 'songlist/' + this.id + '/songs'
      }

      this.apiClient.request({
        url: url
        , method: 'post'
        , data: {
          sids: sids.join('|')
          , kbps: this.apiClient.kbps
        }
      }).then((songs) => {
        // resolved
        this.set(songs, {
          add: false
          , remove: false
          , merge: true
        })
        defer.resolve()
        return songs
      }, function (err) {
        // rejected
        return defer.reject(err)
      })
    } else {
      this.sidFetchList = []
    }
  }, 500)

  toggleShuffle() {
    this.isShuffle = !this.isShuffle
    return this.isShuffle
  }

  /**
   * check songlist is current playing
   * @return {Boolean}
   */
  isCurrent() {
    return this.douradio._playlist === this
  }

  /**
   * Check songlist can be edited by current user
   * @return {Boolean} [description]
   */
  isEditable() {
    let user = this.douradio.options.userinfo
    return (!isEmpty(user)
      && !isEmpty(this.info)
      && user.user_id == this.info.creator.id
    )
  }

  findCurrentSong(models) {
    if(!models) {
      models = this.models
    }

    const FAILEDVALUE = [-1, null]

    if(!this.isCurrent()) {
      return FAILEDVALUE
    }
    let currentSong = this.douradio.currentSong
    if(!currentSong) {
      return FAILEDVALUE
    }

    let index = findIndex(models, (model) => {
      return model.id == currentSong.id
    })

    return [index, currentSong]
  }


  getPlayableList() {
    return this.filter((model) => {
      return model.isPlayable()
    })
  }

  /**
   * Count playable-song in the playlist
   */
  isPlayable() {
    return this.getPlayableList().length > 3
  }

  /**
  * @example
  * get next song:`getSongByOffset(null, 1)``
  * get prev song: `getSongByOffset(null, -1)`
  *
  * @param {Number} baseIndex?
  * @param {Number} offset
  * @param {Boolean} playable=true
  */
  getSongByOffset(baseIndex, offset=1, playable=true) {
    let pl = playable ? pl = this.getPlayableList() : this.models
    , length = pl.length
    , index
    , currSong

    if(length === 0) {
      return Promise.reject('No Song available in songlist to play')
    }

    if(!isNumber(baseIndex)) {
      [baseIndex, currSong] = this.findCurrentSong(pl)
    }

    index = baseIndex + offset
    if(index < 0) {
      index = length - 1
    } else if (index >= length) {
      index = 0
    }

    currSong = pl[index]
    return Promise.resolve(currSong)
  }

  getPrevSong() {
    if(this.length === 0) {
      return Promise.reject( ERROR_NO_ENOUGH_SONG_IN_PLAYLIST )
    }

    if(this.isShuffle) {
      let sid = this.playRecords.pop()
      if(sid) {
        let song = this.get(sid)
        if(song === this.douradio.currentSong) {
          return this.getPrevSong()
        }
        if(song) {
          return Promise.resolve(song)
        }
      }
    }

    return this.getSongByOffset(null, -1)
  }

  // smart shuffle
  getNextSong() {
    let pl = this.getPlayableList()

    if(pl.length === 0) {
      return Promise.reject( ERROR_NO_ENOUGH_SONG_IN_PLAYLIST )
    }

    if(this.isShuffle) {
      let [song, second] = sample(pl, 2)
      if(song === this.douradio.currentSong) {
        song = second
      }
      // TODO song may be undefined here, what do?
      this.pushRecord(song.id)
      return Promise.resolve(song)
    } else {
      return this.getSongByOffset(null, 1).then((song) => {
        this.pushRecord(song.id)
        return song
      })
    }
  }

  /**
   * save songlist info to the server
   * @param  {String}  {title
   * @param  {String}  description
   * @param  {Boolean} is_public}
   * @return {Promise}             Request.Promise
   */
  save({title, description, is_public}) {
    // save the songlist info to the server
    return this.apiClient.request({
      url: 'songlist/' + this.id + '/'
      , method: 'put'
      , data: {
        title, description, is_public
      }
    }).then((response) => {
      this.info = Object.assign(this.info, response)
      this.douradio.mineSonglists.refresh()
      this.trigger('sync change')
    })
  }

  /**
   * delete the songlist
   * @return {Promise}
   */
  delete() {
    return this.apiClient.request({
      url: 'songlist/' + this.id + '/'
      , method: 'delete'
    })
  }

  /**
   * Check if the song is in Songlist
   * @param  {String|Number}  sid [description]
   * @return {Boolean}     [description]
   */
  hasSong(sid) {
    return !!this.get(sid)
  }

/**
 * move song from fIndex to tIndex
 * @param  {number} fIndex from index
 * @param  {number} tIndex target index
 * @return {RequestPromise}
 */
  moveFrom(fIndex, tIndex) {
    if(fIndex === tIndex) {
      return
    }

    // should be undefined when placing item at the end of the songlist
    let before_item_id = tIndex < (this.models.length - 1) ? this.models[tIndex].getItemId() : undefined

    let [removed, ] = this.models.splice(fIndex, 1)
    this.models.splice(tIndex, 0, removed)

    // put item1(id=item_id) before item2(id=before_item_id)
    this.request = this.apiClient.request({
      url: 'songlist/' + this.id + '/'
      , method: 'post'
      , data: {before_item_id: before_item_id, item_id: removed.getItemId()}
    }).then((response) => {
      this.request = false
      return
    }, (err) => {
      /**
       * @todo restore default order, report error and etc.
       */
    })

    this.trigger('sort')
  }

  /**
   * add or edit comment of a song
   * @param {String|Number} sid
   * @return {RequestPromise(Song)}
   */
  editComment(sid, comment) {
    let song = this.get(sid)
    if(!song) {
      return Promise.reject('Song not found!')
    }

    return this.apiClient.request({
      url: 'songlist/' + this.id + '/songs/' + song.id + '/'
      , method: 'patch'
      , data: {comment: comment}
    }).then((response) => {
      song.set({
        item_info: {
          comment: response.comment
          , created_time: response.created_time
        }
      })
      return song
    })
  }

  /**
   * @todo
   * add song to the songlist
   * @param {String|Number} sid
   * @return {RequestPromise}
   */
  addSong(sid, comment="") {
    return this.apiClient.request({
      url: 'songlist/' + this.id + '/songs/'
      , method: 'post'
      , data: {
        id: this.id
        , song_id: sid
      }
    }).then((r) => {
      let song = new this.model({
        sid: r.song_id
      })
      this.add(song)
      return song
    })
  }

/**
 * removeSong from Songlist
 * @param  {String|Number} sid
 * @return {Promise(Song)} return a promise with removed song
 */
  removeSong(sid) {
    let model = this.get(sid)

    return this.apiClient.request({
      url: 'songlist/' + this.id + '/songs/' + sid + '/'
      , method: 'delete'
    }).then((response) => {
      // this.trigger('remove', model)
      return this.remove(model)
    })
  }

  /**
   * push playrecord when song in this songlist finish playing
   * @param {String|Number} sid
   */
  pushRecord(sid) {
    return this.playRecords.push(sid)
  }

  /**
   * get creator's other songlists
   * @return {[]Songlist} array of songlists
   */
  getCreatorSonglists() {
    return this.apiClient.request({
      url: 'songlist/user/' + this.info.creator.id + '/'
    }).then((response) => {
      // reject current songlist
      return filter(response.songlists, (songlist) => {
        return songlist.id != this.id
      })
    })
  }

}

export default Songlist
