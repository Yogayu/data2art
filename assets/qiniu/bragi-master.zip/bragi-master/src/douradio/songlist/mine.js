// Created Songlists

/**
 * usage `douradio.createdSonglists.getAll().then((songlists) => {
 *   return songlists
 * })`
 *
 * douradio.createdSonglists.on('change', function () {
 *   // things you want to do
 * })
 *
 * @emits `change:mine` in douradio
 *
 * */

export default class MineSonglists {

  constructor(douradio) {
    this.douradio = douradio
    this.models = []
  }

  refresh() {
    // refresh the whole list
    if(this.request) {
      return this.request
    }

    this.request = this.douradio.apiClient.request({
      url: 'songlist/mine'
    }).then((response) => {
      this.request = null
      this.models = response.songlists
      this.douradio.trigger('change:mine-songlist')
    })
  }

  getAll() {
    if(this.request) {
      return this.request
    }

    if(this.models && this.models.length > 0) {
      return Promise.resolve(this.models)
    } else {
      return this.refresh()
    }
  }

}
