import React from 'react'
import classnames from "classnames"
import styles from "./button.module.scss"

const borderWidth = 1

export default function Button (props) {
  let color = props.color
  , borderColor = props.borderColor || color

  return <button
    {...props}
    className={classnames('button', styles.button, props.className)}
    style={Object.assign({}, {
      color: color
      , borderColor: borderColor
      , height: props.height
      , lineHeight: (props.height - 2 * borderWidth) + 'px'
      , padding: '0 10px'
    }, props.style)}
  ></button>
}
