import React from "react"
import {
  stackBlurCanvasRGBA
  , stackBlurImage
} from "./lib"

export default class Blur extends React.Component {

  static defaultProps = {
    blurRadius: 20
    , width: 680
    , height: 680
  }

  blurImage() {
    try {
      let canvas = this.refs.canvas
      , context = canvas.getContext('2d')
      , bg = new Image()
      bg.crossOrigin = 'Anonymous'
      bg.src = this.props.src

      canvas.height = this.props.height
      canvas.width = this.props.width

      bg.onload = () => {
        let {width, height} = canvas
        context.save()

        // context.beginPath()
        // context.arc(
        //   width / 2, height / 2, width / 2, 0
        //   , Math.PI * 2, true
        // )
        // context.closePath()

        context.clip()

        context.drawImage(bg, 0, 0, width, height)

        // context.beginPath()
        // context.arc(
        //   0, 0, width / 2, 0
        //   , Math.PI * 2, true
        // )
        // context.clip()
        // context.closePath()
        //
        context.restore()

        // stackBlurImage(
        //   bg,
        //   canvas,
        //   this.props.blurRadius,
        //   false
        // )
        stackBlurCanvasRGBA(
          canvas, 0, 0, width, height, this.props.blurRadius
        )
      }
    } catch (e) {
      console.error(e)
    }
  }

  componentDidMount() {
    this.blurImage()
  }

  componentDidUpdate() {
    this.blurImage()
  }

  render() {
    let {width, height} = this.props

    return <canvas
      ref="canvas"
      {...this.props}
    ></canvas>
  }

}
