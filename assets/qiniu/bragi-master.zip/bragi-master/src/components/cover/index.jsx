/**
 * @todo move playing-cover to here
 */
import "./cover.scss"
import extend from "lodash/extend"
import classnames from "classnames"
import IconPlay from "icons/icon-play"
import IconPlaying from "icons/icon-playing-wave"
import React from "react"

let Cover = ({
  src
  , size=42
  , rounded=false
  , style=null
  , onClick=null
  , onPlay=null
  , isPlaying=false
  , className="cover"
  , children=null
  , iconSize=18
}) => {

  return <div
    onClick={onClick}
    className={classnames('cover', className)}
    style={extend({
      height: size
      , width: size
      , backgroundImage: src ? `url(${src})` : ''
      , borderRadius: rounded ? '50%' : 0
      , display: 'inline-block'
    }, style || {})}>
      {children}
      
      {isPlaying ? <div style={{
        borderRadius: rounded ? '50%' : 0
        , lineHeight: size + 'px'
        , height: size
        , display: 'block'
      }} className="playable-overlay">
        <IconPlaying size={iconSize} color={'#FFFFFF'}></IconPlaying>
      </div> : null}

      {onPlay && !isPlaying ?
        <div style={{
          borderRadius: rounded ? '50%' : 0
          , lineHeight: size + 'px'
          , height: size}}
          className="playable-overlay"
          onClick={onPlay}>
          <IconPlay
            color={'#FFFFFF'}
            size={iconSize}
            center={true}
          ></IconPlay>
        </div> : null}
  </div>
}

export default Cover
