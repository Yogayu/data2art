import React from 'react'
import styles from './placeholder.module.css'

export default class PlaceHolder extends React.Component {

  render () {
    return <div
      className={styles.animatedBackground}
      style={{
        width: this.props.width
        , height: this.props.height
        , display: 'inline-block'
        , ...this.props.style
      }}
    >{this.props.children}</div>
  }

}

export class PlaceHolderAlbumCover extends React.Component {

  static defaultProps = {
    size: 144
  }

  renderCircle(size, color, border) {
    return <div style={{
      position: 'absolute'
      , top: this.props.size / 2 - size / 2
      , left: this.props.size / 2 - size / 2
      , width: size
      , height: size
      , backgroundColor: color
      , borderColor: border
      , borderWidth: 1
      , borderStyle: 'solid'
      , borderRadius: '50%'
    }}></div>
  }

  render () {

    return <PlaceHolder style={{
      border: '1px solid #eaeaea'
      , backgroundColor: '#e0e0e0'
      , position: 'relative'

      , width: this.props.size
      , height: this.props.size

      , ...this.props.style
    }}>
      {this.renderCircle(this.props.size * 0.75, '#f7f7f7', '#eaeaea')}
      {this.renderCircle(this.props.size * 0.1543, '#e0e0e0', '#eaeaea')}
    </PlaceHolder>

  }

}
