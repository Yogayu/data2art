import React from "react"

export default class OverflowText extends React.Component {

  static defaultProps = {
    lineHeight: 1.2
    , fontSize: 12
    // config
    , maxLine: 1
  }

  render() {
    let {fontSize, lineHeight, children} = this.props
    , lineHeightPx = Math.floor(parseInt(fontSize * lineHeight))

    return <div
      style={Object.assign({}, {
        display: 'inline-block'
        , maxHeight: lineHeightPx * this.props.maxLine
        , lineHeight: this.props.lineHeight
        , fontSize: this.props.fontSize
      }, this.props.style)}
      className={this.props.className}
    >
      {children}
    </div>
  }

}
