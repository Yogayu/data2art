import React from "react"
// step1: render the original

export default class OverflowText extends React.Component {

  static defaultProps = {
    lineHeight: 1
    , fontSize: 12
    // config
    , maxLine: 1
  }

  constructor(props) {
    super(props)
    this.state = {
      enable: false
      , height: 'auto'
    }
  }

  componentDidMount() {
    let {
      height,
      width,
      top,
      left
    } = this.refs.root.getBoundingClientRect()
    , {fontSize, lineHeight} = this.props
    // Calculate lineHeight in px
    , lineHeightPx = Math.floor(parseInt(fontSize * lineHeight))

    // ok, Check how many lines displayed
    , linesCount = Math.floor(height / lineHeightPx)

    if(linesCount > this.props.maxLine) {
      this.setState({
        enable: true
        , height: lineHeightPx * this.props.maxLine
        , originalTop: top
        , originalLeft: left
        , originalHeight: height
        , originalWidth: width
      })
    }
  }

  componentDidUpdate() {
  }

  renderHoverBox(style) {
    let newStyle = Object.assign({}, style, {
      left: this.state.originalLeft

      , top: this.state.originalTop - (this.state.originalHeight - this.state.height)

      , height: this.state.originalHeight
      , width: this.state.originalWidth

      , position: 'fixed'
      , background: 'rgba(249, 249, 249, 0.5)'
      , zIndex: 1000
      , transition: 'all 1s linear'
    })

    return <div style={newStyle}>
      {this.props.children}
    </div>
  }

  render() {
    return <div
      ref="root"
      className={this.props.className}
      style={Object.assign({}, this.props.style || {}, {
        display: 'inline-block'
        , lineHeight: this.props.lineHeight
        , fontSize: this.props.fontSize
        , height: this.state.height + 1
        , overflow: 'hidden'
      })}

      onMouseEnter={ this.state.enable ? (e) => {
        this.setState({hover: true})
      } : null}

      onMouseLeave={this.state.enable ? (e) => {
        this.setState({hover: false})
      } : null}
    >
      {this.state.enable && this.state.hover ?
        this.renderHoverBox() : this.props.children}
    </div>
  }

}
