import React from 'react'
import shallowCompare from 'react/lib/shallowCompare'

let Z_HIGHEST = 100000

export default class Snackbar extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      offsetX: 0
    }
  }

  componentDidMount() {
    this.autoCenter()
  }

  componentDidUpdate(prevProps, prevState) {
    this.autoCenter()
  }

  autoCenter () {
    let {width, } = this.refs.root.getBoundingClientRect()

    this.setState({
      offsetX: width / -2
    })

  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  render() {
    return <div
      ref="root"
    style={{
      height: 30
      , lineHeight: '30px'
      , borderRadius: 15
      , backgroundColor: '#62646c'
      , textAlign: 'center'
      , fontSize: 13
      , fontWeight: 400
      , color: '#ffffff'
      , padding: '0 20px'
      , position: 'fixed'
      , bottom: '30%'
      , left: '50%'
      , marginLeft: this.state.offsetX
      , zIndex: Z_HIGHEST
    }}>{this.props.children}</div>
  }

}
