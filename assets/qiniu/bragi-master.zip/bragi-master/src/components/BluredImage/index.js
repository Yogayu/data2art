import React from 'react'

export const supportFilter = (function () {
  // edge browser has bug with css3 filter
  let supportFilter = document.body.style.filter !== undefined
  , notIE = document.documentMode === undefined
  , notEdge = navigator.userAgent.indexOf('Edge') < 0
  return supportFilter && notIE && notEdge
})()

// supportFilter = false
// console.debug('supportFilter', supportFilter)


export default function BluredImage ({src, style, className}) {
  if(supportFilter) {
    return <img
      className={className}
      src={src}
      style={style}
      height={222}
      width={222}
    ></img>
  } else {
    return null
  }
}
