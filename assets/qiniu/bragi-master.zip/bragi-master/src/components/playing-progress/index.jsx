import styles from "./progress.module.scss"
import React from "react"
import clns from "classnames"

export default class PlayingProgress extends React.Component {

  static defaultProps = {
    loaded: 0
    , played: 0
    , barColor: '#6BBD7A'
    , bgColor: ''
  }

  componentDidMount() {
    this.width = this.refs.root.offsetWidth
  }

  render() {
    return <div
      ref={'root'}
      className={clns(styles.progress, this.props.className)}
      style={this.props.style}
    >
      <div style={{
        display: 'relative'
        , overflow: 'hidden'
        , display: 'block'
        , position: 'absolute'
        , width: '100%'
        , height: '100%'
        , left: 0
        , top: 0
        , backgroundColor: this.props.bgColor
      }}>
        <div className={styles.progressBar} style={{
          width: '' + this.props.loaded + '%'
          // , backgroundColor: '#CEECD2'
          , backgroundColor: '#C4C4C4'
        }}></div>

        <div className={styles.progressBar} style={{
          width: '100%'
          , left: '-' + (100 - this.props.played) + '%'
          , backgroundColor: this.props.barColor || '#6BBD7A'
        }}></div>
      </div>
      
      {this.props.children}
    </div>
  }
}
