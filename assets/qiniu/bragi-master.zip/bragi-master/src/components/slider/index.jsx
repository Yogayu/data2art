import "./slider.scss"

import React from "react"
import ReactDOM from "react-dom"
// import extend from 'lodash/object/extend'
import classnames from "classnames"
import isNumber from "lodash/isNumber"
import Draggable from "react-draggable"

// import {screenPosition} from 'utils'

// const constrain = (snap) => {
//   const constrainOffset = (offset, prev) => {
//     var delta = offset - prev
//     if (Math.abs(delta) >= snap) {
//       return prev + parseInt(delta / snap, 10) * snap
//     }
//     return prev
//   }
//   return (pos) => {
//     return {
//       top: constrainOffset(pos.top, pos.prevTop)
//       , left: constrainOffset(pos.left, pos.prevLeft)
//     }
//   }
// }

/**
 * this Slider is port from material-slider
 *  @example <Slider
      name="volume-slider"
      className="ui-slider"
      defaultValue={douradio.getVolume()}
      value={douradio.getVolume()}
      min={0}
      max={100}
      onChange={this.onVolumeChange.bind(this)}
      style={{
        width: 100,
        height: 10,
        marginTop: 0,
        marginBottom: 0
      }}
    ></Slider>
 */
export default class Slider extends React.Component {

  static defaultProps = {
    zIndex: 0
    , style: {}
    , onChange: null
    , min: 0
    , max: 100
    , value: 0
    , width: 100
    , height: 14
    // , defaultValue: 0
    , className: 'ui-slider'
    , name: 'slider'
    , hide: true
  }

  getLeft() {
    if(this.state && isNumber(this.state.left)) {
      return this.state.left
    }

    return this.props.value / (
      this.props.max - this.props.min
    ) * this.props.width
  }

  afterSlide(event, left) {
    if(left < 0) {
      left = 0
    } else if(left > this.props.width) {
      left = this.props.width
    }

    let value = this.props.min + (
      this.props.max - this.props.min
    ) * (left / this.props.width)

    this.setState({left: left})

    return this.props.onChange(event, value)
  }

  onStart(event, ui) {
    return
    // console.log(
    //   '<Event name=onStart ',
    //   "Position=", ui,
    //   "/>")
  }

  onDrag(event, ui) {
    console.log(
      '<Event name=onDrag ',
      "Position=", ui, "/>")

    let position = this._getXValue(event.pageX)
    this.afterSlide(event, position)

    // return this.afterSlide(event, this._getXValue(ui.x))
  }

  onStop(event, ui) {
    return
    // console.log(
    //   '<Event name=onStop ',
    //   "Position=", ui.position, "/>")
  }

  _getXValue(clientX) {
    let root = ReactDOM.findDOMNode(this)
    // , {left} = screenPosition(root)
    let {left} = root.getBoundingClientRect()
    console.log(clientX, left)
    return clientX - left
  }

  onClick(event) {
    event.preventDefault()
    // let root = ReactDOM.findDOMNode(this)
    // let {left} = screenPosition(root)
    // let position = (event.pageX - left)
    let position = this._getXValue(event.pageX)
    this.afterSlide(event, position)

    // cause Draggable didn't listen to the onPropChangeEvent, so you need a
    // this.forceUpdate()
  }

  // componentWillReceiveProps(nextProps) {}

  render() {
    let handlerWidth = 5
    , handlerHeight = 10
    , width = this.props.width
    , height = this.props.height
    , barHeight = 2
    , barBackground = '#e5e5e8'
    , barColor = '#979797'

    return <div
      className={classnames(
        "slider"
        , this.props.className
        , {'hide': this.props.hide})}
      style={{
        width: width + handlerWidth
        , height: height
        , marginRight: this.props.hide ? -1 * (width + handlerWidth) : 0
      }}
      onClick={this.onClick.bind(this)}
    >
      <div
        className="bar-container"
        style={{
          display: 'block'
          , width: width
          , height: barHeight
          , backgroundColor: barBackground
          , marginTop: (height - barHeight) / 2
        }}
      >

        <div
          className="bar"
          style={{
            backgroundColor: barColor
            , height: barHeight
            , width: this.getLeft()
          }}
        ></div>

      </div>

      <Draggable
        ref={'draggable'}
        axis="x"
        handle=".handle"
        zIndex={this.props.zIndex}
        bounds="parent"
        onStart={this.onStart.bind(this)}
        onDrag={this.onDrag.bind(this)}
        onStop={this.onStop.bind(this)}
        position={{x: this.getLeft(), y: 0}}
      >

        <div className="handle" style={{
          top: (height - handlerHeight) / 2
          // , left: this.getLeft()
          , height: handlerHeight
          , width: handlerWidth
        }}></div>

      </Draggable>
    </div>
  }
}
