// React Douban AD
import reqwest from "reqwest"
import React from "react"
import douradio from "douradio"
import get from "lodash/get"
import shallowCompare from 'react/lib/shallowCompare'

export default class DoubanAD extends React.Component {

  static defaultProps = {
    unit: 'dale_fm_channel'
    , adSource: '//erebor.douban.com'
    // , width: 950
    // , height: 90
    , uid: null
    , bid: null
    , onUpdate: function (width, height) {}
  }

  getHeight() {
    return this.state.height || this.props.height || 0
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  componentDidMount() {
    // this.getAd()
    douradio.once('playing', this.getAd.bind(this), this)
    douradio.on('skip', this.getAd.bind(this), this)
  }

  componentWillUnmount() {
    this.request = null
    douradio.off(null, null, this)
  }

  shouldComponentUpdate(nextProps, nextState) {
    return this.state.html != nextState.html
  }

  logError() {
    console.error('AD Load Error')
  }

  buildCrtr() {
    // Channel: 4
    // Songlist: 10
    let pl = douradio._playlist
    if(!pl) {
      return null
    }

    if(pl.isChannel()) {
      return ['4', pl.id].join(':')
    } else {
      return ['10', pl.id].join(':')
    }
  }

  getAd() {
    //  http://erebor.douban.com/?unit=dale_fm_channel&uid=&bid=%2FD%2F%2F0d1mVEI&crtr=4%3A-10%7C3%3A%2Frotate_ad%3Fcid%3D-10&ts=1456299711903&prv=&debug=false&callback=erebor_64680B4FCDF1468D934B6FC3FC875064
    this.request = reqwest({
      url: this.props.adSource
      , type: 'jsonp'
      , data: {
        unit: this.props.unit
        , uid: this.props.uid || get(douradio, ['options', 'userinfo', 'user_id'])
        , bid: this.props.bid || get(douradio, ['options', 'bid'])
        , crtr: this.buildCrtr()
        , ts: (new Date()).getTime()
        , prv: ''
        , debug: false
      }
    }).then((response) => {
      if(!this.request) {
        return
      }
      this.request = null

      if(response.html) {
        this.props.onUpdate(response.width, response.height)
      } else {
        this.props.onUpdate(0, 0)
      }

      this.setState(response)

    }, this.logError)
  }

  componentDidUpdate() {
    if(this.state.html) {
      let frame = this.refs.frame
      if(!frame) {return}
      frame.contentWindow.document.open()
      frame.contentWindow.document.write(this.state.html)
      frame.contentWindow.document.close()
    }
  }

  render() {
    return <div
      className={this.props.className}
      style={this.props.style}
    >
      {this.state.html ? <iframe
        ref="frame"
        height={this.state.height}
        width={this.state.width}
        frameBorder="0"
        style={{
          display: 'block'
          , margin: '0 auto'
        }}
      ></iframe> : null}
      {this.props.children}
    </div>
  }

}
