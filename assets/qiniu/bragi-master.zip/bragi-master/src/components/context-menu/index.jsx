// 加入已有歌单
require("./context-menu.scss")
import React from "react"
import ReactDOM from "react-dom"
import Overlay from "ui/overlay"

export class ContextMenu extends React.Component {

  static defaulProps = {
    className: 'context-menu'
  }

  constructor() {
    super()
    // this.state = {offsetX: 0, offsetY: 0}
  }

  componentDidMount() {
    // edge detection
    // this.edgeDetection()
  }

  edgeDetection() {
    let node = ReactDOM.findDOMNode(this)
    // right
    let ww = window.innerWidth
    // , wh = window.innerHeight
    , nw = node.offsetWidth
    // , nh = node.offsetHeight
    , offsetX = 0
    , offsetY = 0

    // overflow right
    if((this.props.x + nw) > ww) {
      offsetX = ww - this.props.x - nw - 10
    }

    this.setState({
      offsetX: offsetX
      , offsetY: offsetY
    })
  }

  onRightClick(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  onClick(e) {
    e.stopPropagation()
  }

  render() {
    return <Overlay
      className={this.props.className || 'context-menu'}
      onClick={this.onClick.bind(this)}
      onContextMenu={this.onRightClick.bind(this)}
      {...this.props}
    >
    {Array.isArray(this.props.children) ?
      <ul>{this.props.children}</ul>
      : this.props.children
    }
    </Overlay>
  }

}

export class ContextMenuItem extends React.Component {
  // todo, menu with submenus

  static defaultProps = {
    autoClose: true
  }

  onClick(e) {
    e.preventDefault()
    e.stopPropagation()

    if(this.props.autoClose) {
      window.app.hideContextMenu()
    }

    if(this.props.onClick) {
      this.props.onClick.call(null, e, this)
    } else if(this.props.href) {
      window.open(this.props.href, this.props.target)
    }
  }

  render() {
    return <li onClick={this.onClick.bind(this)}>
      {this.props.icon ? <i className={"icon icon-" + this.props.icon}></i> : null}
      {this.props.title}
      {this.props.children}
    </li>
  }

}

export class ContextMenuLine extends React.Component {
  render() {
    return <li className="line"></li>
  }
}
