import "./cover.scss"
import React from "react"
import Loading from "ui/loading"

import extend from "lodash/extend"

// {ReactCSSTransitionGroup} = React.addons

export default class PlayingCover extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      loaded: false
      , src: props.src
      , prevSrc: props.src
    }
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.src != this.props.src){
      this.setState({
        loaded: false
        , src: nextProps.src
        , prevSrc: this.props.src
      })
    }
  }

  onLoad(){
    this.setState({loaded: true})
  }

  isLoading() {
    return this.props.loading || !this.state.loaded
  }

  // componentDidUpdate: (prevProps, prevState, prevContext) ->

  render() {
    let imgSrc
    if(this.state.loading) {
      imgSrc = this.state.src
    } else {
      if(this.state.loaded) {
        imgSrc = this.state.src
      } else {
        imgSrc = this.state.prevSrc
      }
    }

    return <div
      className="playing-cover"
      onClick={this.props.onClick}
      style={{
        width: this.props.size
        , height: this.props.size
      }}
    >
      <img
        onLoad={this.onLoad.bind(this)}
        key="img"
        ref="img"
        src={this.state.src}
        alt=""
        width={0}
        height={0}
      />

      <div
        className="cover"
        style={extend({
          width: this.props.size
          , height: this.props.size
          , backgroundImage: imgSrc && 'url(' + imgSrc + ')'
          , opacity: this.isLoading() ? 0.05 : 1
          , borderRadius: (this.props.round ? '50%' : '0')
        }, this.props.style)}></div>

      {this.isLoading() ?
        <Loading key="loading" className="center"></Loading> : null}

      {this.props.playButton ?
        <i className={this.props.paused ? "icon icon-play" : "icon icon-pause"}></i>
        : null}
      {this.props.children}
    </div>
  }
}

PlayingCover.defaultProps = {
  paused: true
  , src: ''
  , size: 200
  , style: {}
  , round: true
  , playButton: false
}
