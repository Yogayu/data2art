/**
 * this module contains .lrc parser
 */
import flatten from "lodash/flatten"
import sortBy from "lodash/sortBy"
import filter from "lodash/filter"
import map from "lodash/map"

let getLyricMetaData = (lyric) => {
  let result = lyric.match(
    /\[(ar|ti|al|by|offset)\:(.*)\]/
  )

  if(result && result.length === 3){
    return [result[1], result[2]]
  } else {
    return null
  }
}

let getLyricTime = (lyric, times=[]) => {
  /* result = lyric.match(///
    \[
      (\d{2}) # 匹配分钟数
      \:
      (.*?) # 匹配秒数， 支持 22, 22.12, 22.134 等等, 后面加问号是非贪婪模式
    \]
    (.*)
  ///) */
  let result = lyric.match(/\[(\d{2})\:(.*?)\](.*)/)

  if(result) {
    let [, minutes, seconds, sublyric] = result
    let milliseconds = parseInt(
      (parseInt(minutes, 10) * 60 + parseFloat(seconds)) * 1000,
      10
    )
    times.push(milliseconds)
    return getLyricTime(sublyric, times)
  } else {
    return [
      times,
      lyric
    ]
  }
}

/**
 * parse lyrics
 * @param  {String} lyrics raw text / or .lrc format lyrics
 * @return {Object}
 *  @property {[]{time, lyrics}} lines
 *  @property {boolean} isStaticLyric
 */
let parse = (lyrics) => {
  if(lyrics.trim().length == 0) {
    return {lines: []}
  }

  // lines = { time: 0, text: 'xxx' }
  let isStaticLyric = true
  , offset = 0

  let lines = lyrics.split('\n').map((originalLyric, index) => {
    let metadata = getLyricMetaData(originalLyric)
    if(metadata){
      let [label, value] = metadata
      if(label === 'offset') {
        offset = parseInt(value, 10)
      }
      return {lyric: null}
    }

    let [times, lyric] = getLyricTime(originalLyric)

    if(times.length === 0) {
      return {lyric: lyric}
    } else {
      isStaticLyric = false
      return map(times, (time) => {
        return {time: time, lyric: lyric}
      })
    }
  })

  if(offset > 0) {
    console.debug('have offset', offset)
  }

  lines = map(filter(
    sortBy(flatten(lines), 'time'),
    (line) => !!line.lyric
  ), (line) => {
    if(line.time) {
      line.time = line.time + offset
    }
    return line
  })
  // lines = _.chain(lines).flatten().sortBy('time').filter((line)->
  //   return !!line.lyric
  // ).map((line) ->
  //   if(line.time)
  //     line.time = line.time + offset
  //   return line
  // ).value()

  return {
    lines,
    isStaticLyric: isStaticLyric,
  }
}

export default parse
