import "./lyrics.scss"

import React from "react"
import ReactDOM from "react-dom"
import Loading from "ui/loading"
import TweenLite from "gsap/TweenLite"
import lang from "i18n"
import Scroller from "ui/scrollbar"
import parseLyrics from "./parser"
import isNull from "lodash/isNull"
import sortedIndexBy from "lodash/sortedIndexBy"
import shallowCompare from "react/lib/shallowCompare"

/**
# @todo try the scrollTo plugin of green_sock
# @todo lyric tooltip
#
# {offset: '', modify: [{time: xxx, content: xxx}, ...]]
#
# method: share
# method: replace(upload a new lyric)
# show contributer: uid
# LyricTooltip = React.createClass {
# }
**/

export default class Lyrics extends React.Component {

  static defaultProps = {
    lyric: null
  }

  constructor(props) {
    super(props)
    this.state = this.props.lyric ? parseLyrics(this.props.lyric) : {lines: []}
  }

  componentWillReceiveProps(props) {
    if(!props.lyric) {
      return this.setState({
        lines: []
      })
    }

    if(props.lyric != this.props.lyric){
      this.setState(parseLyrics(props.lyric))
    }
  }

  componentDidMount() {
    this.props.douradio.on('playing', (currentAudio) => {
      let currentIndex = sortedIndexBy(this.state.lines, {
        time: currentAudio.position
      }, 'time') - 1
      this.setState({
        index: currentIndex
      })
    }, this)
  }

  shouldComponentUpdate(p, s) {
    return shallowCompare(this, p, s)
  }

  componentWillUnmount() {
    this.props.douradio.off(null, null, this)
  }

  componentDidUpdate() {
    if(this.state.isStaticLyric){
      return
    }
    let scroller = this.refs.scroller
    if(! scroller) {
      return
    }
    let node = ReactDOM.findDOMNode(scroller)
    , currentNode = ReactDOM.findDOMNode(this.refs.current)

    if(currentNode) {
      let pos = currentNode.offsetTop - node.offsetHeight / 2
      if(pos < 0) {
        pos = 0
      }
      scroller.scrollTo(pos, 1000)
    }
  }

  onScroll(e) {
    e.stopPropagation()
  }

  render() {
    let currentIndex = this.state.index || -1

    if(isNull(this.props.lyric)){
      return <div className={this.props.className}>
        <Loading className="lyric-loader" style={{
          left: 104
          , top: 155
        }}>{lang('LYRIC_LOADING')}</Loading>
      </div>
    }

    if(this.state.lines.length == 0){
      return <div className={this.props.className}>
        <div className="no-lyric">{lang('LYRIC_NO_FOUND')}</div>
      </div>
    }

    // <div className={this.props.className} onWheel={this.onScroll}>
    return <Scroller ref="scroller" onWheel={this.onScroll} className={this.props.className}>
      {this.state.isStaticLyric && this.state.lines.length > 5
        ? <p>{lang('LYRIC_NO_SUPPORT_SCROLL')}</p> : null}
      {this.state.lines.map((line, index) => {
        if(currentIndex == index){
          return <p key={index} className="on" ref="current">{line.lyric}</p>
        } else {
          return <p key={index}>{line.lyric}</p>
        }
      })}
    </Scroller>
  }
}
