import "./tooltip.scss"
import React from "react"
import classnames from "classnames"
import shallowCompare from "react/lib/shallowCompare"
import capitalize from "lodash/capitalize"

export default class Tooltip extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      offsetX: 0
      , offsetY: 0
      , x: 0
      , y: 0
      , style: {}
    }
  }

  static defaultProps = {
    x: 0 // middle of an element
    , y: 0 // top of an element
    , direction: 'top'
    , backgroundColor: '#4a4a4a'
    , color: null
    , visiable: true
  }

  static propTypes = {
    x: React.PropTypes.number
    , y: React.PropTypes.number

    /* direction should be 'top', 'bottom', 'left', 'right'
                            [v]      [^]      []>     <[]
    */
    , direction: React.PropTypes.oneOf(['bottom', 'right', 'left', 'right']) // left and right is currently not support
    , backgroundColor: React.PropTypes.string
    , color: React.PropTypes.string
    , visiable: React.PropTypes.bool
  }

  shouldComponentUpdate(props, state) {
    return shallowCompare(this, props, state)
  }

  componentDidMount() {
    this.fixPosition()
  }

  componentDidUpdate() {
    this.fixPosition()
  }

  fixPosition(){
    let el = this.refs.root
    , offsetX = 0, offsetY = 0
    , direction = this.props.direction

    if(direction === 'top') {
      offsetY = -1 * el.offsetHeight
    } else if (direction === 'bottom') {
      offsetY = 0
    } else if (direction == 'left') {
      offsetX = el.offsetWidth
    } else if (direction == 'right') {
      offsetX = 0
    }

    offsetX = -1 * el.offsetWidth / 2

    this.setState({offsetX, offsetY})
  }

  render() {
    let {x, y, direction, children, visiable, backgroundColor, color} = this.props
    , {offsetX, offsetY} = this.state
    /**
     * this is a es2015 feature
     * @see https://babeljs.io/docs/learn-es2015/#enhanced-object-literals
     */
    , arrowStyle = Object.assign({}, {
      [`border${capitalize(direction)}Color`]: backgroundColor
    }, this.props.arrowStyle), innerStyle = Object.assign({
      'color': color
      , 'backgroundColor': backgroundColor
    }, this.props.innerStyle), rootStyle = Object.assign({
      left: (x + offsetX) || 0
      , top: (y + offsetY) || 0
    }, this.props.style || {})

    return <div ref="root" className={classnames(
      'tooltip', 'tooltip-' + direction,
      {'in': visiable}
    )} style={rootStyle} role="tooltip">
      <div className="tooltip-arrow" style={arrowStyle}></div>
      <div className="tooltip-inner" style={innerStyle}>{children}</div>
    </div>
  }
}
