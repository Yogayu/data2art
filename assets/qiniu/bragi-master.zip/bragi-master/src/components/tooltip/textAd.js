import styles from "./textAd.module.css"
import React from 'react'
import Link from 'ui/link'


export default class TextAd extends React.Component {

  static defaultProps = {
    onDisplay: function () {}
    , onClick: function () {}
  }

  componentDidMount() {
    this.props.onDisplay()
  }

  componentDidUpdate() {
    this.props.onDisplay()
  }

  handleClick() {
    window.open(this.props.url, {target: '_blank'})
    this.props.onClick()
  }

  render() {
    let {
      display
      , url
      , text
      , theme = "default"
    } = this.props

    if (!display || !url || !text ) {
      return null
    }

    return (
      <div className={styles.ad + " " + styles["theme-" + theme]}>
        <a
          onClick={this.handleClick.bind(this)}
          href={url}
          className={styles.text}
        >
          {text}
        </a>
        <div className={styles.tip}>AD</div>
      </div>
    )
  }

}
