import React from "react"
import Tooltip from "./index"
import Icon from "ui/icon"
import ReactDOM from "react-dom"
import isString from "lodash/isString"
import shallowCompare from 'react/lib/shallowCompare'

export default class TitleWithTooltip extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      hover: false
      , left: 0
      , top: 0
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  toggleHover(value) {
    // console.debug('toggle', value)
    let iconDom = ReactDOM.findDOMNode(this.refs.icon)

    return this.setState({
      hover: value
      , left: iconDom.offsetLeft + iconDom.offsetWidth
      , top: iconDom.offsetTop
    })
  }

  render() {
    let {title, icon, className} = this.props
    , tooltipStyle = {
      display: 'inline-block'
      , position: 'absolute'
      , left: this.state.left
      , top: this.state.top - 2
      , borderRadius: 2
    }

    if(isString(icon)) {
      icon = <Icon i={icon}
        style={{
          position: 'relative'
          , top: -2
        }}></Icon>
    }

    return <h3
      className={className || "title"}
      onMouseLeave={this.toggleHover.bind(this, false)}
      style={{
        position: 'relative'
      }}
    >
      <span onMouseEnter={this.toggleHover.bind(this, true)}>{title}</span>

      <span
        onMouseEnter={this.toggleHover.bind(this, true)}
        ref="icon"
        style={{
          marginLeft: 6
        }}
      >
        {icon}
      </span>

      {this.state.hover ?
        <Tooltip
          direction="right"
          visiable={true}
          backgroundColor={'rgb(106, 189, 122)'}
          style={tooltipStyle}
          {...this.props.tooltipProps}
        >
          {this.props.tooltip}
        </Tooltip> : null
      }
    </h3>
  }
}
