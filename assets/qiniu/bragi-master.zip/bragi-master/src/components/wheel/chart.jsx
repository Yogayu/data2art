import React from "react"
import {
  LineChart,
  // AreaChart
} from "rd3"

// to ChartView using React.ChartJS

export default class ChartView extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      wheelData: [{
        x: 0
        , y: 0
      }]
      , scrollData: [{
        x: 0
        , y: 0
      }]
    }
  }

  pushData(label, value) {
    let currentTime = Date.now()
    , timeOffset = currentTime - (this.prevTime || currentTime)

    if(timeOffset > 1000) {
      // clear the time offsets
      this.state[label] = []
      this.startTime = null
    }

    this.prevTime = currentTime

    if(!this.startTime) {
      this.startTime = currentTime
    }
    let time = currentTime - this.startTime

    this.state[label].push({
      x: time
      , y: value
    })
    this.forceUpdate()
  }

  render() {
    let data = [
      {
        name: "wheel-data"
        , values: this.state.wheelData
      }
      , {
        name: 'scroll-data'
        , values: this.state.scrollData
      }
    ]
    return <LineChart
      legend={true}
      data={data}
      width={1024}
      height={400}
      viewBoxObject={{
        x: 0
        , y: 0
        , width: 500
        , height: 400
      }}
      title="Line Chart"
      yAxisLabel="Altitude"
      xAxisLabel="Elapsed Time (sec)"
      gridHorizontal={true}
    />
  }
}
