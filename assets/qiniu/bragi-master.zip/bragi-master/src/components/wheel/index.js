/**
  list of available states
  {
    isFixedPlayer: false
    , ap: (0 - 1)
  }
  , {
    isFixedPlayer: true
    , ap: (0 - 1)
  }
*/

// mouse wheel and touch events
import React from "react"
import {TweenLite, TimelineLite} from "utils/gsap"
import shallowCompare from "react/lib/shallowCompare"
import {getScrollY } from "utils/domutils"

// touch utils
let getTouch = (e) => {
  if (e.targetTouches && e.targetTouches.length > 0) {
    return e.targetTouches[0]
  } else if (e.changedTouches && e.changedTouches.length > 0) {
    return e.changedTouches[0]
  } else {
    // Maybe IE pointer
    return e
  }
}

// make animation promisable
let promisable = (gsapTween) => {
  return new Promise((resolve, reject) => {
    gsapTween.eventCallback('onComplete', () => {
      resolve()
    })
  })
}

// from perfectScrollbar
let getDeltaFromEvent = (e) => {
  let deltaX = e.deltaX
  var deltaY = -1 * e.deltaY

  if (typeof deltaX === "undefined" || typeof deltaY === "undefined") {
    // OS X Safari
    deltaX = -1 * e.wheelDeltaX / 6
    deltaY = e.wheelDeltaY / 6
  }

  if (e.deltaMode && e.deltaMode === 1) {
    // Firefox in deltaMode 1: Line scrolling
    deltaX *= 20
    deltaY *= 20
  }

  if (deltaX !== deltaX && deltaY !== deltaY/* NaN checks */) {
    // IE in some mouse drivers
    deltaX = 0
    deltaY = e.wheelDelta
  }

  return -1 * deltaY
}

const TIMEOUT = 200
const MINI_PLAYER_HEIGHT = 100

export default class WheelContainer extends React.Component {

  static defaultProps = {
    miniHeight: 100
    , useFixed: false
    , targetAp: 0
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  constructor(props) {
    super(props)
    this.state = {
      ap: 0
      , isFixedPlayer: false
    }
    this.onScroll = this.onScroll.bind(this)
    this.onWindowResize = this.onWindowResize.bind(this)
  }

  dealWithTargetAp(targetAp, force=false) {
    if(this._initScrollHandler) {
      window.clearTimeout(this._initScrollHandler)
    }

    let thisAp = this.state.ap

    if(targetAp != thisAp || force) {
      if(this.inAnimation()) {
        // kill the previous animation
        this.animate.kill()
      }

      if(this.useFixedPlayer()) {
        this.doPlayerAnimation(targetAp)
      } else {
        this.scrollTo(targetAp * this.gapHeight)
      }
    }
  }

  componentWillMount() {
    this.onWindowResize()
  }

  componentDidMount() {
    window.addEventListener('scroll', this.onScroll)
    window.addEventListener('resize', this.onWindowResize)

    // !!hack, browser will move to previous window scroll after some
    // seconds
    this._initScrollHandler = window.setTimeout(() => {
      this._initScrollHandler = null
      this.scrollTo(0)
    }, 100)
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll)
    window.removeEventListener('resize', this.onWindowResize)
  }

  /**
   * decide whether to use fixed player
   * @return {bool}
   */
  useFixedPlayer() {
    return this.props.useFixed || getScrollY() > this.gapHeight
  }

  /**
   */
  togglePlayer() {
    console.warn('call togglePlayer directly is deprecate')
    return

    if(this.inAnimation()) {
      return
    }

    let scrollY = getScrollY()

    if(
      scrollY > this.gapHeight || this.state.isFixedPlayer || this.props.useFixed
    ) {
      // console.debug('toggle fixed player')
      if(this.state.ap > 0.99) {
        this.setState({isFixedPlayer: true})
        return this.doPlayerAnimation(0)
      } else {
        this.setState({isFixedPlayer: true})
        return promisable(this.doPlayerAnimation(1)).then(() => {
          this.setState({isFixedPlayer: false})
        })
      }
    }

    if(scrollY < 100) {
      this.scrollTo(this.gapHeight)
    } else {
      this.scrollTo(0)
    }
  }


  inAnimation() {
    return this.animate && this.animate.isActive()
  }

  onMove(delta) {
    if(!this.delta) {
      this.delta = 0
    }
    this.delta += delta

    // console.debug('onMove', this.delta)

    if(this.delta > 99) {
      // console.debug('scrollTo', this.gapHeight)
      this.delta = null
      this.scrollTo(this.gapHeight)
    } else if(this.delta < -99){
      // console.debug('scrollTo', 0)
      this.delta = null
      this.scrollTo(0)
    }
  }

  onMoveCancel() {
    this.delta = null
  }

  onWheel(e) {
    // not doing anything if `inAnimation`
    if(this.inAnimation()) {
      return e.preventDefault()
    }

    let scrollY = getScrollY()
    , deltaY = getDeltaFromEvent(e)

    // console.log('onWheel', deltaY)

    // decide situation
    if(
      this.state.ap == 1 &&
      (scrollY > this.gapHeight ||
        (scrollY == this.gapHeight && deltaY > 0))
    ) {
      // no preventDefault
      return
    } else {
      // clear delta after wheel stop moving
      if(this.onWheelHandler) {
        window.clearTimeout(this.onWheelHandler)
      }
      this.onWheelHandler = window.setTimeout(
        this.onMoveCancel.bind(this), TIMEOUT
      )

      e.preventDefault()
      return this.onMove(deltaY)
    }

  }

  /**
  * scroll page to position
  * @param {number} position
  * @return {GSAP.TweenLite}
  */
  scrollTo(pos) {
    // let ease = Back.easeOut.config(1),
    let duration = .3
    , scrollAnimation = TweenLite.to(window, duration, {scrollTo: {y: pos}})
    , apAnimation = this.doPlayerAnimation(this.getAnimationProgress(pos))
    , tl = new TimelineLite()

    tl.add(scrollAnimation, 0)
    tl.add(apAnimation, 0)

    this.animate = tl
  }

  doPlayerAnimation(ap, duration=0.3) {
    let apAnimation = TweenLite.to(this, duration, {
      state: {ap: ap}
    })

    return apAnimation
  }

  onScrollEnd() {
    let scrollY = getScrollY()

    if(scrollY < 100) {
      return this.scrollTo(0)
    } else {
      return this.scrollTo(this.gapHeight)
    }
  }

  onScroll(e) {
    // Animation Scroll is a `controlled` animation
    // so do nothing here
    if(this.inAnimation()) {
      return
    }

    let scrollY = getScrollY()

    // for whatever reason(pageDown, scrollDown or something unknow method/device)
    // page scroll to (0, gapHeight)
    if(scrollY > 0 && scrollY <= this.gapHeight) {
      // console.debug('<scrollTo>', e, scrollY)
      this.setState({ap: this.getAnimationProgress(scrollY)})

      // set a debounce vertion of onScrollEnd
      if(this._onScrollTimeoutHandler) {
        window.clearTimeout(this._onScrollTimeoutHandler)
      }
      this._onScrollTimeoutHandler = window.setTimeout(
        this.onScrollEnd.bind(this), TIMEOUT
      )
    }
  }

  // touch events
  onTouchCancel(e) {
    console.log('touchCancel', e)
  }

  onTouchEnd(e) {
    if(this._touchStartY > this.gapHeight) {
      return
    }

    let touch = getTouch(e)
    let difference = touch.pageY - this._touchStartY

    // this._touchStartY = 0

    // console.log('touchEnd: difference', difference)

    if(difference > 100) {
      return this.scrollTo(0)
    } else if (difference < -100) {
      return this.scrollTo(this.gapHeight)
    }
  }

  onTouchMove(e) {
    if(this._touchStartY > this.gapHeight) {
      return
    }

    e.preventDefault()
    // let touch = getTouch(e)
    // console.log('touchMove', touch.pageY)
  }

  onTouchStart(e) {
    // console.log('touchStart', e.touches)
    let touch = getTouch(e)
    this._touchStartY = touch.pageY
  }

  onWindowResize(){
    this.layerHeight = window.innerHeight - this.props.miniHeight

    this.gapHeight = parseInt(
      this.layerHeight - MINI_PLAYER_HEIGHT, 10
    )
    let ap = this.getAnimationProgress(getScrollY())
    // set animation progress
    this.setState({ap: ap})

    // console.debug('WindowResize:',{gapHeight: this.gapHeight,ap})

    this.forceUpdate()

  }


  getAnimationProgress(pos) {
    if(pos > this.gapHeight) {
      return 1
    }

    return Math.round(pos / this.gapHeight * 100) / 100
  }

  render() {
    let {ap} = this.state
    // , isFixedPlayer = this.useFixedPlayer() && ap < 1
    , useFixed = this.useFixedPlayer()

    console.log(ap)

    // console.debug(
    //   'isFixedPlayer ->', useFixed
    //   , ', ap ->', ap
    // )

    let styleContainer = {
        width: '100%'
        , height: 10000
      }
      , styleCover = {
        height: this.layerHeight
      }
      , styleContents = {
        minHeight: 1500
      }

    // console.debug('AnimationProgress: ', ap)

    return <div
      onWheel={this.onWheel.bind(this)}
      styles={styleContainer}

      onTouchCancel={this.onTouchCancel.bind(this)}
      onTouchStart={this.onTouchStart.bind(this)}
      onTouchEnd={this.onTouchEnd.bind(this)}
      onTouchMove={this.onTouchMove.bind(this)}
    >
      <div style={styleCover}>
        {useFixed && ap < 0.01 ? <div
          className="fixed-player-place-holder"
          style={{
            display: 'block'
            , height: null // this.fullPlayerHeight()
          }}
        ></div> : null}

        {this.props.cover ? React.cloneElement(this.props.cover, {
          minHeight: MINI_PLAYER_HEIGHT
          , ref: 'cover'
          , maxHeight: this.layerHeight
          , animationProgress: ap
          , isMiniPlayer: ap > 0.99
          , style: useFixed && ap < 0.99  ? {
            position: 'fixed'
            , top: 0
            , height: this.layerHeight * (1 - ap)
          } : {}
        }) : null}

        {useFixed && ap < 0.01 ?
          <div className="fixed-player-overlay"
            onClick={this.togglePlayer.bind(this)}
            style={{
              background: 'rgba(255, 255, 255, .8)'
              , position: 'fixed'
              , left: 0
              , right: 0
              , top: 0
              , bottom: 0
              , zIndex: 900
            }}></div> : null}
      </div>

      <div style={styleContents}>
        {this.props.children}
      </div>

    </div>
  }

}
