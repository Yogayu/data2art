// this is the basic dialog, that

// Simple Dialog Component uses in `userlogin`

// feature, always center
import React, { Component } from 'react'
import styles from './dialog.module.css'
import shallowCompare from 'react/lib/shallowCompare'
import cls from 'classnames'

export default class Dialog extends Component {

  constructor(props) {
    super(props)
    this.state = {
      width: this.props.width || 480
      , height: this.props.height || 380
    }
  }

  autoCenter() {
    let {width, height} = this.refs.inner.getBoundingClientRect()
    this.setState({
      width, height
    })
  }

  componentDidUpdate() {
    this.autoCenter()
  }

  componentDidMount() {
    this.autoCenter()
  }

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  preventDefault(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  render () {
    let {width, height} = this.state

    return <div
      ref={'root'}
      className={cls(styles.dialog, this.props.isClose ? styles.dialogClose : null)}
      onWheel={this.preventDefault}
      style={{
        top: '50%'
        , left: '50%'
        , width: width
        , height: height

        , marginLeft: -1 * width / 2
        , marginTop: -1 * height / 2

        // style
        , borderRadius: 2
        , border: 'solid 1px #e1e1e1'

        , boxSizing: 'content-box'
      }}
    >
      <div
        ref={'inner'}
        style={this.props.innerStyle}
        className={styles.ctx}>
        {this.props.children}
      </div>

      <div className={styles.msk}></div>

    </div>
  }


}
