import "./dialog.scss"
import React from "react"
import Icon from "ui/icon"

export default class Dialog extends React.Component {

  static defaultProps = {
    title: null
    , url: null
    , width: 200
    , height: 200
    , showMask: false
    , showShadow: true
    , className: ''
    , baseZIndex: 10000
  }

  constructor(props) {
    super(props)
    this.state = {
      close: false
      , innerHeight: null
    }
  }

  onClose(e) {
    e.preventDefault()
    this.setState({
      close: true
    })
    window.setTimeout(() => {
      if(this.props.onClose) {
        this.props.onClose()
      }
    }, 200)
  }

  getHeight() {
    return this.state.innerHeight || this.props.height
  }

  componentDidMount() {
    this.componentDidUpdate()
  }

  componentDidUpdate() {
    let ch = this.refs.content.offsetHeight
    console.log(ch)
    if(ch !== this.state.innerHeight) {
      this.setState({innerHeight: ch})
    }
  }

  render() {
    let cls = 'dui-dialog ' + this.props.className

    if(this.state.close) {
      cls += ' close'
    } else {
      cls += ' open'
    }

    let dialog = <div className={cls} style={{
      'display': 'block'
      , 'position': 'fixed'
      , 'width': this.props.width
      , 'minHeight': this.getHeight()
      , 'left': '50%'
      , 'marginLeft': -1 * this.props.width / 2
      , 'top': '50%'
      , 'marginTop': -1 * this.getHeight() / 2
      , 'zIndex': this.props.baseZIndex
    }}>
      {this.props.showShadow ? <span className="dui dialog-shd"></span> : null}
      <div className="dui-dialog-content" ref="content">
        <a
          href="#"
          className='dui-dialog-close'
          onClick={this.onClose.bind(this)}
          style={{'textDecoration': 'none'}}
        >
          <Icon i="close" size={14} color="#ACACAC"></Icon>
        </a>

        {this.props.title ?
          <div className="hd"><h3>{this.props.title}</h3></div> : null}
        <div className="bd">{this.props.children}</div>
        {this.props.footer ?
          <div className="ft">{this.props.footer}</div> : null}
        {this.props.modal ? <div className="dui-dialog-msk"></div> : null}
      </div>
    </div>

    if(this.props.showMask) {
      return <div className="dui-dialog-wrapper">
        <div
          className="dui-dialog-msk"
          style={{zIndex: this.props.baseZIndex - 1}}></div>
        {dialog}
      </div>
    } else {
      return dialog
    }
  }
}
