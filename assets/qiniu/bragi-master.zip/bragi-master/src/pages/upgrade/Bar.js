import React from 'react'

const Bar = () => {
  return <div
    id="old-version-tip"
    style={{
      fontSize: 12
      , color: '#292929'
      , textAlign: 'center'

      , background: '#e1e9e6'

      , height: 34
      , lineHeight: '34px'

      , position: 'fixed'
      , top: 0
      , left: 0
      , right: 0
      , width: '100%'

      , zIndex: 10000
    }}

  >
  您的浏览器版本过低， 不能使用豆瓣FM的<a href="#" className="barLink" id="_showNewFeatures">最新功能</a>， 建议您<a className="barLink" href="#" id="_upgradeBrowsers">升级浏览器</a>或者在手机上<a className="barLink" href="/app" target="_blank">下载使用豆瓣FM App</a>
  </div>
}

export default Bar
