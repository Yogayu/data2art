import React from 'react'

const buildImgUrl = (name) => {
  // let img = require('./icons/' + name)
  return 'http://localhost:3000/public/' + name
}

const Browsers = () => {
  let browsers = [{
    title: 'Firefox'
    , url: 'http://www.firefox.com.cn/download/'
    , version: 'Firefox 16'
    , icon: '//img3.doubanio.com/img/files/file-1477982262.png'
  }, {
    title: 'Chrome'
    , url: 'https://www.google.cn/intl/zh-CN/chrome/'
    , version: 'Chrome 36'
    , icon: '//img3.doubanio.com/img/files/file-1477982174.png'
  }, {
    title: 'Safari'
    , url: 'http://www.apple.com/safari/'
    , version: 'Safari 9'
    , icon: '//img3.doubanio.com/img/files/file-1477982625.png'
  }, {
    title: 'Internet Explorer'
    , url: 'https://support.microsoft.com/zh-cn/help/17621/internet-explorer-downloads'
    , version: 'IE 9'
    , icon: '//img3.doubanio.com/img/files/file-1477982302.png'
  }]

  return (<div
    style={{
      width: 800
      , height: 480
      // , backgroundColor: '#eee'
      // , border: '1px solid #e1e1e1'
      , textAlign: 'center'
    }}

  >
    <h1 style={{
      fontSize: 22
      , color: '#999999'
      , fontWeight: 400
      , margin: '80px 0 60px 0'
    }}>最新豆瓣 FM 支持以下浏览器</h1>

    <hr style={{
      border: '0px solid #e5e5e5'
      , borderTopWidth: '1px'
      , width: 180
      , marginBottom: 60
    }} />

    <div className="browsers">
    {browsers.map((browser, i) => {
      return <li key={i} className="browser">
        <a
          className="barLink"
          href={browser.url}
          target="_blank">
          <img width={70} height={70} src={browser.icon} alt={browser.title} />
        </a>
        <a
          target="_blank"
          href={browser.url}
          className={'browserTitle barLink'}>{browser.title}</a>
        <p className={'browserDesc'}>最低可用版本<br />
        {browser.version}
        </p>
      </li>
    })}
    </div>
  </div>)
}

export default Browsers
