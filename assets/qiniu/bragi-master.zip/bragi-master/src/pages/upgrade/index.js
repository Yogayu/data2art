/*global Do, $, dui */
import "babel-polyfill"

require('./bar.css')

var domString = require('raw!./Bar.html')
, browsersPage = require('raw!./Browsers.html')

var createDialog = function (
  width=802
  , height=600
  , title=null
  , content
  , allowScroll=true
) {
  var dlg = dui.Dialog({
    modal: true
    , width: width
    , height: height
    , isHideTitle: !title
    , title: '最新功能'
    , content: content
  })
  // dlg.update()

  dlg.body.css({
    padding: 0
    , overflow: 'hidden'
    , height: height - 40
    , overflowY: allowScroll ? 'scroll' : null
  })

  dlg.node.bind('wheel', function (e) { e.stopPropagation() })

  dlg.open()

  // @todo for debug use only
  window.dlg = dlg
  return dlg
}

Do.ready(function () {
  $('body').css({
    position: 'relative'
    , top: 34
  }).append(domString)

  $('#_showNewFeatures').bind('click', function (e) {
    e.preventDefault()
    //http://p.dapps.douban.com/p/30da2333544b4283ab284f07e869c2f2.jpg
    var wh = $(window).height() - 100

    if(wh > 600) {
      wh = 600
    }

    var dlg = createDialog(
      802, wh
      , '最新功能'
      , `<img
          src="https://img1.doubanio.com/img/files/file-1477981647.jpg"
          alt="新版介绍" />`
      , true
    )

    return dlg
  })

  $('#_upgradeBrowsers').bind('click', function (e) {
    e.preventDefault()
    var dlg = createDialog(
      800, 480, null, browsersPage
      , false // allow scroll
    )

    dlg.body.css({
      backgroundColor: '#fff'
    })

    dlg.node
      .find('.dui-dialog-content')
      .css('border-color', '#e1e1e1')

    dlg.shadow.hide()
  })
})
