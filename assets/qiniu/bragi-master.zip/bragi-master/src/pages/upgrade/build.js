// this is a special build file for the static page
// usage: babel-cli build.js
import React from 'react'
import ReactDOMServer from 'react-dom/server'
import Bar from './Bar'
import Browsers from './browsers'
import fs from 'fs'

const renderToString = (Component) => {
  return ReactDOMServer.renderToString(
    <Component></Component>
  )
}

fs.writeFile(
  './Bar.html'
  , renderToString(Bar)
)

fs.writeFile(
  './Browsers.html'
  , renderToString(Browsers)
)
