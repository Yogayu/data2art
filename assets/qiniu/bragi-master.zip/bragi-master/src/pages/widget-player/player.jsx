var React = require('react');
var Progress = require('components/playing-progress');
var douradio = require('douradio');
var Controls = require('views/playing/controls');
var Icon = require('views/icon');
var Loading = require('ui/loading');
var ReactSlider = require('react-slider');


var formatPosition = function(t){
  if(!t) return '';

  function pad(n) {
    return n < 10 ? '0' + n.toString() : n.toString();
  }

  var d = new Date(parseInt(t, 10));
  return pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

var VolumeSlider = React.createClass({

  getInitialState: function () {
    return { value: 100 }
  },

  onChange: function (ev) {
    console.log(ev);
    this.setState({value: ev});
  },

  render: function () {
    return <span className="volume-slider" style={{}}>
      <i className="icon icon-volume-up"></i>
      <ReactSlider
        defaultValue={100}
        value={this.state.value}
        onChange={this.onChange}
        withBars={true}
      ></ReactSlider>
    </span>
  }

})

var Player = React.createClass({

  handlePlayPause: function (e) {
    e.preventDefault();
    douradio.togglePause();
  },

  handleOpenSubject: function (e) {
    if(!douradio.currentSong) { return; }
    window.open(
      douradio.currentSong.albumLink(),
      '_blank'
    );
  },

  componentDidMount: function () {
    douradio.switchChannel(1);

    douradio.on('switch_song play pause', () => {
      this.forceUpdate();
    }, this);

    douradio.on('playing', (currentAudio) => {
      var {position, duration} = currentAudio;
      this.setState({
        played: position / duration * 100,
        position: position,
        duration: duration
      });
    }, this)

    douradio.on('loading', (currentAudio) => {
      var {bytesLoaded, bytesTotal} = currentAudio;
      this.setState({
        loaded: bytesLoaded / bytesTotal * 100
      });
    }, this)

  },

  getInitialState: function () {
    return {
      loaded: 0,
      played: 0
    };
  },

  componentWillUnmount: function () {
    douradio.off(null, null, this);
  },

  render: function () {
    var currentSong = douradio.currentSong;

    if(!currentSong) {
      return <div className="widget-player">
       <Loading className="center"></Loading>
      </div>
    }

    return <div className={
        "widget-player" + (douradio.isPlaying() ? '' : ' stopped')
    }>
      <div className="cover-outer" onClick={this.handleOpenSubject}>
        <div className="cover" style={{
          backgroundImage: 'url(' + currentSong.get('picture') + ')',
        }}></div>
        <span className="label">查看专辑信息</span>
      </div>

      <div className="content">
        <h1 className="artist-title" style={{
        }}>{currentSong.get('artist')}</h1>
        <p className="sub-title" style={{}}>
          &lt; {currentSong.get('albumtitle')} &gt;
          {currentSong.get('public_time')}
        </p>
        <p className="song-title">{currentSong.get('title')}</p>
        <Progress
          loaded={this.state.loaded}
          played={this.state.played}
        ></Progress>
        <div className="time">
          <span>{formatPosition(this.state.position)}</span>
          <VolumeSlider></VolumeSlider>
        </div>
      </div>

      <Icon
        className="btn-play-pause"
        i={douradio.isPlaying() ? 'pause' : 'play'}
        onClick={this.handlePlayPause}
      ></Icon>

      <Controls></Controls>

      <div
        onClick={this.handlePlayPause}
        className="pause-layer">
        继续收听 &gt;
      </div>

    </div>;
  }
  
});

class WidgetPlayer {

  constructor () {
    // DBR related work here
  }

  render (root) {
    React.render(<Player></Player>, root)
  }

}

module.exports = new WidgetPlayer()
