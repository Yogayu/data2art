// this is a small player build for <web 2.0> to replace the old flash player.
require('./style.scss');
var player = require('./player');

player.render(
  document.getElementById('fm-player')
);
