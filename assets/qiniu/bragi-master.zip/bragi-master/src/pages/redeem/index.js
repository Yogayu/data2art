import "./index.scss"

import {ContentManager} from "./widgets"

let ctx = new ContentManager()

let switcher = document.querySelector('.switchers')
if(switcher) {
  switcher.addEventListener('click', function (e) {
    e.preventDefault()
    let target = e.target.getAttribute('href')
    if(!target) {
      return
    }
    ctx.render(target.slice(1))
  })
}
