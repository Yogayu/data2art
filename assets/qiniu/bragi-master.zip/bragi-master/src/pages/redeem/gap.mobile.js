import "./gap.mobile.scss"
import createOpener from "h5/utils/open"
import domReady from "domready"

// Client Uri
let opener = createOpener(
  'doubanradio://douban.fm/gap',
  'http://www.douban.com/mobile/download/fm',
  'doubanradio',
  'com.douban.radio'
)

domReady(function () {
  document
    .getElementById('app-button')
    .addEventListener('click', function () {
      if(navigator.userAgent.indexOf('MicroMessenger') > 0) {
        let el = document.getElementById('wechat-tip')
        if(!el) {
          el = document.createElement('div')
          el.id = 'wechat-tip'
          el.innerHTML = `链接打不开？<br>
            <small>请点击右上角 选择 “<b>用浏览器打开</b>”</small>`
        }
        el.style.display = 'block'

        document.body.appendChild(el)
        return
      }
      opener.open()
    })

  // do something with position

  let pageWidth = window.innerWidth
    , pageHeight = window.innerHeight
    , header = document.querySelector('.header-mobile')
    , container = document.querySelector('.container')
    , logo = document.querySelector('.logo')
 // , circleLength = header.offsetHeight
    , logoWidth = pageWidth * 0.825
    , logoHeight = logoWidth / 512 * 318
    , realHeaderHeight = pageHeight * 0.33

  if(realHeaderHeight < logoHeight) {
    realHeaderHeight = logoHeight
  }

  // 0.375 is the center of header center

  header.style.height = `${realHeaderHeight}px`

  // header.style.marginTop = '-' + (circleLength - realHeaderHeight) + 'px'

  container.style.paddingTop = '' + (pageHeight * .52) + 'px'


  logo.style.width = `${logoWidth}px`
  logo.style.height = `${logoHeight}px`
  logo.style.marginLeft = `${-1 * logoWidth * 0.375}px`

  logo.style.backgroundSize = '100% 100%'
})
