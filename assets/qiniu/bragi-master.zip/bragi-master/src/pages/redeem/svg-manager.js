import svg from "svg.js"

// bind events
let changeableColors = {
  'initial': ['#FDFDF8', '#FDEDD1', '#FCCBBC', '#F2EAD4', '#E6D9B9'],
  'success': ['#FDFDF8', '#F2F2CF', '#D5E1D3', '#76A9B3', '#4B758C'],
  'failure': ['#112E4C', '#4B6684', '#1F385A', '#23466C', '#467098']
}

export class SVGManager {

  constructor() {
    let width = window.innerWidth
      , height = width / 414 * 249
    height = height > 250 ? 250 : height

    this.width = width
    this.height = height

    this.initTopSVG()
    this.initBottomSVG()
  }

  initTopSVG() {
    let draw = svg('cover-svg').viewbox(0, 0, 414, 249).size(
      this.width, this.height
    )

    let gradient = draw.gradient('linear', (stop) => {
      this.top1 = stop.at(0, '#FDEDD1')
      this.top2 = stop.at(1, '#FCCBBC')
    })

    draw.path(
      "M-41.3748518,-7.38961457 C-41.3748518,-7.38961457 -20.7239732,-28.5258293 12.9074577,1.50984558 L40.0486124,4.84714187 C40.0486124,4.84714187 51.8491144,40.4449794 77.810219,22.6460603 C103.771323,4.84714124 113.80175,-24.0761001 146.253131,-7.38961467 C178.704512,9.29687076 184.604763,-9.61447938 184.604763,-9.61447938 C184.604763,-9.61447938 218.826219,-39.0939396 238.887072,-1.27123635 L251.867624,5.95957428 C251.867624,5.95957428 270.748428,29.3206551 287.26913,9.85308769 C303.789833,-9.6144797 342.141465,1.50984466 342.141465,1.50984466 C342.141465,1.50984466 356.302067,-64.6798841 401.143975,-27.4133978 C445.985883,9.85308843 454.83626,-18.5139386 454.83626,-18.5139386 L454.83626,231.783352 L-51.4052785,229.002271 L-41.3748518,-7.38961457 Z"
    ).attr(
      'transform', 'translate(201.715491, 96.494752) scale(1, -1) rotate(11.000000) translate(-201.715491, -96.494752)'
    ).fill(gradient)

    return draw
  }

  initBottomSVG() {
    let draw = svg('bottom-svg')
      .viewbox(0, 400, 414, 230)
      .size(this.width, this.height)

    let gradient = draw.gradient('radial', (stop) => {
      this.bottom1 = stop.at({
        offset: 0,
        color: '#f2ead4',
        opacity: 0.983440897
      })

      this.bottom2 = stop.at({
        offset: 1,
        color: '#E6D9B9'
      })
    })

    draw.path(
      "M1,535 C1,535 18.5,516.000001 47,543.000001 L70,546 C70,546 80,578.000001 102,562 C124,545.999999 132.5,520 160,535 C187.5,549.999999 192.5,533 192.5,533 C192.5,533 221.5,506.499999 238.5,540.5 L249.5,547 C249.5,547 265.5,568 279.5,550.5 C293.5,533 326,543 326,543 C326,543 338,483.499999 376,517 C414,550.500001 421.5,525 421.5,525 L421.5,750 L-7.5,747.5 L1,535 Z"
    ).fill(gradient)

    return draw
  }

  switchTheme(style="initial") {
    let colors = changeableColors[style]
    if(!colors) {
      colors = changeableColors.initial
    }

    document.querySelector('body').style.backgroundColor = colors[0]

    let animationDuration = 300

    this.top1.animate(animationDuration, ">").update({
      color: colors[1]
    })

    this.top2.animate(animationDuration, ">").update({
      color: colors[2]
    })

    this.bottom1.animate(animationDuration, ">").update({
      color: colors[3]
    })

    this.bottom2.animate(animationDuration, ">").update({
      color: colors[4]
    })

  }

}
