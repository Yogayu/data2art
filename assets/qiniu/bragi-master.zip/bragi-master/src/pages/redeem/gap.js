import "./gap.scss"
import reqwest from "reqwest"
import Cookies from "cookies-js"
import domReady from "domready"

class RedeemBox {

  constructor(dom) {
    this.dom = dom
    this.bindEvents()
  }

  bindEvents() {
    this.dom.querySelector(
      '.input-redeem-code'
    ).addEventListener('keyup', this.onKeyUp.bind(this))

    this.dom.querySelector(
      '.button-redeem'
    ).addEventListener('click', (event) => {
      event.preventDefault()
      let input = this.dom.querySelector('.input-redeem-code')
      this.doRedeem(input.value)
    })

    this.dom.querySelector('.button-redeem').innerText = '兑换'

    this.dom.querySelector('.form-redeem').addEventListener('submit', (event) => {
      event.preventDefault()
      let input = this.dom.querySelector('.input-redeem-code')
      this.doRedeem(input.value)
    })

    this.dom.querySelector('.button-redeem-failure').addEventListener('click', (event) => {
      this.render('initial')
    })
  }

  doRedeem(code) {
    if(this.inputDisabled) {
      return
    }

    if(this.request) {
      this.request.abort()
    }

    this.request = reqwest({
      url: '/j/pro/redeem',
      method: 'post',
      // error: function (err) {}, maybe drop the erro
      data: {
        'redeem_code': code,
        'ck': Cookies.get('ck').replace(/\"/g, '')
      },
      success: (response) => {
        this.request = null
        if(response.err) {
          return this.render('failure', response.err)
        }
        this.onRedeemSuccess(response)
        this.render('success', response)
      },
      error: (response) => {
        return this.render('failure')
      }
    })
  }

  appOpen(url, timeout = 100) {
    window.setTimeout(() => {
      location.href = url
    }, timeout)
  }

  // checkRedeem(code) {}
  onRedeemSuccess(gift) {
    let isApp = navigator.userAgent.indexOf('com.douban.DoubanRadio') > 0
    if(gift.gap_songlist_url) {
      let gapSonglistUrl = 'http://douban.fm/' + gift.gap_songlist_url
      if(isApp) {
        this.appOpen(gapSonglistUrl, 100)
        this.appOpen('http://douban.fm/reloadSonglists', 200)
      } else {
        console.log('@todo open url')
        // location.href = gapSonglistUrl
      }
    }
    if(isApp) {
      this.appOpen('http://douban.fm/refreshUserInfo', 300)
    }
  }

  onKeyUp(e) {
    // this.checkRedeem(e.target.value)
    let target = e.target

    if(target.value.length >= 16) {
      this.inputDisabled = false
      target.parentElement.classList.remove('disable')
    } else {
      this.inputDisabled = true
      target.parentElement.classList.add('disable')
    }
  }

  hide() {
    this.dom.style.display = 'none'
  }

  show() {
    this.dom.style.display = ''
  }

  render(state='initial', data={}) {
    if(state === 'initial') {
      this.dom.querySelector('.input-redeem-code').value = ""
    }

    if(state === 'success') {
      this.dom.querySelector('.expire-time').innerText = data.effective_time

      let msg = this.dom.querySelector('.success-message')
      // is gap
      if(data.gap_songlist_url) {
        msg.innerText = data.buyer
      } else {
        msg.innerHTML = "成功兑换了 " + data.buyer + " 赠予你的10元/月礼品卡<br>"
      }
    }

    return Array.prototype.map.call(
      this.dom.querySelectorAll('.state'),
      (node) => {
        if(node.classList.contains(state)) {
          node.style.display = 'block'
        } else {
          if(!node.hidden) {
            node.style.display = 'none'
          }
        }
      }
    )
  }

}


domReady(function () {
  new RedeemBox(
    document.querySelector('.header')
  )
})
