// lodash build of `underscore` for Backbone use

/* ```find all underscore methods in Backbone
 * re.findall('_\.(.*?)\(', source)
 */

// collection
import each from "lodash/each"
import map from "lodash/map"
import size from "lodash/size"
import some from "lodash/some"
import invoke from "lodash/invokeMap"

import filter from "lodash/filter"

// Strings
import escape from "lodash/escape"

// function
import once from "lodash/once"
import bind from "lodash/bind"
import defer from "lodash/defer"

// object
import extend from "lodash/extend"
import defaults from "lodash/defaults"
import result from "lodash/result"
import keys from "lodash/keys"
import pick from "lodash/pick"
import has from "lodash/has"
import omit from "lodash/omit"

// lang
import isRegExp from "lodash/isRegExp"
import isFunction from "lodash/isFunction"
import isString from "lodash/isString"
import isObject from "lodash/isObject"
import isEmpty from "lodash/isEmpty"
import isEqual from "lodash/isEqual"
import isArray from "lodash/isArray"
import clone from "lodash/clone"
import isNumber from "lodash/isNumber"

// utils
import matches from "lodash/matches"
import uniqueId from "lodash/uniqueId"
import iteratee from "lodash/iteratee"

// array
import union from "lodash/union"
import indexOf from "lodash/indexOf"

module.exports = {
  bind,
  clone,
  defaults,
  defer,
  each,
  escape,
  extend,
  has,
  invoke,
  isArray,
  isEmpty,
  isEqual,
  isFunction,
  isObject,
  isRegExp,
  isString,
  iteratee,
  keys,
  map,
  matches,
  once,
  pick,
  result,
  size,
  some,
  uniqueId,
  indexOf,

  // addon collection
  filter,

  // non backbone variable
  isNumber,
  union,
  omit
}
