// dropdown songlist
import "./dropdown.scss"
import Tooltip from "components/tooltip"
import classnames from "classnames"
import Scrollbar from "./scrollbar"
import React from 'react'

export default class Dropdown extends Tooltip {

  static defaultProps = {
    x: 0
    , y: 0
    , height: 400
  }

  onClickBody(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  fixPosition(){
    let el = this.refs.root
    , offsetX = -1 * el.offsetWidth / 2

    // right edge detection
    let offsetRight = (this.props.x + offsetX + el.offsetWidth) - window.innerWidth

    if(offsetRight > 0) {
      offsetX = offsetX - 1 * offsetRight - 10
    }

    this.setState({
      offsetX: offsetX
      , offsetY: 0
    })
  }

  render() {
    let {
      x, y, direction="top", children, visiable, height, className
    } = this.props
    let {offsetX, offsetY} = this.state

    return <div
      onClick={this.onClickBody.bind(this)}
      ref="root"
      className={classnames(
        'dropdown', direction, className,
        {'in': visiable}
      )} style={{
        left: x + offsetX,
        top: y + offsetY + 5
      }} role="tooltip">
        <div className="inner-container">
          <div className="popup-arrow"><div className="arrow-inner"></div></div>
          <Scrollbar
            className="inner"
            style={{
              height: height,
              width: '100%'
            }}
          >
          {children}
          </Scrollbar>
        </div>
      </div>
  }

}
