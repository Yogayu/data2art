import React from "react"
import cls from "classnames"

// let icons = {}
// ['add', 'angle-down', 'clock', 'down', 'heart-red', 'heart', 'lyric', 'more'
// , 'pause', 'prev', 'search', 'skip', 'trash', 'volume'].map((name) => {
//   icons[name] = require('icons/' + name + '.svg')
// })

// svg fonts

export default class Icon extends React.Component {

  static defaultProps = {}

  constructor(props) {
    super(props)
  }

  onClick(e) {
    e.preventDefault()
    if(this.props.onClick) {
      e.stopPropagation()
      return this.props.onClick(e)
    }
  }

  render() {
    /*
    console.error(
      `ui/icon[i=${this.props.i}] is deprecated, please use icons/icon-${this.props.i} instead`
    )
    */

    let SVG
    try {
      SVG = require('assets/icons/icon-' + this.props.i + '.svg')
    } catch (e) {
      console.error('can not found icon-' + this.props.i)
      SVG = ""
    }

    let className = cls('icon', 'icon-' + this.props.i, this.props.className)
    , height = this.props.height || this.props.size || 18
    , width = this.props.width || this.props.size || 18

    return <i
      href="#"
      className={className}
      onClick={this.onClick.bind(this)}
      style={Object.assign({
        backgroundImage: 'url(' + SVG + ')'
        , backgroundSize: `${width}px ${height}px`
        , display: 'inline-block'
        , height: height
        , width: width
      }, this.props.style)}
    ></i>
  }
}

Icon.defaultProps = {onClick: null}
