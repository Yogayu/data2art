import QRCode from "qrcodejs"
import React from "react"
import ReactDOM from "react-dom"

export default class QRCodeBox extends React.Component {

  static defaultProps = {
    text: 'http://douban.fm/',
    width: 94,
    height: 94,
    colorDark: '#000000',
    colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.H
  }

  componentDidMount() {
    this.qrcode = new QRCode(ReactDOM.findDOMNode(this), {
      width: this.props.width,
      height: this.props.height,
      colorDark: this.props.colorDark,
      colorLight: this.props.colorLight,
      correctLevel: this.props.correctLevel,
      text: this.props.text
    })
  }

  componentWillReceiveProps(props) {
    if(props.text) {
      this.qrcode.makeCode(props.text)
    }
  }

  componentWillUnMount() {
    this.qrcode.clear()
  }

  render() {
    return <div className="qrcode">{this.props.children}</div>
  }
}
