import "./section-switcher.scss"
import React from "react"
import isFunction from "lodash/isFunction"
import isNumber from "lodash/isNumber"
import extend from "lodash/extend"
import shallowCompare from "react/lib/shallowCompare"
import classnames from "classnames"

export function SectionSwitcherHeader(props) {
  let {
    onSwitchSection, sections, currIndex, lineStyle, children
  } = props
  return <div className="section-header">
    <ul className="container">
      {sections.map((
        section, index
      ) => {
        let isCurrent = currIndex === index
        , icon = null

        if(section.icon) {
          icon = React.createElement(section.icon, {
            color: isCurrent ? '#45A156' : '#979797'
            , size: 23
            , style: {
              verticalAlign: 'top'
            }
          })
        }

        return <li
          key={'section-' + index}
          className={classnames(
            isCurrent ? 'current' : null,
            'tab-' + section.url
          )}
        >
          <a onClick={onSwitchSection.bind(null, section)} href="#">
            {icon} {section.title}
          </a>
        </li>
      })}
      {lineStyle ?
        <div className="blank-line" ref="line"></div>
        : null}
        {children}
      </ul>
    </div>
}

export default class SectionSwitcher extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      currentIndex: null
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  onSwitchSection(section, event) {
    event.preventDefault()
    let index = this.props.sections.indexOf(section)

    if(this.state.index === index) {
      return
    }

    if(this.props.onSwitch) {
      this.props.onSwitch(section)
    }

    this.setState({currentIndex: index})
  }

  setLinePosition() {
    let line = this.refs.line
    if (!this.refs.currentTab) {
      line.style.display = 'none'
    }
    let node = this.refs.currentTab

    if(this.props.lineStyle === 'blank') {
      line.style.left = node.offsetLeft + 'px'
      line.style.width = node.offsetWidth + 'px'
    } else if(this.props.lineStyle === 'triangle') {
      // a little triangle
      line.style.width = 0
      line.style.left = (node.offsetLeft + node.offsetWidth / 2) + 'px'
    }
  }

  componentDidMount() {
    if(this.props.lineStyle) {
      this.setLinePosition()
    }
  }

  componentDidUpdate() {
    if(this.props.lineStyle) {
      this.setLinePosition()
    }
  }

  // @todo use for the future
  getAsyncComponent(el) {
    let after = (component) => {
      this.setState({
        component: component
      })
    }

    if(React.isElement(el)) {
      return after(el)
    }

    if(isFunction(el)) {
      let result = el(after)
      if(result.then) {
        // it's in a promise
        result.then(after)
      }
    }
  }

  currentIndex() {
    if(isNumber(this.props.currentIndex)) {
      return this.props.currentIndex
    } else if (isNumber(this.state.currentIndex)) {
      return this.state.currentIndex
    } else {
      return this.props.defaultIndex
    }
  }

  render() {
    // console.count('section-switcher')
    let sectionElement = this.props.page
    , currIndex = this.currentIndex()

    if(!sectionElement && isNumber(currIndex)) {
      let section = this.props.sections[currIndex]
      sectionElement = React.createElement(
        section.component, extend({
          subpage: section.name
        }, section.props))
    }

    return <div className={this.props.className || "section-switcher"}>
      <SectionSwitcherHeader
        sections={this.props.sections}
        currIndex={currIndex}
        onSwitchSection={this.onSwitchSection.bind(this)}
        lineStyle={null}
      >{this.props.children}</SectionSwitcherHeader>

      <div className="section-content">
        {sectionElement}
      </div>
    </div>
  }

}
