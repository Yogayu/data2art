import React from "react"
// import isString from 'lodash/lang/isString'
// import isArray from 'lodash/lang/isArray'
import {isString, isArray} from "lodash/"

/**
 * Single Line Text
 * React Component
 */
export default class Text extends React.Component {

  render() {
    let {
      height,
    } = this.props
    , defaultStyle = {
      display: 'inline-block'
      , overflow: 'hidden'
      , textOverflow: 'ellipsis'
      , lineHeight: height
      , height: height
      , whiteSpace: 'nowrap'
    }

    if(isString(this.props.children)) {
      let title = this.props.children
      return <span {...this.props} style={
        Object.assign(defaultStyle, this.props.style)
      } title={title}>{title}</span>
    } else if(isArray(this.props.children)){


    }
  }

}
