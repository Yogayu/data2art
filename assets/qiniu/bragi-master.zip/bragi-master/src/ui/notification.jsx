// inline notification
import styles from "./notification.module.scss"
import {IconNotification} from "icons"
import React from 'react'

export default function ({children, style}) {
  return <div
    className={styles.notification}
    style={style}
  >
    <IconNotification color="#6BBD7A" size={11}></IconNotification>
    &nbsp;
    {children}
  </div>
}
