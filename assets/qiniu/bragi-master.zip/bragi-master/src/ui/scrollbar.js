import "./scrollbar.scss"

import React from "react"
import perfectScrollbar from "perfect-scrollbar"
import defaults from "lodash/defaults"
import classnames from "classnames"

export default class ScrollBar extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      isMouseOver: false
    }
  }

  componentDidMount() {
    let node = this.refs.scroller
    perfectScrollbar.initialize(node, this.props.scroller)
  }

  componentDidUpdate() {
    perfectScrollbar.update(this.refs.scroller)
  }

  componentWillUnmount() {
    perfectScrollbar.destroy(this.refs.scroller)
  }

  scrollTo(yPos, timeout = 0) {
    if(this.state.isMouseOver){
      return
    }
    window.TweenLite.to(this.refs.scroller, timeout / 1000, { scrollTop: yPos })
    perfectScrollbar.update(this.refs.scroller)
  }

  onWheel(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  render() {
    let inner = React.createElement(this.props.element || 'div', {
      ref: 'scroller'
      , onWheel: this.onWheel.bind(this)
      , onMouseOver: () => {
          this.state.isMouseOver = true
          return
        }
      , onMouseOut: () => {
          this.state.isMouseOver = false
          return
        }
      , style: defaults(this.props.style, {
        position: 'relative'
        , height: '100%'
      })
      , className: 'ps-container'
      // , className: this.props.className
    }, this.props.children)
    return <div className={classnames('ps-outer', this.props.className)}>{inner}</div>
  }
}

ScrollBar.defaultProps =  {
  scroller: {
    wheelSpeed: 2
    , wheelPropagation: true
    , minScrollbarLength: 20
  }
}
