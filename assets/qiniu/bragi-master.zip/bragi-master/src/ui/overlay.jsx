import React from "react"
import ReactDOM from "react-dom"
import shallowCompare from "react/lib/shallowCompare"
import classnames from "classnames"

let preventDefault = (e) => {
  e.preventDefault()
  e.stopPropagation()
}

export default class Overlay extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      x: props.x
      , y: props.y
    }
  }

  componentDidMount() {
    this.fixPosition()
  }

  componentDidUpdate() {
    this.fixPosition()
  }

  shouldComponentUpdate(props, state) {
    return shallowCompare(this, props, state)
  }

  fixPosition(){
    // edge detection
    const ContainerWidth = 1024
    let el = ReactDOM.findDOMNode(this)
    , windowWidth = window.innerWidth
    , windowHeight = window.innerHeight
    // right corner
    , maxRightPos = (windowWidth + ContainerWidth) / 2
    , x = this.props.x || 0
    , y = this.props.y || 0

    if(this.props.align === 'right') {
      // x should be the right edge of an element
      x = x - el.offsetWidth
    }

    // edge detection
    if((x + el.offsetWidth) > maxRightPos) {
      x = maxRightPos - el.offsetWidth
    }

    if((y + el.offsetHeight) > windowHeight) {
      y = windowHeight - el.offsetHeight - 10
    }

    this.setState({x, y})
  }

  render() {
    let {x, y} = this.state

    return <div
      {...this.props}
      onClick={preventDefault}
      style={Object.assign({}, {
        left: x
        , top: y
        , position: 'fixed'
        , zIndex: 10000
      }, this.props.style)}
      className={classnames('overlay', this.props.className)}>
      {this.props.children}
    </div>
  }

}
