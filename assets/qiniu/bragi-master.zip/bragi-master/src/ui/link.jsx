import "./link.scss"

import React from "react"
import classnames from "classnames"
import douradio from "douradio"
import IconPlay from "icons/icon-play"
import isString from "lodash/isString"
// import ga from 'utils/analytics'


// move some scss helper to purejs

export default class Link extends React.Component {

  static defaultProps = {
    trigger: true
    , href: null
    , target: null
    , tag: 'a'
    , ga: {}
  }

  onClick(e) {
    e.preventDefault()
    e.stopPropagation()

    if(this.props.onClick) {
      this.props.onClick(e)
    }

    if(this.props.ga) {
      let data = this.props.ga
      ga('send', {
        hitType: 'event'
        , eventCategory: data.category
        , eventAction: data.action
        , eventLabel: data.label
        , eventValue: data.value
      })
    }

    let href = this.props.href

    if(
      href.match(/(https?\:)?\/\/(.*)/) || href.slice(0, 6) === 'mailto'
    ){
      return window.open(href, this.props.target)
    }

    return window.app.navigate(
      this.props.href,
      {trigger: this.props.trigger}
    )
  }

  render() {
    let title

    if(isString(this.props.children)) {
      title = this.props.children
    }

    return React.createElement(this.props.tag, {
      // ...this.props
      style: this.props.style
      , onClick: this.onClick.bind(this)
      , className: classnames('link', this.props.className)
      , title: title
    }, this.props.children)
  }
}

export class ChannelLink extends React.Component {

  static defaultProps = {
    color: '#4A4A4A'
    , iconColor: '#C6C6C6'
    , iconSize: 12
  }

  onPlay(e) {
    e.preventDefault()
    return douradio.switchChannel.call(
      douradio, this.props.id
    )
  }

  render() {
    return <a
      className={classnames('playable-link', this.props.className)}
      onClick={this.onPlay.bind(this)}
      style={{color: this.props.color}}
    >
      {this.props.icon ? this.props.icon
        : <IconPlay size={this.props.iconSize} i="play" color={this.props.iconColor}></IconPlay>}
      <span style={{color: this.props.color}}>{this.props.children}</span>
    </a>
  }

}

export class SonglistLink extends ChannelLink {
  static defaultProps = {
    color: '#4A4A4A'
    , iconColor: '#C6C6C6'
    , iconSize: 12
  }

  onPlay(e) {
    e.preventDefault()
    if(this.props.songlist) {
      return douradio.switchSonglist(this.props.songlist)
    } else {
      return douradio.switchSonglist(this.props.id)
    }
  }
}
