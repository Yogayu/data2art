import "./popup.scss"
// popup layer for pages like <Songlist, Song, Artist>
import React from "react"
import ReactDOM from "react-dom"
import Scrollbar from "ui/scrollbar"

// import defaults from 'lodash/object/defaults'
import isBoolean from "lodash/isBoolean"
// import Backbone from 'backbone'

import "gsap/TweenLite"
import "gsap/plugins/CSSPlugin"
import "gsap/easing/EasePack"

// flow
//   hidden -> show
//     render an empty block, ANIMATION_INIT
//     animtion: ANIMATION_ONGOING
//     render as normal: ANIMATION_FINISHED
//
//   show -> hidden
//     hide the context(make block empty)
//     animation
//     render as null
//
// so there are 6 states here

// no animation
const ANIMATION_INIT = 0 // prepare for the animation
const ANIMATION_ONGOING = 1 // animation ongoing
const ANIMATION_FINISHED = 2 // animation not start or finished

export default class Popup extends React.Component {

  static defaultProps = {
    top: "50%"
    , left: "50%"
    , width: 0
    , height: 0
    , hidden: false
  }

  constructor(props) {
    super(props)

    this.state = {
      animationStatus: ANIMATION_FINISHED
    }
  }

  // animation related
  shouldComponentUpdate(nextProps, nextState) {
    return true

    // if animation is ongoing, do not trigger rerender
    let as = nextState.animationStatus !== undefined
      ? nextState.animationStatus : this.state.animationStatus

    if(as === ANIMATION_ONGOING) {return false}

  }

  componentDidMount() {
    this.setState({
      animationStatus: ANIMATION_INIT
    })
  }

  componentWillUnmount() {
    if(this.animator) {
      this.animator.kill()
      this.animator = null
    }
  }

  componentWillReceiveProps(nextProps) {
    // console.debug(nextProps)
    if(!isBoolean(nextProps.hidden)) {
      return
    }

    if(!this.props.hidden && nextProps.hidden) {
      // from show -> hidden
      this.setState({
        animationStatus: ANIMATION_INIT
        , animationReverse: true
      })
    } else if (this.props.hidden && !nextProps.hidden) {
      // from hidden -> show
      this.setState({
        animationStatus: ANIMATION_INIT
        , animationReverse: false
      })
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if(this.state.animationStatus === ANIMATION_INIT) {
      // console.log('do animating ', this.state.animationReverse)
      this.doAnimation(this.state.animationReverse)
    }
  }

  doAnimation(reverse) {
    return

    if(!reverse) {
      reverse = this.props.hidden
    }

    let el = ReactDOM.findDOMNode(this)

    if(this.animator) {
      this.animator.kill()
    }

    let startPoint = {
      left: this.props.left,
      top: this.props.top,
      height: this.props.height,
      width: this.props.width,
      opacity: 1
    }

    let endPoint = {
      // ease: window.Elastic.easeOut.config(2.5, 1),
      top: 0,
      left: 0,
      width: window.innerWidth,
      height: window.innerHeight,
      opacity: 1
    }

    if(reverse) {
      this.animator = window.TweenLite.to(
        el, 0.3, startPoint
      )
    } else {
      this.animator = window.TweenLite.fromTo(el, 0.3, startPoint, endPoint)
    }

    this.state.animationStatus = ANIMATION_ONGOING
    this.animator.eventCallback("onComplete", () => {
      if(!this.animator) {
        return
      }
      // console.info('[Animation] Ends')
      this.setState({animationStatus: ANIMATION_FINISHED})
      reverse ? this.onClose() : this.onOpen()
    })
  }

  /**
   * @todo
   *  navigate to / or remember the url when you open the overlay
   */
  onClose() {
    return this.props.onClose && this.props.onClose()
    // app.root.hideOverlay("*")
    // Backbone.history.navigate('/', {trigger: false})
  }

  onOpen() {}

  onScroll(e) {
    e.stopPropagation()
  }

  onWheel(e) {
    // console.log(e)
    e.preventDefault()
    e.stopPropagation()
  }

  render() {
    // if(this.state.animationStatus === ANIMATION_FINISHED && this.props.hidden) {
    //   return null
    // }

    // {this.state.animationStatus === ANIMATION_INIT ?
    //   null : this.props.children
    // }

    return <div
      onScroll={this.onScroll.bind(this)}
      onWheel={this.onWheel.bind(this)}
      className="popup"
      style={{
        position: "fixed"
        , zIndex: this.props.baseZIndex || 500
        , background: 'rgba(255, 255, 255, .95)'
        , overflowY: 'hidden'
        , top: 0
        , left: 0
        , width: window.innerWidth
        , height: this.props.height || window.innerHeight
        , opacity: 1
      }}>
      <Scrollbar>
        {this.props.children}
      </Scrollbar>
    </div>
  }
}
