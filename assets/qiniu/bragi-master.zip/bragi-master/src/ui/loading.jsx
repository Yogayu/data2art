import "scss/ui/_loading.scss"
import classNames from "classnames"
import React from "react"

let Loading = ({className, style}) => {

  return <div
    className={classNames({
      loader: true
      , center: true
    }, className)}
    style={style}>
    <div className="c-1">
      <div className="c-2">
        <div className="c-3"></div>
      </div>
    </div>
  </div>
}

export default Loading
