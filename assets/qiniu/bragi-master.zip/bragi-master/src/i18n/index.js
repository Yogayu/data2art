let trans_zh = {
  GUIDE_INPUT_TO_SEARCH: '输入你喜欢的艺术家，歌曲，或者风格<br>接下来豆瓣FM会由这里开始，带你进入意想不到的音乐世界',
  GUIDE_OR_TRY: '或者，来试试',
  GUIDE_TASTE_TEST: '音乐口味测试',
  GUIDE_SEARCH_PLACEHOLDER: '输入',

  SEARCH_ARTIST_TITLE: '艺术家',
  SEARCH_ARTIST_DESCRIPTION: '「艺术家 系 MHz」包含搜索艺术家歌曲，以及与其相似的艺术家歌曲',
  SEARCH_SONG_TITLE: '单曲',
  SEARCH_SONG_DESCRIPTION: '「单曲 MHz」包含搜索歌曲以及与它类似的歌曲',
  SEARCH_PROGRAMME_TITLE: '节目',
  SEARCH_PROGRAMME_DESCRIPTION: '「单曲 MHz」包含搜索歌曲以及与它类似的歌曲',
  SEARCH_CHANNEL_TITLE: '流派/风格/心情/场景 MHz',
  SEARCH_CHANNEL_DESCRIPTION: '',
  SEARCH_HOT_SONGS: '单曲 MHz',
  SEARCH_MORE: '更多',
  SEARCH_GUESS_ARTIST: '艺术家 MHz',
  SEARCH_HOT_SONG: '单曲 MHz',
  SEARCH_GUESS_HOT: '热门',
  SEARCH_GUESS_INTEREST: '你可能感兴趣的',
  SEARCH_NO_RESULT: '没有找到',

  COMMON_DOUBAN_FM: '豆瓣FM',
  COMMON_SEARCH_PLACEHOLDER: '艺术家 / 单曲 / 风格 / 场景',

  COMMON_LOGIN: '登录',
  COMMON_REGISTER: '注册',

  LYRIC_LOADING: '歌词载入中',
  LYRIC_NO_FOUND: '暂无歌词',
  LYRIC_NO_SUPPORT_SCROLL: '本歌词暂不支持自动滚动',
  GUESS_PROGRAMMES: '你可能喜欢',
  HOT_PROGRAMMES: '热门',
  MINE_SONG_BANNED: '不再播放的歌曲',
  MINE_SONG_LIKED: '红心歌曲',
  MINE_SONG_PLAYED: '累计收听',
  MINE_FAV_PROGRAMME: '收藏节目',
  MINE_FAV_CHANNEL: '收藏MHz',

  // playing
  PLAYING_VIEW_ALBUM: '查看专辑信息',

  // menu
  MENU_SENT_TO_PHONE: '离线这首歌到手机',
  MENU_SHARE_SONG: '分享这首歌',
  MENU_SIMILAR_SONG: '收听相似歌曲',
}

export default function(s, lang="zh") {
  let found
  found = trans_zh[s.toUpperCase()]
  if (found) {
    return found
  }
  return s
};
