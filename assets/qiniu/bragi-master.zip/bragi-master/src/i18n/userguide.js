import isFunction from 'lodash/isFunction'
import isString from 'lodash/isString'

// i18n.configFrom('http://dobuan.fm/j/v2/i18n')
let trans = {
  // user guide main
  'title': '挑选你喜欢的艺术家，开启私人音乐之旅'
  , 'replace_all': '换一批'
  , 'go_search': '自己搜'

  , 'like': '喜欢'
  , 'cancel_like': '取消喜欢'
  , 'liked': '已喜欢'

  , 'skip_and_start_listening': '跳过，直接去听歌'
  , 'start_listening_artist_name': artistName => `先选这些，开始收听从 ${artistName} 出发的音乐`

  , 'will_play_top_channel': '即将为你播放包含各种乐风的豆瓣精选兆赫...'
  , 'will_play_personal_channel': '即将为你播放我的私人兆赫'

  , 'personal_channel': '我的私人兆赫'

  // search artist page
  , 'search_for_artist': '搜索你喜欢的艺术家'
  , 'search_no_result': '没有找到'

  // login related
  , 'go_login': '已有账号登录'
  , 'is_keep_history': '还想保留登录之前的收听历史吗？'


  // after login
  , 'merge_notify': (played, liked, baned, channels, artists) => {
    return `你在豆瓣FM听过${played}首歌曲，标记了${liked}首红心歌曲，${banned}首不再收听，收藏了${channels}个兆赫，喜欢了${artists}个艺术家`
  }
  , 'keep': '保留'
  , 'no_keep': '不保留'

  // tips
  , 'tip_artist_channel': '包含和该艺术家相似的一些艺术家的歌曲'
}

export default function i18n(str, ...args) {
  let item = trans[str]

  if(isFunction(item)) {
    return item.apply(null, args)
  } else if(isString(item)) {
    return item
  } else {
    console.warn('[i18n] no translate found here')
    return str
  }

}
