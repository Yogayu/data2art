import React from "react"
import {Provider} from "react-redux"

import configureStore from "./store"
import Container from "./container"

import ss, {KEY_IS_SHOWED_USERGUIDE} from 'controllers/stores'

let store = configureStore(Object.assign({
  isInSearch: false
  // , isFinished: true
  , isFinished: false

  , isShowLogin: false
  , userinfo: null

  , guessArtists: {
    isFetching: false
    , artists: []
  }

  // keep an record of artists
  , artists: {}

  , searchResults: {
    keyword: ''
    , isFetching: false
    , artists: []
  }

  , choosedArtists: []
}, {}))


// function saveState(state) {
//   let choosedArtists = state.choosedArtists
//   ss.set(KEY_CHOOSED_ARTSITS, {
//     choosedArtists
//     , artists: pick(state.artists, choosedArtists)
//   })
// }

import douradio from 'douradio'
import last from 'lodash/last'
import set from "lodash/set"
import {USER_LOGIN, initUserGuide} from './actions'
import log from '../utils/log'

export default function setup(options) {
  douradio.getCurrentUser().then((userinfo) => {
    store.dispatch({
      type: USER_LOGIN
      , userinfo: userinfo
    })
  })
  log('userguide', 'start')

  initUserGuide(store.dispatch)

  douradio.isPlaying() ? douradio.togglePause() : null

  let unsubscribe = store.subscribe(() => {
    let state = store.getState()
    if(state.isFinished) {
      let userinfo = state.userinfo
      , ca = state.choosedArtists
      , showUserTips = true

      if(userinfo.is_personal_service_enabled) {
        // "old" user login through userguide
        showUserTips = false
        douradio.switchChannel(0)
      } else if(ca.length === 0) {
        // exit without choose any
        ss.set(KEY_IS_SHOWED_USERGUIDE, true)
        douradio.switchChannel(-10)
        log('userguide', 'quit')
      } else if (ca.length < 5) {
        let aid = last(state.choosedArtists)
        , artist = state.artists[aid]
        ss.set(KEY_IS_SHOWED_USERGUIDE, true)
        douradio.switchChannel(artist.channel || -10)
        log('userguide', 'quit')
      } else {
        set(douradio, ['options', 'userinfo', 'is_personal_service_enabled'], true)
        douradio.switchChannel(0)
        ss.deleteKey(KEY_IS_SHOWED_USERGUIDE)
        log('userguide', 'finish')
      }
      unsubscribe()
      douradio.off(null, null, store)
      options.onFinish(showUserTips)
    }
  })

  return <Provider store={store}>
    <Container></Container>
  </Provider>
}
