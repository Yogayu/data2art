import React from 'react'
import ArtistAvatar from './ArtistAvatar'
import styles from './ArtistAvatar.module.css'
import i18n from 'i18n/userguide'


class LikeButton extends React.Component {

  static defaultProps = {
    nohover: false
  }

  constructor(props) {
    super(props)
    this.state = {
      hover: false
    }
  }

  onMouseEnter() {
    if(this.props.isLiked) {
      this.setState({hover: true})
    }
  }

  onMouseLeave() {
    if(this.props.isLiked) {
      this.setState({hover: false})
    }
  }

  render() {
    return <a
      onMouseEnter={this.props.nohover ? null : this.onMouseEnter.bind(this)}
      onMouseLeave={this.props.nohover ? null : this.onMouseLeave.bind(this)}
      onClick={this.props.onClick}
      className={styles.likeButton}>
      {this.props.isLiked ?
        (this.state.hover ? i18n('cancel_like') : i18n('liked'))
        : i18n('like')}
    </a>
  }

}


function Artist(props) {
  let {
    style, id, avatar, name_usual, onClick, liked, hidden, nohover=false
    , size=100
  } = props
  return <div
    className={hidden ? styles.hidden : null}
    style={Object.assign({
      display: 'inline-block'
      , marginRight: '40px'
      , marginTop: 25
      , textAlign: 'center'
    }, style)}>

    <ArtistAvatar
      src={avatar}
      choosed={liked}
      size={size}
    ></ArtistAvatar>
    <div className={styles.artistTitle} title={name_usual}>{name_usual}</div>
    <LikeButton nohover={nohover} onClick={onClick} isLiked={liked}></LikeButton>
  </div>
}

export default Artist
