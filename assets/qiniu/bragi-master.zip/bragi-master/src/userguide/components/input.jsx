import SearchInput from 'views/search/input'
import React from 'react'
import cls from 'classnames'
import styles from './input.module.css'
import IconSearch from 'icons/icon-search'
import {IconClose} from 'icons'
import i18n from 'i18n/userguide'


export default class CustomInput extends SearchInput {

  render() {
    return <div
      className={cls("search-input-wrapper", styles.search)}
      onClick={this.onClick.bind(this)}
    >
      <IconSearch size={16} color={'#62646c'}></IconSearch>

      <input
        ref="search"
        type="text"
        className="search"
        placeholder={i18n('search_for_artist')}
        value={this.value}
        onFocus={this.onFocus.bind(this)}
        onBlur={this.onBlur.bind(this)}
        onChange={this.onChange.bind(this)}
      />

    {this.value ? <a
      className="button-close"
      onClick={this.onClear.bind(this)}
      href="#search">
        <IconClose
          size={13}
          color={'#ffffff'}
          center={true}
        ></IconClose>
      </a> : null}
    </div>
  }

}
