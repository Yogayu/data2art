import LoginDialog from 'views/login'
import React from 'react'
import ReactDOM from 'react-dom'
import shallowCompare from 'react/lib/shallowCompare'
import IconAngle from 'icons/icon-angle'

import styles from '../container/base.module.css'

export default class LoginPage extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      marginTop: 0
      , width: 478
    }
  }

  onBack(e) {
    e.preventDefault()
    this.props.closeLogin()
  }

  autoCenter() {
    let el = ReactDOM.findDOMNode(this.refs.inner)
    // console.log('autoWidth', el)

    this.setState({
      marginTop: (580 - el.offsetHeight) / 2
      , width: el.offsetWidth
    })
  }

  componentDidMount() {
    this.autoCenter()
  }

  componentDidUpdate() {
    this.autoCenter()
  }

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  onLoginSuccess() {
    this.autoCenter()
    this.props.onSuccess()
  }

  onFinish() {
    this.props.closeLogin()
  }

  render() {
    return <div className={styles.container}>
      <div style={{float: 'left', margin: '25px 0 0 25px'}}>
        <a
          className={styles.link} href="" onClick={this.onBack.bind(this)}
          style={{color: '#62646c'}}
        >
          <IconAngle size={13} color={'#62646c'} direction={'left'}></IconAngle>
          &nbsp;
          返回
        </a>
      </div>

      <div style={{
        margin: '0 auto'
        , position: 'relative'
        , top: this.state.marginTop
        , width: this.state.width
      }}>
        <LoginDialog
          ref={'inner'}
          {...this.props}
          onLoginSuccess={this.onLoginSuccess.bind(this)}
          onFinish={this.onFinish.bind(this)}
          height={391}
        ></LoginDialog>
      </div>
    </div>
  }

}
