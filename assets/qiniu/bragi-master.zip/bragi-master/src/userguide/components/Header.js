import React from 'react'
import Cover from 'components/cover'
import styles from './header.module.css'
import IconAngle from 'icons/icon-angle'
import i18n from 'i18n/userguide'

function Header ({userinfo, onLogin}) {
  let isLogin = !!userinfo && userinfo.user_id

  return <div className={styles.header}>
    {isLogin ? <span>
      &nbsp;
      <Cover className={styles.cover} src={userinfo.icon} size={22} rounded={true}></Cover>
      <span className={styles.username}>{userinfo.name}</span>
    </span> : <a href="#" onClick={function (e) {
      e.preventDefault()
      onLogin()
    }} className={styles.linkGreen}>
      {i18n('go_login')}
      &nbsp;
      <IconAngle version={2} color={'#2f9842'} direction={'right'} size={13}></IconAngle>
    </a>}
  </div>
}

export default Header
