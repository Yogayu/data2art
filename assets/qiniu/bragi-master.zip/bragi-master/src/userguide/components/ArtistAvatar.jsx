// Global Components
import Cover from 'components/cover'
import styles from './ArtistAvatar.module.css'
import IconRight from 'icons/icon-right'
import {IconClose} from 'icons'

import React from 'react'

export default function ArtistAvatar(props) {
  // size: 120 or 42
  let {
    src, size, choosed, hasRight=true, hasClose=false, clickAble=false, border=null
  } = props

  return <Cover size={size} rounded={true} src={src} className={styles.avatar}
    style={{
      border: border
    }}
  >
    <div className={styles.choosed} style={{
      lineHeight: `${size}px`
      , height: size
      , opacity: choosed ? 1 : 0
      , cursor: clickAble ? 'pointer' : null
    }}>
      {hasRight ?
        <IconRight color="#ffffff"></IconRight> : null}

      {hasClose ?
        <IconClose className={styles.hoverShow} hasCircle={false} color="#ffffff"></IconClose> : null}
    </div>
  </Cover>
}
