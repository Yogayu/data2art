# User Guide sub application

# what the hell redux is?

```javascript
// 比如你想把store里面 isFucked 改成 false
// 在backbone里是这样的：
store.set({isFucked: false})

// 在view里面
store.on('change:isFucked', function () {this.forceUpdate()}, this)

// 在Redux里，你首先得定义action
const TOGGLE_IS_FUCKED = 'toggle_is_fucked'

function toggleIsFucked(isFucked) {
  dispatch({
    type: TOGGLE_IS_FUCKED
    , value: isFucked
  })
}

// 然后

function isFuckedReducer(store, action) {
  if(action.type === TOGGLE_IS_FUCKED) {
    return Object.assign({}, store, {
      isFucked: action.value
    })
  }
}

// 然后怎么去监听这里的change，通知ui，还没搞懂
```

# Multiple Build
