import {combineReducers} from "redux";
import zipObject from "lodash/zipObject";
import concat from "lodash/concat";
import without from "lodash/without";
import findIndex from 'lodash/findIndex'
import clone from 'lodash/clone'

import {
  REFRESH_ARTISTS
  , INIT_USER_GUIDE
  , REQUEST_ARTISTS
  , REPLACE_ARTIST

  , LIKE_ARTIST
  , UNLIKE_ARTIST
  , TOGGLE_SEARCH_DIALOG
  , REQUEST_SEARCH
  , RESPONSE_SEARCH

  , FINISH_GUIDE
  , REOPEN_GUIDE

  , OPEN_LOGIN
  , CLOSE_LOGIN
  , USER_LOGIN
} from "./actions";

function guessArtists(state = {}, action) {
  switch (action.type) {
    case REQUEST_ARTISTS:
      return Object.assign({}, state, {
        isFetching: true
      })
    case REFRESH_ARTISTS:
      return Object.assign({}, state, {
        isFetching: false
        , artists: action.artists.map((ar) => {return ar.id})
      })
    case REPLACE_ARTIST:
      let {artist, toReplace} = action
      , i = state.artists.indexOf(toReplace.id)
      if(i < 0) {
        return state
      }

      let nr = clone(state.artists)
      nr[i] = artist.id
      return Object.assign({}, state, {
        artists: nr
      })
    default:
      return state
  }
}

function choosedArtists(state = [], action) {
  switch (action.type) {
    case LIKE_ARTIST:
      // if(state.length >= 5) {return state}
      if(state.indexOf(action.id) >= 0) {
        return state
      }
      return concat(state, action.id)
    case UNLIKE_ARTIST:
      return without(state, action.id)
    case INIT_USER_GUIDE:
      return action.artists.map(function (ar) {return ar.id})
    default:
      return state
  }
}

function artists(state = {}, action) {
  let artist

  switch (action.type) {
    case REFRESH_ARTISTS:
    case RESPONSE_SEARCH:
    case INIT_USER_GUIDE:
      let artists = action.artists
      return Object.assign(
        {},
        state,
        zipObject(artists.map((ar) => ar.id), artists)
      )
    case REPLACE_ARTIST:
      let artist = action.artist
      return Object.assign(
        {}, state, {
          [artist.id]: artist
        }
      )
    case LIKE_ARTIST:
      artist = state[action.id]
      return Object.assign({}, state, {
        [action.id]: Object.assign({}, artist, {liked: true})
      })
    case UNLIKE_ARTIST:
      artist = state[action.id]
      return Object.assign({}, state, {
        [action.id]: Object.assign({}, artist, {liked: false})
      })
    default:
      return state
  }
}

function isInSearch(state = false, action) {
  if(action.type === TOGGLE_SEARCH_DIALOG) {
    return !state
  }
  return state
}

function searchResults(state = {}, action) {
  // scema:
  // searchResults: {
  //   keyword: ''
  //   , isFetching: false
  //   , artists: []
  // }

  if(action.type === TOGGLE_SEARCH_DIALOG) {
    return {keyword: '', isFetching: false, artists: []}
  } else if(action.type === REQUEST_SEARCH) {
    return {keyword: action.keyword, isFetching: true, artists: state.artists}
  } else if(action.type === RESPONSE_SEARCH) {
    return {
      keyword: state.keyword
      , isFetching: false
      , artists: action.artists.map(function (ar) { return ar.id })
    }
  }

  return state
}

function isFinished(state=false, action) {
  if(action.type === FINISH_GUIDE) {
    return true
  } else if(action.type === INIT_USER_GUIDE) {
    return false
  }
  return state
}

function isShowLogin(state=false, action) {
  // console.debug(action)
  if(action.type === OPEN_LOGIN) {
    return true
  } else if (action.type === CLOSE_LOGIN) {
    return false
  }
  return state
}

function userinfo(state=null, action) {
  if(action.type === USER_LOGIN) {
    return action.userinfo
  }
  return state
}

const rootReducer = combineReducers({
  guessArtists
  , searchResults
  , choosedArtists
  , artists
  , isInSearch
  , isFinished
  , isShowLogin
  , userinfo
})

export default rootReducer
