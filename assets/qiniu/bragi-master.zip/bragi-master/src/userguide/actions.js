import request from "utils/request"
import douradio from 'douradio'
import log from 'utils/log'

// export const
export const INIT_USER_GUIDE = 'init_user_guide'

export const REFRESH_ARTISTS = 'refresh_artists'
export const REQUEST_ARTISTS = 'request_artists'
export const LIKE_ARTIST = 'like_artist'
export const UNLIKE_ARTIST = 'unlike_artist'

export const REPLACE_ARTIST = "replace_artist"

export const TOGGLE_SEARCH_DIALOG = 'toggle_search_dialog'

export const REQUEST_SEARCH = 'request_search'
export const RESPONSE_SEARCH = 'response_search'

export const FINISH_GUIDE = 'finish_userguide'

// login related
export const OPEN_LOGIN = 'open_login'
export const CLOSE_LOGIN = 'close_login'
export const USER_LOGIN = 'user_login'

//
export const ARTISTS_LIMIT = 10


function refreshArtists(artists) {
  return (dispatch) => {
    dispatch({
      type: REFRESH_ARTISTS
      , artists: artists
    })
  }
}

export function likeAndReplaceArtist(oldArtist) {
  log('userguide', 'like_from_guess')

  return (dispatch) => {
    request({
      url: '/artist/' + oldArtist.id + '/like'
      , method: 'put'
    })

    dispatch({
      type: LIKE_ARTIST
      , id: oldArtist.id
    })

    return request({
      'url': 'artist/guess'
      , 'data': {'limit': 1, 'is_new_user': true}
    }).then(function (resp) {
      let artists = resp.artists
      if(artists.length > 0) {
        window.setTimeout(function () {
          dispatch({
            type: REPLACE_ARTIST
            , toReplace: oldArtist
            , artist: artists[0]
          })
        }, 1000)
      }
    })
  }
}

export function initUserGuide(dispatch) {
  dispatch({type: INIT_USER_GUIDE, artists: []})

  return request({
    'url': '/artist/user_liked'
    , data: {limit: ARTISTS_LIMIT}
  }).then((response) => {
    dispatch({
      type: INIT_USER_GUIDE
      , artists: response.artists.reverse()
    })
  })
}

export function fetchArtists (logEvent) {
  if(logEvent) {
    log('userguide', logEvent)
  }

  return (dispatch) => {
    dispatch({
      type: REQUEST_ARTISTS
    })

    return request({
      'url': 'artist/guess'
      , 'data': {
        'limit': ARTISTS_LIMIT
        , 'is_new_user': true
      }
    }).then((response) => {
      dispatch({
        type: REFRESH_ARTISTS
        , artists: response.artists
      })
    }, (err) => {
      // so you need to define something
      console.log('Something error happens')
    })
  }
}

export function likeAnArtist (artistId) {
  return (dispatch) => {
    request({
      url: '/artist/' + artistId + '/like'
      , method: 'put'
    })

    dispatch({
      type: LIKE_ARTIST
      , id: artistId
    })
  }
}

export function unlikeAnArtist (artistId) {
  log('userguide', 'unlike')

  return (dispatch) => {
    request({
      url: '/artist/' + artistId + '/like'
      , method: 'delete'
    })

    dispatch({
      type: UNLIKE_ARTIST
      , id: artistId
    })
  }
}

export function toggleLikeArtist (artist) {
  log('userguide', 'like_from_search')

  return (artist.liked ? unlikeAnArtist : likeAnArtist)(artist.id)
}

export function toggleSearchDialog () {
  log('userguide', 'search')

  return (dispatch) => {
    dispatch({type: TOGGLE_SEARCH_DIALOG})
  }
}

let searchRequest = null

export function searchResults (keyword) {
  if(searchRequest) {
    searchRequest.abort()
  }

  return (dispatch) => {
    dispatch({type: REQUEST_SEARCH, keyword: keyword})

    if(!keyword) {
      return dispatch({
        type: RESPONSE_SEARCH
        , artists: []
        , keyword: keyword
      })
    }

    request({
      'url': 'query/artist'
      , 'data': {
        'q': keyword
        , 'limit': 5
      }
    }).then(function (result) {
      dispatch({
        type: RESPONSE_SEARCH
        , artists: result.items
        , keyword: keyword
      })
    })
    // dispatch({type: SEARCH, q: })
  }
}

export function finishGuide () {
  return (dispatch) => {
    dispatch({type: FINISH_GUIDE})
  }
}

// login related

export function openLogin () {
  return {type: OPEN_LOGIN}
}

export function closeLogin (states) {
  if(douradio.userinfo('is_personal_service_enabled')) {
    return {type: FINISH_GUIDE}
  } else {
    return {type: CLOSE_LOGIN}
  }
}

export function loginSuccess() {
  return (dispatch) => {
    douradio.getCurrentUser(true).then((userinfo) => {
      dispatch({type: USER_LOGIN, userinfo: userinfo})
    })
  }
}
