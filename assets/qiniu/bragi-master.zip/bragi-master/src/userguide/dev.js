import AppComponent from './index'
import {render} from "react-dom";

render(
  <AppComponent></AppComponent>,
  document.getElementById('app')
)
