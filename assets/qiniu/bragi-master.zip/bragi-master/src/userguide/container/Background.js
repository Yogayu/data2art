import React from 'react'
import {connect} from "react-redux"
import first from "lodash/first"
import last from 'lodash/last'
import styles from './bg.module.css'
import BluredImage from 'components/BluredImage'


class Background extends React.Component {

  render() {
    let width = 580
    , imgWidth = 222

    return <div className={styles.bg}>
      <div className={styles.over}></div>

      <BluredImage
        src={this.props.firstArtist.avatar}
        className={styles.cover}
        alt=""
        style={{
          left: '50%'
          , marginLeft: -1.5 * imgWidth - width / 2
        }}
      />
      <BluredImage
        className={styles.cover}
        src={this.props.lastArtist.avatar} alt=""
        style={{
          right: '50%'
          , marginRight: -1.5 * imgWidth - width / 2
        }}
      />
    </div>
  }

}

function mapStateToProps(state) {
  let artists = state.artists
  , guessArtists = state.guessArtists.artists

  function toArtist(id) {
    return artists[id] || {}
  }

  return {
    firstArtist: toArtist(first(guessArtists))
    , lastArtist: toArtist(last(guessArtists))
  }
}

export default connect(mapStateToProps, function () {return {}})(Background)
