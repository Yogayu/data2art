import connect from './connect'
import React from 'react'
import styles from './base.module.css'
import SearchInput from '../components/input'
import Artist from '../components/Artist'
import Loading from "ui/loading"
import ChoosedArtists from './ChoosedArtists.js'
import i18n from 'i18n/userguide'

function Search (props) {
  let {keyword, artists, isFetching, toggleLikeArtist, toggleSearchDialog, searchResults} = props
  , hasResult = artists.length > 0
  , hasInput = !!keyword.trim() || hasResult // artists.length > 0 || (!!keyword.trim() && isFetching)

  return <div
    className={styles.searchContainer}
  >
    <div className={styles.searchOverlay}></div>

    <div className={styles.searchInner}
      style={{
        paddingTop: hasInput ? 80 : 200
      }}
    >
      <div className={styles.inputWrapper}>
        <SearchInput value={keyword} onSearch={function (value) { searchResults(value) }} />
        <a href={'#'} className={styles.linkCancel} onClick={function (e) {
          e.preventDefault()
          toggleSearchDialog()
        }}>取消</a>
      </div>

      {isFetching ? <Loading></Loading> : null}

      <div style={{textAlign: 'left', marginBottom: 70}}>
      {hasResult ? artists.map(
        (artist) => {
          return <Artist
            style={{
              marginRight: 20
            , marginLeft: 20
            , marginTop: 0
            }}
            key={artist.id} {...artist}
            onClick={toggleLikeArtist.bind(null, artist)}></Artist>
        }
      ): null}

      {!hasResult && !!keyword && !isFetching ?
        <p style={{textAlign: 'center'}}>{i18n('search_no_result')}</p>
        : null}
      </div>
    </div>
  </div>
}

export default connect(function mapStateToProps (state) {
  let sr = state.searchResults
  , artists = sr.artists.map(function (id) {
    return state.artists[id]
  })

  return Object.assign({}, sr, {
    artists
  })
})(Search)
