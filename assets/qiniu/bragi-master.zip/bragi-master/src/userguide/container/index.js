import React from 'react'
// import {bindActionCreators} from "redux";
// import {connect} from "react-redux";
// import * as actions from "../actions";
import connect from './connect'
import Artists from './Artists'
import ChoosedArtists from './ChoosedArtists'
import Search from './Search'

import styles from './base.module.css'

import IconSearch from 'icons/icon-search'
import {IconRefresh} from "icons"

import LoginWrapper from '../components/LoginWrapper'

import Header from '../components/Header'
import Background from './Background'

import i18n from 'i18n/userguide'

const offset = 85

class Overlay extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      zIndex: -1
      , opacity: 0
    }
  }

  componentWillReceiveProps(nextProps) {
    const zindex = 2000

    if(nextProps.show && !this.props.show) {
      if(this.timeHandler) {
        window.clearTimeout(this.timeHandler)
        this.timeHandler = null
      }

      // hidden -> show
      this.setState({
        opacity: 1
        , zIndex: zindex
        , display: 'block'
        , transitionDelay: '0s'
        , transitionDuration: '1s'
      })

    } else if(!nextProps.show && this.props.show) {
      // show hidden
      this.setState({
        opacity: 0
        , zIndex: zindex
        , display: 'block'
        , transitionDelay: '1s'
        , transitionDuration: '1s'
      })

      this.timeHandler = window.setTimeout(() => {
        this.setState({
          zIndex: -1
        })
      }, 1000)

    }

  }

  // componentDidUpdate() {}

  render() {
    let canOpenPersonalChannel = this.props.show

    return <div
      style={Object.assign({
        height: '100%'
        , transition: 'all .3s ease-out'
      }, this.state)}
      className={styles.overlay}>
    </div>
  }

}

class App extends React.Component {
  componentWillMount() {
    this.props.fetchArtists()
  }

  render() {
    let {
      isFinished,
      isInSearch,
      fetchArtists,
      toggleSearchDialog,
      openLogin,
      closeLogin,
      loginSuccess,
      isShowLogin,
      userinfo
    } = this.props
    , inner = null

    if(isShowLogin) {
      inner = <LoginWrapper
        closeLogin={closeLogin}
        onSuccess={loginSuccess}
      ></LoginWrapper>
    } else {
      let isFetching = this.props.guessArtists.isFetching
      , canOpenPersonalChannel = this.props.choosedArtists.length >= 5

      inner = <div className={styles.container}>
        <Header userinfo={userinfo} onLogin={openLogin}></Header>

        <Overlay show={canOpenPersonalChannel}></Overlay>

        <h1 className={styles.title}>{i18n('title')}</h1>

        <Artists></Artists>

        <div className={styles.buttons}>
          <a className={styles.btn}
            style={{marginRight: 40}}
             onClick={(e) => {
            e.preventDefault()
            fetchArtists('guess')
          }} href="#">
            <IconRefresh
              className={isFetching ? styles.fetching : null}
              size={14}
              color={'#8f8e94'}
              style={{marginRight: 5, top: -1, position: 'relative'}}
            ></IconRefresh>
            {i18n('replace_all')}
          </a>

          <a className={styles.btn} onClick={(e) => {
            e.preventDefault()
            toggleSearchDialog()
          }} href="#">
            <IconSearch size={18}
              color={'#8f8e94'}
              style={{
                marginRight: 6
                , position: 'relative'
                , top: -1
              }}
            ></IconSearch>
            {i18n('go_search')}
          </a>
        </div>
        <ChoosedArtists></ChoosedArtists>

        {isInSearch ? <Search></Search> : null}
      </div>
    }

    return <div className="outer">
      {inner}
      <Background></Background>
    </div>
  }

}

export default connect(function mapStateToProps (state) {
  return state
})(App)
