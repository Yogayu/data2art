import React from 'react'
import connect from './connect'
import ArtistAvatar from '../components/ArtistAvatar'
import styles from './base.module.css'
import IconPlay from 'icons/icon-play'
import last from 'lodash/last'
import IconAngle from 'icons/icon-angle'
import i18n from 'i18n/userguide'

function Artist({id, avatar, onClick, name_usual}) {
  return <div
    className={styles.choosedArtist}
    onClick={function (e) {
    e.preventDefault()
    onClick(id)
  }}>
    <ArtistAvatar
      src={avatar}
      rounded={true}
      choosed={!!id}
      hasRight={false}
      hasClose={true}
      size={42}
      clickAble={!!id}
      border={'solid 1px #e1e1e1'}
    ></ArtistAvatar>
    <div className={styles.choosedArtistName}>{name_usual}</div>
  </div>
}

function getWillPlayText(artists, finished) {
  let artistNames = artists
    .filter(function (ar) { return !!ar.id })
    .map(function(ar) { return ar.name_usual })

  let name = last(artistNames)

  if(artistNames.length === 0) {
    return i18n('skip_and_start_listening')
    // return finished ? i18n('start_listening_top_channel') : i18n('skip_and_start_listening')
  } else {
    // return finished ? `即将为你播放包含 ${name} 的歌曲…` : `听 ${name} 的歌`
    return i18n('start_listening_artist_name', name)
  }
}

function ChoosedArtists({
  artists
  , unlikeAnArtist
  , canOpenPersonalChannel
  , isFinished
  , finishGuide
}) {
  let onPlay = (e) => {
    e.preventDefault()
    finishGuide()
  }

  let willPlay = (function() {
    if(canOpenPersonalChannel) {
      if(isFinished) {
        return <p className={styles.willPlayText}>{i18n('will_play_personal_channel')}</p>
      } else {
        return <a onClick={function (e) {
            e.preventDefault()
            finishGuide()}
          } className={styles.btnPlay} href={'#'}
          >
          <IconPlay color={'#ffffff'} size={15} style={{top: '-1px'}}></IconPlay>
          &nbsp;
          &nbsp;
          &nbsp;
          {i18n('personal_channel')}
        </a>
      }
    } else {
      return <p className={styles.willPlayText}>
        <a className={styles.link} href="" onClick={onPlay}>
          {getWillPlayText(artists, isFinished)}
          &nbsp;
          <IconAngle
            version={2}
            direction={'right'}
            size={13}
            style={{
              position: 'relative'
              , top: -1
            }}
          ></IconAngle>
        </a>
      </p>
    }
  })()

  return <div style={Object.assign({
    position: 'relative'
    , top: 0
    , transition: 'all .3s ease-out'
    , zIndex: 10000
    , transitionDelay: '0.5s'
  }, canOpenPersonalChannel ? {
    top: -300
    , transform: 'scale(1.1)'
  } : {})}>
    {artists.map(function(artist, index) {
      if(artist.id) {
        return <Artist
          {...artist}
          key={artist.id}
          onClick={unlikeAnArtist}
        ></Artist>
      } else {
        return <Artist {...artist} key={'default-' + index} onClick={function () {}}></Artist>
      }
    })}

    <div style={{marginTop: canOpenPersonalChannel ? 30 : 20}}>
      {willPlay}
    </div>
  </div>
}

export default connect(function mapStateToProps(state) {
  let defaultArtist = {
    id: null
    , avatar: '//img1.doubanio.com/f/fm/ccf59e9485e4db05d7bc6df8931a67f925636f91/pics/fm/artist/default_avatar/person_small.png'
  }

  let ca = state.choosedArtists.slice(0, 5)
  let canOpenPersonalChannel = ca.length >= 5

  let artists = ca.map(function (aid) {
    return state.artists[aid]
  })

  while(artists.length < 5) {
    artists.push(defaultArtist)
  }

  // if(hasSearchResult) {}

  // console.debug('ChoosedArtists', artists)
  // console.debug('isFinished', state.isFinished)

  return {artists, canOpenPersonalChannel, isFinished: state.isFinished}
})(ChoosedArtists)
