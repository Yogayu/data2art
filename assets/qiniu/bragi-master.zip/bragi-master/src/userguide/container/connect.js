/**
 *  Since this small app shares one `Actions`, so let's create a function
 *  to autoBinding it
 */

import * as actions from "../actions";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";

export default function autoConnect(mapStateToProps) {
  if(!mapStateToProps) {
    mapStateToProps = function (state) { return state }
  }

  return connect(mapStateToProps, function (dispatch) {
    return bindActionCreators(actions, dispatch)
  })
}
