import Cover from "components/cover"
import React from "react"
import Artist from "../components/Artist.js"
import styles from './base.module.css'

function Artists(props) {
  let {artists=[], isFetching, fetchArtists, toggleSearchDialog, likeAndReplaceArtist} = props

  return <div className={styles.artists}>
    {artists.map(
      (artist, index) => {
        return <Artist
          size={100}
          style={{
            marginRight: ((index + 1) % 5 === 0) ? 0 : 40
            // margin: '0 20px'
          }}
          key={artist.id} {...artist}
          hidden={artist.liked}
          nohover={true}
          onClick={function () {
            likeAndReplaceArtist(artist)
          }}></Artist>
      }
    )}
  </div>
}

import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import * as actions from "../actions";

function fillArtists(ids, artists) {
  return ids.map((id) => artists[id])
}

function mapStateToProps(state) {
  let {artists} = state.guessArtists
  return Object.assign({}, state.guessArtists, {
    artists: fillArtists(artists, state.artists)
  })
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(actions, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Artists)
