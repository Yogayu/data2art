import React from 'react'
import Icon from './index'

export default class IconGenerated extends Icon {
  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewBox: '0 0 20 20'
    , size: 12
    , color: '#B9B9B9'
  })

  renderIcon(color) {
    return <g id="icon" fill="none" fillRule="evenodd" >
      <g id="addition" fill={color} >
        <path d="M9 9H4.007C3.45 9 3 9.448 3 10c0 .556.45 1 1.007 1H9v4.993C9 16.55 9.448 17 10 17c.556 0 1-.45 1-1.007V11h4.993C16.55 11 17 10.552 17 10c0-.556-.45-1-1.007-1H11V4.007C11 3.45 10.552 3 10 3c-.556 0-1 .45-1 1.007V9z" id="Rectangle-51"  />
      </g>
    </g>
  }
}
