import React from "react"
import "./icon-playing.scss"
import Icon from "ui/icon"

export default function IconPlaying ({className}) {
  return <Icon
    i="playing"
    size={12}
    className={className}></Icon>
}
