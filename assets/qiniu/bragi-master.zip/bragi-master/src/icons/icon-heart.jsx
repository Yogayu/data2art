import Icon from "./index"
import React from "react"
import { darken } from 'utils/color'

export default class IconHeart extends Icon {

  static defaultProps = {
    size: 30
    , version: '1.1'
    , xmlns: 'http://www.w3.org/2000/svg'
    , color: '#c4c4c4'
    , className: "icon icon-heart"
    , viewSize: 30
  }

  renderIcon(fillColor) {
    // fillColor = this.props.color || '#C4C4C4'
    if(this.props.liked) {
      fillColor = '#FF2C56'
      if(this.state.hovered) {
        fillColor = darken(fillColor, 30)
      }
    }

    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <path
        d="M22,0 C18.9359565,0 16.5821582,1.72596986 15,3.5 C13.4530656,1.72596986 11.0993172,0 8,0 C3.7559698,0 0,3.9236383 0,9 C0,12.0105248 0.844640658,15.0729547 2.5,18 C6.88109125,25.6681877 15.0243286,28.9632358 15,29 C15.0243286,28.9631844 22.9314319,25.7540044 27.5,18 C29.1765036,15.1251042 30.0352238,12.2324468 30,9 C30.0352238,3.9236383 26.2791541,0 22,0 Z"
        id="b" fill={fillColor} />
    </g>
  }


}
