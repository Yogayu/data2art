import React from 'react'
import Icon from './index'

export default class IconSkip extends Icon {

  static defaultProps = Object.assign({}, Icon.defaultProps, {
    size: 30
    , viewSize: 30
  })

  linkAs = (key, attrs) => (
    (this.__cb4r3fs || (this.__cb4r3fs = new Map())).get(key) || this.__cb4r3fs.set(key, node => (
      this.refs[key] !== node && (this.refs = Object.assign({}, this.refs, { [key]: node })),
      node && Object.keys(attrs).forEach(attr => node.setAttributeNS(null, attr, attrs[attr]))
    )).get(key)
  )

  renderIcon() {
    return <g ref={ this.linkAs("Page-1", { 'fill-rule': "evenodd" }) } id="Page-1" fill="none" >
      <g ref={ this.linkAs("Fill-1-Copy-8-+-Path-Copy-6-+-Oval-3-Copy-2", {  }) } id="Fill-1-Copy-8-+-Path-Copy-6-+-Oval-3-Copy-2" fill="#4A4A4A" >
        <path ref={ this.linkAs("Fill-1-Copy-8", {  }) } d="M4.722 1.347l18.973 12.148c1.497.828 1.497 2.182 0 3.01L4.722 28.653C3.225 29.48 2 28.778 2 27.09V2.91C2 1.22 3.225.52 4.722 1.346zM25 28.5c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z" id="Fill-1-Copy-8"  />
        <path ref={ this.linkAs("Path-Copy-6", {  }) } id="Path-Copy-6" d="M23 4h4v22.5h-4z"  />
        <path ref={ this.linkAs("Oval-3-Copy-2", {  }) } d="M25 6c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z" id="Oval-3-Copy-2"  />
      </g>
    </g>
  }

}
