import Icon from './index'
import React from 'react'

export default class IconGenerated extends Icon {
  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewBox: '0 0 23 23'
    , size: 23
    , color: '#8F8e94'
  })

  renderIcon(color) {
    return <g id="icon" fill="none" fillRule="evenodd" >
      <g id="1205_cd-copy" transform="rotate(-90 11.75 8.75)" stroke={color} >
        <g id="Layer_1" >
          <g id="Group" >
            <path d="M7.334 15.793v-4.778M10.61 9.688l3.938 3.05" id="Shape"  />
            <path d="M8.25 15.984a7.724 7.724 0 0 0 6.291-3.234 7.734 7.734 0 1 0-6.291 3.234z" id="Oval"  />
            <ellipse id="Oval" cx="8.25" cy="8.25" rx="1.017" ry="1.017"  />
            <circle id="Oval" cx="8.25" cy="8.25" r="2.765"  />
          </g>
        </g>
      </g>
    </g>

  }
}
