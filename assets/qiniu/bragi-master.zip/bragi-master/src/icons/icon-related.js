import React, { Component } from 'react'
import Icon from './index'

export default class IconAdd extends Icon {

  static defaultProps = Object.assign({}, Icon.defaultProps, {
    size: 15
    , color: '#b9b9b9'
    , viewBox: '43 1 15 15'
  })

  renderIcon (color) {
    return (<g
        id="Group-3"
        stroke="none"
        strokeWidth="1"
        fill="none"
        fillRule="evenodd"
        transform="translate(43.000000, 1.000000)"
    >
      <path
        d="M6,6 L1.00684547,6 C0.449948758,6 0,6.44771525 0,7 C0,7.55613518 0.450780073,8 1.00684547,8 L6,8 L6,12.9931545 C6,13.5500512 6.44771525,14 7,14 C7.55613518,14 8,13.5492199 8,12.9931545 L8,8 L12.9931545,8 C13.5500512,8 14,7.55228475 14,7 C14,6.44386482 13.5492199,6 12.9931545,6 L8,6 L8,1.00684547 C8,0.449948758 7.55228475,-1.77635684e-15 7,-1.77635684e-15 C6.44386482,-1.77635684e-15 6,0.450780073 6,1.00684547 L6,6 Z"
        id="Rectangle-51"
        fill={color}></path>
    </g>)
  }
}
