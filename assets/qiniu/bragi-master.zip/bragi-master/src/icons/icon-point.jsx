import React from 'react'
import Icon from './index'

export default class IconPoint extends Icon {

  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewBox: '0 0 9 9'
    , size: 9
    , color: '#c6c6c6'
  })

  renderIcon(color) {
    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <circle id="Oval-59" fill={color} cx="4.5" cy="4.5" r="1.5"></circle>
    </g>
  }

}
