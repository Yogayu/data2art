import React, { Component } from 'react'
import Icon from './index'

export default class IconList extends Icon {

  static defaultProps = {
    ...Icon.defaultProps
    , viewBox: '0 5 17 12'
    , size: 17
  }

  renderIcon (color="#b9b9b9") {
    return (
      <path d="M0,5 L2,5 L2,7 L0,7 L0,5 Z M4,5 L17,5 L17,7 L4,7 L4,5 Z M0,10 L2,10 L2,12 L0,12 L0,10 Z M4,10 L17,10 L17,12 L4,12 L4,10 Z M0,15 L2,15 L2,17 L0,17 L0,15 Z M4,15 L17,15 L17,17 L4,17 L4,15 Z"
        stroke="none"
        fill={color} fillRule="evenodd"></path>
    )
  }
}
