import styles from "./icon-playing-wave.module.scss"
// import uniqueId from 'lodash/utility/uniqueId'

import React from "react"
import clns from "classnames"


export default class IconPlayingWave extends React.Component {

  static defaultProps = {
    color: '#5CBC7D'
    , viewSize: 12
    , animate: true
  }

  render() {
    return React.createElement('div', {
      className: clns(styles.wave, this.props.className)
      , style: Object.assign({}, {
        position: 'relative'
        , width: 12
        , height: 12
        , display: 'inline-block'
        , overflow: 'hidden'

        // , transform: 'scale(10)'
      }, this.props.style)
    }, [
      [2, 12, 2, 5]
      , [5, 12, 5, 6]
      , [8, 12, 8, 1]
      , [11, 12, 11, 5]
    ].map((arr, index) => {
      let [x1, y1, x2, y2] = arr
      return React.createElement('div', {
        key: 'line' + index
        , ref: 'line' + index
        , className: clns(
          styles['bar' + (index + 1)], this.props.animate ? null : styles.paused
        )
        , style: {
          position: 'absolute'
          , background: this.props.color || '#5cbc7d'
          , height: 12
          , left: x1 - 1
          , width: 2
          , borderRadius: '25%'
        }
      })
    }))
  }

}

/*
import Icon from './index'
import {TimelineMax, TweenMax} from 'utils/gsap'

export class IconPlayingWaveSvg extends Icon {

  static defaultProps = Object.assign({}, Icon.defaultProps, {
    color: '#5CBC7D'
    , viewSize: 12
    , animate: true
  })

  componentDidMount() {
    // [from, to, speed]
    let tl = new TimelineMax();

    [
      [10, 1, 2]
    , [10, 1, 1.4]
    , [1, 10, 1.8]
    , [10, 1, 1]
    ].map((ret, index) => {
      let [frm, to, duration] = ret
      , el = this.refs['line' + index]
      let tween = TweenMax.fromTo(el, duration, {
        attr: {
          y2: frm
        }
      }, {
        attr: {
          y2: to
        }
      })
      tl.add(tween, 0)
    })

    tl
    .timeScale(2)
    .yoyo(true)
    .repeat(-1)

    if(!this.props.animate) {
      tl.pause()
    }

    this.tl = tl
  }

  componentWillUpdate(nextProps, nextState) {
    if(!this.tl) {
      return
    }

    if(nextProps.animate != this.props.animate) {
      if(nextProps.animate) {
        this.tl.play()
      } else {
        this.tl.pause()
      }
    }
  }

  componentWillUnmount() {
    if(this.tl) {
      this.tl.kill()
    }
  }

  renderIcon(fill) {
    return React.createElement('g', {
      stroke: 'none'
      , strokeWidth: 1
      , fill: 'none'
      , fillRule: 'evenodd'
    }, [
      [2, 12, 2, 5]
      , [5, 12, 5, 6]
      , [8, 12, 8, 1]
      , [11, 12, 11, 5]
    ].map((arr, index) => {
      let [x1, y1, x2, y2] = arr
      return React.createElement('line', {
        key: 'line' + index
        , ref: 'line' + index
        , stokeWidth: 1
        , stroke: fill
        , strokeLinecap: 'round'
        , x1, y1, x2, y2
      })
    }))

    let prefix = uniqueId('line-')
    , speed = 1
    , maxHeight=10

    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">

      <line
        className="icon-playing-bar1"
        strokeWidth="1"
        stroke={fill}
        strokeLinecap="round"
        id={prefix + 'line-1'}
        x1="2" y1="12" x2="2" y2="5"
      />

      <line
        id={prefix + 'line-2'}
        className="icon-playing-bar2"
        strokeWidth="1" stroke={fill}
        strokeLinecap="round"
        x1="5" y1="12" x2="5" y2="6" />

      <line
        id={prefix + 'line-3'}
        className="icon-playing-bar3"
        strokeWidth="1"
        stroke={fill}
        strokeLinecap="round"
        x1="8" y1="12" x2="8" y2="1" />

      <line
        id={prefix + 'line-4'}
        className="icon-playing-bar4"
        strokeWidth="1" stroke={fill}
        strokeLinecap="round"
        x1="11" y1="12" x2="11" y2="5" />
    </g>

    , animates = this.props.animate ? `<animate xlink:href="#${prefix}line-1"
      attributeName="y2"
      dur="${2 * speed}s"
      values="10;1;10"
      repeatCount="indefinite" />

      <animate xlink:href="#${prefix}line-2"
        attributeName="y2"
        dur="${1.4 * speed}s"
        values="${maxHeight};1;${maxHeight}"
        repeatCount="indefinite" />

      <animate xlink:href="#${prefix}line-3"
        attributeName="y2"
        dur="${1.8 * speed}s"
        values="1;${maxHeight};1"
        repeatCount="indefinite" />

      <animate xlink:href="#${prefix}line-4"
        attributeName="y2"
        dur="${1 * speed}s"
        values="${maxHeight};1;${maxHeight}"
        repeatCount="indefinite" />` : ''
    animates = ""

    // <g dangerouslySetInnerHTML={{__html: animates}}></g>

    // return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
    //   <line strokeWidth="1" stroke={fill} strokeLinecap="round" id="line-1" x1="2" y1="12" x2="2" y2="5" />
    //   <line strokeWidth="1" stroke={fill} strokeLinecap="round" id="line-2" x1="5" y1="12" x2="5" y2="6" />
    //   <line strokeWidth="1" stroke={fill} strokeLinecap="round" id="line-3" x1="8" y1="12" x2="8" y2="1" />
    //   <line strokeWidth="1" stroke={fill} strokeLinecap="round" id="line-4" x1="11" y1="12" x2="11" y2="5" />
    // </g>
  }
}

*/
