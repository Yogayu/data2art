import React from "react"
import Icon from './index'

export default class IconAngle extends Icon {

  static defaultProps = {
    ...Icon.defaultProps
    , size: 18
    , direction: 'left'
    , color: '#C6C6C6'
    , version: 1
  }

  render () {
    let {
      direction='left', size=18, color='#C6C6C6', style
      , version=1
    } = this.props
    let angle = 0

    if(direction == 'left') {
      angle = 90
    } else if(direction == 'right') {
      angle = 270
    } else if(direction == 'top') {
      angle = 180
    } // if bottom, left unmodified


    if(version == 2) {
      return <svg
        xmlns="http://www.w3.org/2000/svg"
        width={size}
        height={size}
        viewBox="0 0 9 16"
        style={Object.assign({
          transform: "rotate(" + (angle + 90) + "deg)"
          , verticalAlign: 'middle'
        }, style || {})}
        >
        <path
          fill={color}
          fillRule="evenodd"
          d="M.3 14.3c-.4.4-.4 1.02 0 1.4.38.4 1 .4 1.4 0l7-7c.4-.4.4-1.02 0-1.4l-7-7C1.3-.1.68-.1.3.3c-.4.38-.4 1 0 1.4L6.6 8 .3 14.3z"
          />
      </svg>
    }

    return <svg
      className={'icon icon-angle-' + direction}
      width={size}
      height={size}
      viewBox="0 0 18 18"
      version="1.1"
      xmlns="http://www.w3.org/2000/svg"
      style={Object.assign({
        transform: "rotate(" + angle + "deg)"
      }, style || {})}
      >
      <title>Icon Angle {direction}</title>
      <desc>(c) 2005 - 2015 douban.fm, all rights reserved</desc>
      <defs></defs>
      <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <path
          d="M13.8074785,10.809253 C14.0641738,11.0815536 14.0641738,11.5228421 13.8074785,11.7958146 C13.5501613,12.0680618 13.1339704,12.0680618 12.8766432,11.7958146 L9.00000502,7.68466501 L5.12270484,11.7958146 C4.86599947,12.0680618 4.44920681,12.0680618 4.19249141,11.7958146 C3.9358362,11.5228421 3.9358362,11.0815536 4.19249141,10.809253 L8.53426641,6.20422541 C8.79158361,5.93192486 9.20776444,5.93192486 9.46510169,6.20422541 L13.8074785,10.809253 Z"
          id="Shape"
          fill={color}
          transform="translate(9.000000, 9.000000) scale(1, -1) translate(-9.000000, -9.000000)"
          ></path>
      </g>
    </svg>
  }


}
