import Icon from "./index"
import React from "react"

export default class IconTrangle extends Icon {
  static defaultProps = Object.assign({}, Icon.defaultProps, {
    // viewSize: 16
    viewBox: '0 0 16 16'
    , color: '#c6c6c6'
  })

  renderIcon(fill) {
    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <polygon
          id="Triangle-1"
          fill={fill}
          transform="translate(8.000000, 8.500000) scale(1, -1) translate(-8.000000, -8.500000) "
          points="8 6 12 11 4 11 "
        ></polygon>
    </g>
  }


}
