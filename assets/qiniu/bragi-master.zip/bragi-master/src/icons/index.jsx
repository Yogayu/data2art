import "./icon.scss"
import React  from "react"
import shallowCompare from 'react/lib/shallowCompare'

import { darken } from 'utils/color'

export default class Icon extends React.Component {

  static defaultProps = {
    size: 30
    , width: null
    , height: null
    , version: '1.1'
    , xmlns: 'http://www.w3.org/2000/svg'
    , color: '#B9B9B9'
    , viewSize: 18
    , className: 'icon'
    , viewBox: null
    , title: "Title"
    , desc: "Icon"
    , label: null
  }

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  constructor (props) {
    super(props)
    this.state = {
      hovered: false
      , hoverColor: this.props.color && darken(this.props.color, 30)
    }

  }

  renderIcon(color) {
    return this.props.children
  }

  handleMouseEnter = (event) => {
    this.setState({ hovered: true })
  }

  handleMouseLeave = (event) => {
    this.setState({ hovered: false })
  }

  handleClick = (event) => {
    if(this.props.onClick) {
      event.preventDefault()
      event.stopPropagation()
      this.props.onClick(event)
    }
  }

  render() {
    let fillColor = this.state.hovered ? this.props.hoverColor || this.state.hoverColor : this.props.color
    , size = this.props.size
    , style = Object.assign({
      verticalAlign: 'middle'
    }, this.props.style)

    // console.log('fillColor', fillColor)

    if(this.props.center) {
      style = Object.assign({}, {
        display: 'inline-block'
        , position: 'absolute'
        , top: '50%'
        , left: '50%'
        , marginLeft: -1 * size / 2
        , marginTop: -1 * size / 2
      }, this.props.style)
    }

    const svgElement =  <svg
      title={this.props.title}
      onMouseEnter={this.handleMouseEnter}
      onMouseLeave={this.handleMouseLeave}
      viewBox={this.props.viewBox || [0, 0, this.props.viewSize, this.props.viewSize]}
      height={this.props.height || size}
      width={this.props.width || size}
      style={style}
      className={this.props.className}
      onClick={this.handleClick}
    >
      <desc>{this.props.desc}</desc>
      {this.renderIcon(fillColor)}
    </svg>

    if(this.props.label) {
      return <label title={this.props.label}>
        {svgElement}
      </label>
    } else {
      return svgElement
    }
  }
}

export class IconClose extends Icon {
  static defaultProps = Object.assign(
    {}, Icon.defaultProps,
    {
      viewSize: 13
      , hasCircle: true
    }
  )

  renderIcon(color="#FFFFFF") {
    let bgColor = this.props.bgColor || '#AFAFAF'

    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <g id="搜索结果" transform="translate(-891.000000, -153.000000)">
        <g id="Group-Copy" transform="translate(310.000000, 140.000000)">
          <g id="Oval-436-+-Rectangle-47-+-Rectangle-47-Copy" transform="translate(581.000000, 13.000000)">
            {this.props.hasCircle ?
              <circle id="Oval-436" fill={bgColor} cx="6.5" cy="6.5" r="6.5"></circle>
              : null}
            <rect id="Rectangle-47" fill={color} transform="translate(6.311385, 6.619527) rotate(-50.000000) translate(-6.311385, -6.619527) " x="3.31138505" y="6.11952713" width="6" height="1"></rect>
            <rect id="Rectangle-47-Copy" fill={color} transform="translate(6.311385, 6.619527) rotate(50.000000) translate(-6.311385, -6.619527) " x="3.31138505" y="6.11952713" width="6" height="1"></rect>
          </g>
        </g>
      </g>
    </g>
  }
}

export class IconStar extends Icon {
  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewSize: 18
  })

  renderIcon(color) {
    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <path
        d="M14.6753671,10.3627187 L10.989809,10.898939 L9.34248263,14.2390557 C9.28044764,14.3644003 9.150854,14.4506545 9.0012902,14.4506545 C8.8508766,14.4506545 8.72255765,14.3644003 8.66009776,14.2390557 L7.01192162,10.898939 L3.32551373,10.3627187 C3.18742215,10.3427486 3.06547666,10.2467218 3.01916287,10.1048061 C2.97199928,9.96204069 3.01491389,9.81247689 3.11476473,9.71475054 L5.7814194,7.11565452 L5.15299648,3.44411802 C5.12962714,3.30645134 5.18273928,3.16028671 5.30383498,3.07318279 C5.42493067,2.98437928 5.58001814,2.97843072 5.70408812,3.04428978 L9.0008653,4.77702046 L12.2963678,3.04428978 C12.4208627,2.97928051 12.5767999,2.98522908 12.6966209,3.07318279 C12.8168668,3.16028671 12.8716786,3.30645134 12.8474594,3.44411802 L12.2177618,7.11565452 L14.8848414,9.71475054 C14.9851171,9.81247689 15.0276068,9.96204069 14.981293,10.1048061 C14.9366788,10.2467218 14.8138836,10.3427486 14.6753671,10.3627187 L14.6753671,10.3627187 Z"
        id="Shape"
        fill={color}
        transform="translate(9.000000, 8.725327) scale(1, -1) translate(-9.000000, -8.725327) "></path>
    </g>
  }
}

export class IconRelated extends Icon {

  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewSize: 18
    , className: 'icon icon-related'
    , color: '#ffffff'
  })

  renderIcon(color) {
    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <g id="歌单-无版权歌曲-hover"  transform="translate(-864.000000, -377.000000)">
        <g id="Group-Copy-17"  transform="translate(310.000000, 140.000000)">
          <g id="list" transform="translate(25.000000, 172.000000)">
            <g id="list1" transform="translate(0.000000, 51.000000)">
              <g id="-2-+-cover-+-1">
                <g id="-2" transform="translate(26.000000, 0.000000)">
                  <g id="hover">
                    <g id="Shape-2-+-Oval-44-+-Rectangle-51" transform="translate(472.000000, 11.000000)">
                      <g id="Group" transform="translate(31.000000, 3.000000)">
                        <rect id="Rectangle-164" fill={color} x="11" y="0" width="1.5" height="10" rx="1"></rect>
                        <path d="M5.419236,7.10344007 C5.15383527,7.10344007 4.92956389,6.91331382 4.88533044,6.65179322 C4.82092032,6.27930096 4.93810017,5.88352794 5.20660501,5.56535748 C5.51856727,5.19441728 5.98573464,4.97325 6.45678213,4.97325 C6.75632798,4.97325 7,5.21692202 7,5.51646787 C7,5.81601372 6.75632798,6.05968574 6.45678213,6.05968574 C6.30778523,6.05968574 6.14249179,6.14116842 6.03695232,6.26610853 C5.97719836,6.33672685 5.94693336,6.4112253 5.95546964,6.46709914 C5.98030246,6.61143989 5.94770939,6.75578064 5.8631226,6.87373652 C5.78008787,6.9916924 5.65514776,7.070847 5.51158304,7.09490379 C5.48054202,7.10033597 5.449501,7.10344007 5.419236,7.10344007" id="Fill-5" fill={color}></path>
                        <path d="M3.13997625,8 C2.85620127,8 2.61822283,7.79555117 2.57487968,7.51504737 C2.39087573,6.32106618 2.75479465,5.0894664 3.57258999,4.13673484 C4.42800391,3.13820673 5.64406557,2.56575 6.90755936,2.56575 C7.22241056,2.56575 7.4800161,2.82253774 7.4800161,3.13820673 C7.4800161,3.45387573 7.22241056,3.71066347 6.90755936,3.71066347 C5.99162859,3.71066347 5.07079104,4.14818397 4.44108863,4.88092859 C3.8326489,5.59159274 3.57177219,6.46499816 3.70752622,7.34085696 C3.75495835,7.65243698 3.53987817,7.94520771 3.22829815,7.99427543 C3.19885752,7.99754661 3.16941689,8 3.13997625,8" id="Fill-6" fill={color}></path>
                        <path d="M0.396202824,8.56500546 C-0.139113341,6.27285708 0.307117226,4.1203564 1.65383465,2.50397445 C2.88578415,1.02242477 4.71244021,0.1725 6.66349508,0.1725 C6.78227588,0.1725 6.89945153,0.175710292 7.01823233,0.182130876 C7.16831347,0.189354032 7.30715859,0.254362442 7.40748021,0.365920084 C7.50860441,0.475872579 7.56077165,0.620335712 7.55354849,0.770416856 C7.53829961,1.07940745 7.30234316,1.30493045 6.99174742,1.30493045 C6.88099235,1.30091758 6.79591962,1.29850986 6.71164946,1.29850986 C5.08884693,1.29850986 3.51981679,2.01761524 2.51660059,3.22227725 C1.40182674,4.5625741 1.03745862,6.36916583 1.49010977,8.30978725 C1.52462041,8.45665811 1.49974065,8.60673925 1.42028592,8.73354578 C1.34163377,8.86195745 1.21643239,8.95104305 1.07116668,8.98475111 C1.02863032,8.99438199 0.985291378,9 0.942755011,9 C0.680313653,9 0.455593223,8.82102623 0.396202824,8.56500546 Z" id="Fill-7" fill={color}></path>
                        <path d="M8.34807621,12.2990381 C10.0049305,12.2990381 11.3480762,11.6274652 11.3480762,10.7990381 C11.3480762,9.97061098 10.0049305,9.29903811 8.34807621,9.29903811 C6.69122196,9.29903811 5.34807621,9.97061098 5.34807621,10.7990381 C5.34807621,11.6274652 6.69122196,12.2990381 8.34807621,12.2990381 Z" id="Oval-47" stroke={color} strokeWidth="1.5" transform="translate(8.348076, 10.799038) rotate(-30.000000) translate(-8.348076, -10.799038) "></path>
                      </g>
                    </g>
                  </g>
                </g>
              </g>
            </g>
          </g>
        </g>
      </g>
    </g>
  }

}

export class IconNotification extends Icon {

  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewBox: '0 0 10 11'
  })

  renderIcon(color) {
    return <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <g id="收藏的兆赫变歌单通知" transform="translate(-323.000000, -274.000000)" fill="#6BBD7A">
        <g id="Group" transform="translate(310.000000, 268.000000)">
          <g id="iconfont-icon19" transform="translate(17.035932, 11.492192) rotate(-25.000000) translate(-17.035932, -11.492192) translate(12.035932, 5.992192)">
            <g id="图形" transform="translate(-0.000000, -0.000000)">
              <path d="M9.42607789,7.06897781 C9.06209746,7.06897781 8.76702118,6.77391479 8.76702118,6.4099211 L8.76702118,4.99660382 C8.76702118,3.99420611 8.37414289,3.04927271 7.66075026,2.33588008 C7.17810303,1.85323285 6.58940863,1.51754051 5.94869807,1.35071503 L5.94869807,0.969621231 C5.94869807,0.447352124 5.53166754,0.0139770725 5.00941168,0.00890006477 C4.48203905,0.00378329016 4.05138146,0.4313125 4.05138146,0.957518601 L4.05138146,1.35070177 C3.41067092,1.51752724 2.82196325,1.85323285 2.33932927,2.33586683 C1.62593665,3.0492462 1.23305835,3.99419286 1.23305835,4.99659057 L1.23305835,6.40990785 C1.23305835,6.77388828 0.937995337,7.06896456 0.574001645,7.06896456 C0.258617332,7.06896456 -0.00494967617,7.32705688 0.000458730569,7.64238817 C0.00570806995,7.94867894 0.256496386,8.19623282 0.564006697,8.19623282 L9.4360861,8.19623282 C9.74359641,8.19623282 9.99438474,7.94867894 9.99963407,7.64238817 C10.0050292,7.32707014 9.74147547,7.06897781 9.42607789,7.06897781 L9.42607789,7.06897781 Z M5.00003977,10.6906083 C5.93016632,10.6906083 6.68417503,9.93659961 6.68417503,9.00647306 L3.31589124,9.00647304 C3.31589124,9.93659961 4.06991321,10.6906083 5.00003977,10.6906083 L5.00003977,10.6906083 Z" id="Shape"></path>
            </g>
          </g>
        </g>
      </g>
    </g>
  }
}

export class IconRefresh extends Icon {

  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewBox: '0 0 12 11'
  })

  renderIcon(color) {
    return <g id="图形" fill={color}>
      <path d="M0.832073656,2.60131671 C2.43834081,0.0237555111 5.8542967,-0.773954266 8.44664501,0.82346609 C10.4990243,2.08832685 11.4729501,4.49599991 10.9092115,6.79327051 L11.867957,7.25553679 C11.9441638,7.29271017 11.9946029,7.36738809 11.999626,7.45172502 C12.003983,7.52895568 11.9700563,7.60286089 11.909127,7.64978986 C11.9035489,7.65412261 9.40559869,9.24377438 9.40559869,9.24377438 C9.33585812,9.28770906 9.2484812,9.29259376 9.17461947,9.25587574 C9.10086876,9.21958548 9.05153971,9.14701873 9.04540654,9.06501377 L8.82436251,6.17654294 C8.81822934,6.09343409 8.85638823,6.01320914 8.92646182,5.96615597 C8.99598037,5.91921319 9.08502241,5.91256228 9.16078514,5.94907332 L10.038731,6.37295194 C10.4050702,4.52741929 9.59764197,2.63016955 7.95253599,1.61630498 C5.80006945,0.289516196 2.9632406,0.95173771 1.6287896,3.09243581 C0.982600066,4.12949579 0.781190512,5.35440965 1.06148488,6.54216393 C1.34201515,7.72990442 2.07054464,8.73800117 3.11330909,9.3805873 C4.13609217,10.0106305 5.34590929,10.2161328 6.52010683,9.95947919 C6.77284355,9.90410548 7.02290221,10.0631203 7.07880846,10.3146685 C7.11864634,10.496313 7.04622771,10.676964 6.90741261,10.7838202 C6.85451746,10.8246502 6.79136796,10.8549519 6.72140537,10.8701442 C5.3074035,11.179398 3.85064981,10.9320584 2.61931107,10.173302 C1.36366166,9.39967075 0.486270874,8.18574055 0.148502282,6.75565559 C-0.18926631,5.32512907 0.053549098,3.8501987 0.832073656,2.60131671 Z" id="Shape" transform="translate(6.000000, 5.500000) scale(1, -1) translate(-6.000000, -5.500000) "></path>
    </g>
  }
}
