import React from 'react'
import Icon from './index'

export default class IconScrollTop extends Icon {

  static defaultProps = {
    ...Icon.defaultProps
    , size: 40
    , viewBox: '930 1042 40 40'
    , color: '#D9D9D9'
  }

  renderIcon(color) {
    return <g id="Group-4" fill="none" transform="translate(930 1042)" >
      <circle id="Oval-29" fill={color} cx={ 20 } cy={ 20 } r={ 20 }  />
      <path
        d="M21.157 17.4c-.533-.533-1.397-.533-1.93 0L12.4 23.227c-.533.533-.533 1.397 0 1.93.533.533 1.397.533 1.93 0l4.497-3.17v7.648c0 .754.61 1.365 1.365 1.365.754 0 1.365-.61 1.365-1.365v-7.647l4.496 3.17c.267.265.616.4.966.4.348 0 .698-.134.964-.4.533-.534.533-1.398 0-1.93L21.157 17.4zM12 13.5c0-.828.667-1.5 1.505-1.5h12.99c.83 0 1.505.666 1.505 1.5 0 .828-.667 1.5-1.505 1.5h-12.99c-.83 0-1.505-.666-1.505-1.5z"
        id="Combined-Shape" fill="#FFFFFF"  />
    </g>
  }

}
