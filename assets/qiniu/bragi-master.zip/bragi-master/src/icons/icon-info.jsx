import React from "react"
export default class extends React.Component {
  render() {
    return <svg { ...this.props } height={'undefined' === typeof this.props['height'] ? "20px" : this.props['height']} viewBox={'undefined' === typeof this.props['viewBox'] ? "0 0 20 20" : this.props['viewBox']} version={'undefined' === typeof this.props['version'] ? "1.1" : this.props['version']} xmlns={'undefined' === typeof this.props['xmlns'] ? "http://www.w3.org/2000/svg" : this.props['xmlns']}>
  <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
    <g id="Oval-103-+-Rectangle-213-+-Oval-104" transform="translate(3.000000, 3.000000)" fill="#9B9B9B">
      <path d="M7,14 C10.8659932,14 14,10.8659932 14,7 C14,3.13400675 10.8659932,0 7,0 C3.13400675,0 0,3.13400675 0,7 C0,10.8659932 3.13400675,14 7,14 Z M7,13 C10.3137085,13 13,10.3137085 13,7 C13,3.6862915 10.3137085,1 7,1 C3.6862915,1 1,3.6862915 1,7 C1,10.3137085 3.6862915,13 7,13 Z" id="Combined-Shape" stroke="#9B9B9B"/>
      <rect id="Rectangle-213" x="6" y="6" width="2" height="5" rx="1"/>
      <circle id="Oval-104" cx="7" cy="4" r="1"/>
    </g>
  </g>
</svg>
  }
}
