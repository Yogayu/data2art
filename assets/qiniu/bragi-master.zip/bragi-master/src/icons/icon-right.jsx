import Icon from "./index"
import React from 'react'

export default class IconRight extends Icon {
  static defaultProps = Object.assign({}, Icon.defaultProps, {
    viewSize: 12
    , viewBox: '0 0 12 9'
    , color: '#9B9B9B'
  })

  renderIcon(fill) {
    return <g id="icon-right-g" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="icon-right-g-inner" transform="translate(-835.000000, -373.000000)" fill={fill}>
            <g id="icon-right-g-inner-inner" transform="translate(340.000000, 268.000000)">
                <g id="Rectangle-451">
                    <path d="M505.381368,113.3861 L499.105342,107.110074 L496.625513,109.589888 C496.25442,109.96095 495.652806,109.96095 495.281713,109.589888 C494.910683,109.218842 494.910683,108.617197 495.281713,108.246135 L498.252507,105.275326 C498.450433,105.077447 498.810842,104.987325 499.108764,105.001431 C499.404742,104.987387 499.760314,105.077509 499.958146,105.275357 L506.725121,112.042331 C507.096214,112.413424 507.096214,113.015038 506.725121,113.3861 C506.354059,113.757192 505.752461,113.757192 505.381368,113.3861 L505.381368,113.3861 Z" id="Shape" transform="translate(501.003441, 109.332210) scale(1, -1) translate(-501.003441, -109.332210) "></path>
                </g>
            </g>
        </g>
    </g>
  }


}
