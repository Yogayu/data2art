import request from './request'
import ga from './analytics'


function commonLog(category, action, label="") {
  return request({
    url: 'collect_event'
    , method: 'post'
    , data: {
      category, action, label
    }
  })
}

export function logWithGA(category, action, label) {
  ga('send', {
    hitType: 'event'
    , eventCategory: category
    , eventAction: action
    , eventLabel: label
    // , eventValue: data.value
  })
  
  return commonLog(category, action, label)
}

export default commonLog
