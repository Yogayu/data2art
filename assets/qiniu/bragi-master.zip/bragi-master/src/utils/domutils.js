export function getScrollY() {
  return windowScrollY()
  // return window.scrollY || window.pageYOffset
}

export function addEventListener(node, event, listener) {
  if (node.addEventListener) {
    node.addEventListener(event, listener, false)
  } else {
    node.attachEvent(`on${event}`, listener)
  }
}

export function removeEventListener(node, event, listener) {
  if (node.removeEventListener) {
    node.removeEventListener(event, listener, false)
  } else {
    node.detachEvent(`on${event}`, listener)
  }
}

export function windowScrollX() {
  return (window.pageXOffset !== undefined) ? window.pageXOffset :
    (document.documentElement || document.body.parentNode || document.body).scrollLeft
}

export function windowScrollY() {
  return (window.pageYOffset !== undefined) ? window.pageYOffset :
    (document.documentElement || document.body.parentNode || document.body).scrollTop
}

// events


// from perfectScrollbar
export function getDeltaFromEvent(e) {
  let deltaX = e.deltaX
  var deltaY = -1 * e.deltaY

  if (typeof deltaX === "undefined" || typeof deltaY === "undefined") {
    // OS X Safari
    deltaX = -1 * e.wheelDeltaX / 6
    deltaY = e.wheelDeltaY / 6
  }

  if (e.deltaMode && e.deltaMode === 1) {
    // Firefox in deltaMode 1: Line scrolling
    deltaX *= 20
    deltaY *= 20
  }

  if (deltaX !== deltaX && deltaY !== deltaY/* NaN checks */) {
    // IE in some mouse drivers
    deltaX = 0
    deltaY = e.wheelDelta
  }

  return -1 * deltaY
}

import {
  transformPrefix
  , supportTransform
  , support3dTransform
} from 'utils/feature-detect'

// css related
/**
 * @param  {number} x
 * @param  {number} y
 * @param  {number} z
 * @param  {number} scale
 * @return {object} prefixed-transform object
 */
export function transform(x, y, z=0, scale=null) {
  if(!supportTransform) {
    return {}
  }
  let transtr

  if(support3dTransform) {
    transtr = `translate3d(${x}px, ${y}px, ${z})`
  } else {
    transtr = `translate(${x}px, ${y}px)`
  }

  if(scale) {
    transtr = transtr + ` scale(${scale})`
  }
  
  return { [transformPrefix]: transtr }
}
