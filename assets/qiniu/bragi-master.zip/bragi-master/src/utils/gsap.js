// Load all used gsap Plugin
// global TweenLite, TimelineLite

import TweenLite from "gsap/TweenLite"
import TimelineLite from "gsap/TimelineLite"
// import TweenMax from 'gsap/TweenMax'
// import TimelineMax from 'gsap/TimelineMax'
// let TweenLite = TweenMax
// , TimelineLite = TimelineMax

import "gsap/plugins/ScrollToPlugin"
import "gsap/easing/EasePack"
import "gsap/plugins/AttrPlugin"
import "utils/gsap-react-plugin"


export {
  TweenLite, TimelineLite
  // , TimelineMax, TweenMax
}
