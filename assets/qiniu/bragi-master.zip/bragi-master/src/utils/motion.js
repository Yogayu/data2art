// utils for motion

export function inRange(from, to, value) {
  let a, b
  if(from > to) {
    a = to
    b = from
  } else {
    a = from
    b = to
  }

  if(value < a) {
    return a
  } else if(value > b) {
    return b
  }

  return value
}

export function fromTo(from, to, progress=0, offset=0) {
  let value = from + (to - from) * progress + offset
  return inRange(from, to, value)
}
