// Color Utils

function round(value, begin = 0, end = 255) {
  if(value > 255) {
    return 255
  } else if (value < 0) {
    return 0
  }
  return value
}

export function lighten(color, amount) {
  let usePound = false

  if(color[0] == '#') {
    // hex format
    color = color.slice(1)
    usePound = true
  }

  let num = parseInt(color, 16)

  let r = round(
    (num >> 16) + amount
  )
  , b = round(
    ((num >> 8) & 0x00FF) + amount
  )
  , g = round(
    (num & 0x0000FF) + amount
  )

  return (usePound ? "#" : "") + (g | (b << 8) | (r << 16)).toString(16)
}

export function darken(color, amount) {
  return lighten(color, -1 * amount)
}
