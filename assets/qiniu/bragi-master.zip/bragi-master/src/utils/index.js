// utils functions

export function pad(n) {
  if(n<10) {
    return '0' + n.toString()
  } else {
    return n.toString()
  }
}

export function formatTime (time) {
  if(!time) return ''
  let d = new Date(parseInt(time))
  let hours = d.getUTCHours()

  return (
    hours ? (pad(hours) + ":") : ""
  ) + pad(d.getUTCMinutes()) + ":" + pad(d.getUTCSeconds())
}

// in yyyy-mm-dd hh-mm-ss format
export function getCurrentTime () {
  let d = new Date()
  return d.toJSON().replace('T', ' ').slice(0, -5)
}

// dom utils
export function relativePosition (child, parent) {
  let top = 0, left = 0
  let element = child
  while(element && element.offsetParent) {
    top += element.offsetTop
    left += element.offsetLeft
    if(element.offsetParent == document || child.offsetParent == parent) {
      break
    } else {
      element = element.offsetParent
    }
  }
  return {top, left}
}

export function screenPosition (element) {
  let {top, left} = relativePosition(element, document)
  top = top - window.scrollY || document.documentElement.scrollTop
  left = left - window.scrollX || document.documentElement.scrollLeft
  return {top, left}
}

import isNumber from "lodash/isNumber"
import isString from "lodash/isString"

export function isId(n) {
  return isNumber(n) || isString(n)
}
