
import reqwest from "reqwest"
import StackTrace from "stacktrace-js"
import {parseCookie} from "../douradio/utils.js"

function shouldBlock(errorEvent) {
  if (errorEvent.message === "Script error.") {
    return true
  }
  return false
}

function _errorHandler(errorEvent) {

  console.log("Error handler", errorEvent)
  var message = errorEvent.message
  var level = "warning"
  var stack = []
  var extra = {}
  if (shouldBlock(errorEvent)) {
    return;
  }
  function callbackWithStack(stack) {
    _sendErrorToBackEnd(errorEvent.message, level, stack, extra)
  }
  function errorStack(error) {
    console.log("Error computing stack", errorEvent);
    console.log(error);
    _sendErrorToBackEnd("NOSTACK: " + errorEvent.message, "info", [], {error: error})
  }
  StackTrace.fromError(errorEvent.error).then(callbackWithStack).catch(errorStack);
}

// http://stackoverflow.com/questions/25245712/on-firefox-cors-request-gives-error-colon

function _sendErrorToBackEnd(message, level, stack, extra) {
  // const baseUrl = "http://doubandev2.intra.douban.com:8087"
  // const baseUrl = "https://dae-pre152.dapps.douban.com"
  const baseUrl = ""
  var pack = JSON.stringify({
    'message': message,
    'level': level,
    'tags': {},
    'extra': extra,
    'stack': stack
  })
  reqwest({
    url: baseUrl + '/j/jserror/',
    method: 'post',
    data: {
      'ck': parseCookie().ck,
      'pack': pack
    },
    success: (response) => {
      console.log("Error report success", response)
    },
    error: (err) => {
      console.log("Error report failed", message, level, stack, extra, err)
    }
  })
}

function initErrorReporter() {
  console.log("initErrorReporter")
  window.addEventListener("error", _errorHandler)
  hookDebug()
}

function _debugRaiseOut() {
  function _debugRaiseIn() {
    a = b;
  }
  _debugRaiseIn()
}

function hookDebug() {
  function doc_keyUp(event) {
    if (event.shiftKey && event.altKey && event.which === 68) {
      console.log("Calling _debugRaiseOut")
      _debugRaiseOut();
    }
  }
  window.addEventListener('keyup', doc_keyUp, false)
}

export default initErrorReporter
