let simpleStorage = require('simplestorage'),
  douradio = require('douradio')

// @todo error fallback
// @todo abortable Cache

module.exports = function (options, ttl=false) {
  if(options.method && options.method.toLowerCase() != 'get') {
    // cache is available for get request
    ttl = false
  }

  // @todo if debug, always no ttl
  // ttl = false;

  let storageKey = 'req-v2-' + options.url + JSON.stringify(options.data)

  if(ttl) {
    let value = simpleStorage.get(storageKey)
    if(value) {
      return Promise.resolve(value)
    }
  }

  return douradio.apiClient.request(options).then(function (response) {
    if(ttl) {
      simpleStorage.set(storageKey, response, {
        TTL: ttl
      })
    }
    return response
  })
}
