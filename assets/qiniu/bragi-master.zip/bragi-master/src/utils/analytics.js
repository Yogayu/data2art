import douradio from "douradio"
/**
 * analytics.js
 * Creates a temporary global ga object and loads analytics.js.
 * Parameters o, a, and m are all used internally. They could have been
 * declared using 'var', instead they are declared as parameters to save
 * 4 bytes ('var ').
 *
 * @param {Window}        i The global context object.
 * @param {HTMLDocument}  s The DOM document object.
 * @param {string}        o Must be 'script'.
 * @param {string}        g Protocol relative URL of the analytics.js script.
 * @param {string}        r Global name of analytics object. Defaults to 'ga'.
 * @param {HTMLElement}   a Async script tag.
 * @param {HTMLElement}   m First script tag in document.
 */
(function(i, s, o, g, r, a, m){
  // Acts as a pointer to support renaming.
  i['GoogleAnalyticsObject'] = r

  // Creates an initial ga() function.
  // The queued commands will be executed once analytics.js loads.
  i[r] = i[r] || function() {
    (i[r].q = i[r].q || []).push(arguments)
  },

  // Sets the time (as an integer) this tag was executed.
  // Used for timing hits.
  i[r].l = 1 * new Date()

  function insertScript() {
    // Insert the script tag asynchronously.
    // Inserts above current tag to prevent blocking in addition to using the
    // async attribute.
    a = s.createElement(o),
    m = s.getElementsByTagName(o)[0]
    a.async = 1
    a.src = g
    m.parentNode.insertBefore(a, m)
  }

  douradio.once('playing', insertScript, this)
})(
  window,
  document,
  'script',
  '//www.google-analytics.com/analytics.js',
  'ga'
)

// Creates a default tracker with automatic cookie domain configuration.
ga('create', 'UA-7019765-27', 'auto')

// ga('set', 'appName', 'bragi')
// ga('set', 'appId', 'com.douban.bragi')
// ga('set', 'appVersion', '3.0')
// ga('set', 'dimension2', 'bragi')

ga('send', 'pageview')

export default window.ga
