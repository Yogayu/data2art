import React from  "react"
import styles from "./favartists.module.css"
// import douradio from 'douradio'
// import reject from 'lodash/collection/reject'

import clone from "lodash/clone"
import indexOf from "lodash/indexOf"

import request from "utils/request"
import Cover from "components/cover"
import classnames from "classnames"
import {IconRefresh} from "icons"
import Link from "ui/link"
import Button from "components/button"


let Artist = ({id, title, avatar, onLike, onIgnore}) => {
  return <li className={styles.artist}>
    <Cover className={styles.cover} src={avatar} size={42} rounded={true}></Cover>

    <Link className={styles.artistTitle} href={'/artist/' + id}>
      {title}
    </Link>

    <div className={styles.fr}>
      <Button
        onClick={onLike}
        height={24}
        color={'#FF2C56'}
        borderColor={'rgba(255, 44, 86, .3)'}
        style={{
          marginRight: 10
        }}
      >喜欢</Button>

      <Button
        onClick={onIgnore}
        height={24}
        color={'#4A4A4A'}
        borderColor={'#DCDCDC'}
      >不感兴趣</Button>

    </div>

  </li>
}

export default class GuessArtists extends React.Component {

  constructor(props) {
    super(props)
    this.state = {}
  }

  componentDidMount() {
    this.getArtists()
  }

  likeArtist(artist) {
    request({
      url: `artist/${artist.id}/like`
      , method: 'put'
    }).then((response) => {
      this.props.addFavArtist(artist)
    })
    
    this.replaceArtist(artist)
  }

  ignoreArtist(artist) {
    // remove artist from here
    request({
      url: `artist/${artist.id}/uninterested`
      , method: 'put'
    })

    return this.replaceArtist(artist)
  }

  replaceArtist(artist) {
    request({
      url: 'artist/guess'
    }).then((response) => {
      // let newArtists = reject(this.state.artists, artist)
      let artists = clone(this.state.artists)
      , index = indexOf(this.state.artists, artist)
      artists[index] = response.artists[0]
      this.setState({ artists })
    })
  }

  onRefresh(e) {
    e.preventDefault()
    this.getArtists()
  }

  getArtists() {
    request({
      url: 'artist/guess'
      , method: 'get'
      , type: 'json'
    }).then((response) => {
      this.setState({
        artists: response.artists
      })
    }, (response, reason, err) => {
      console.error(err)
    })
  }

  render() {
    let artists = this.state.artists

    if(!artists || artists.length === 0) {
      return null
    }

    return <div className={styles.block}>
      <div className={styles.hd}>
        <h3>
          猜你喜欢的艺术家
          <a onClick={this.onRefresh.bind(this)}
             className={classnames(styles.fr, styles.changeBtn)}>
            <IconRefresh
              color={'#9B9B9B'}
              size={12}
              style={{marginRight: 6}}
            ></IconRefresh>
            换一批
          </a>
        </h3>
      </div>

      <ul>{artists.map((artist) => {
        if(!artist) {
          return null
        }
        return <Artist
          key={"artist-" + artist.id}
          title={artist.name_usual}
          avatar={artist.avatar}
          id={artist.id}
          onLike={this.likeArtist.bind(this, artist)}
          onIgnore={this.ignoreArtist.bind(this, artist)}
        ></Artist>
      })}</ul>
    </div>
  }
}
