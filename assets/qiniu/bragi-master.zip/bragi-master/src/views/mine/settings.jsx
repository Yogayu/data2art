import React from "react"
import MaterialUI from "material-ui"
import findIndex from "lodash/findIndex"

import notir from "controllers/notification"
import douradio from "douradio"

import injectTapEventPlugin from "react-tap-event-plugin"
injectTapEventPlugin()

let {
  FlatButton, RaisedButton, Toggle, Dialog, DropDownMenu, Snackbar,
  Slider
} = MaterialUI

import Loading from "ui/loading"

let ThemeManager = new MaterialUI.Styles.ThemeManager()
  , Colors = MaterialUI.Styles.Colors


class SettingDesktopNotification extends React.Component{

  onChange(e, toggled) {
    if(toggled) {
      notir.enable()
    } else {
      notir.stop()
    }
  }

  render() {
    let hasPermission = window.Notification.permission == 'granted',
      enableNotification = notir.isEnabled()

    if(!window.Notification) {
      return <FlatButton label="您的浏览器不支持桌面提醒" disabled={true} />
    } else {
      return <Toggle
        onToggle={this.onChange.bind(this)}
        name="allowNotification"
        value="true"
        label="开启换歌桌面提醒"
        defaultToggled={notir.isEnabled()}
        style={{
          display: 'inline-block',
          maxWidth: 200
        }}
      />
    }
  }

}


export class SettingPage extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      snackMessage: '',
      snackDuration: 5000,
      loading: true
    }
  }

  getChildContext() {
    return {
      muiTheme: ThemeManager.getCurrentTheme()
    }
  }

  componentWillMount() {
    douradio.getCurrentUser().then((response) => {
      this.setState({
        loading: false
      })
    })

    ThemeManager.setPalette({
      accent1Color: Colors.green500
    })
  }

  _handleAction() {}

  onKbpsChange(e, selectedIndex, menuItem) {
    douradio.setKbps(menuItem.payload).then((success) => {
      // display message for bitrate change
      this.setState({
        snackMessage: '码率变更为' + menuItem.payload,
        snackDuration: 5000
      })
    })
  }

  onVolumeChange(e, value) {
    return douradio.setVolume(value)
  }

  render() {
    if(this.state.loading) {
      return <Loading className="center"></Loading>
    }

    let bitrateChanger

    if(douradio.isPro()) {
      let menuItems = [
        {payload: 'auto', text: '根据网络环境，自动调节音质'},
        {payload: '192', text: '最佳音质，还原完整的听觉享受'},
        {payload: '128', text: '高音质，适合大多网络状况'},
        {payload: '64', text: '中等音质，适合网络状况不佳时'}
      ]
      let bitRate = douradio.getKbps() || 'auto'
      let selectedIndex = findIndex(menuItems, function (item) {
        return item.payload == bitRate
      })
      bitrateChanger = <DropDownMenu
       menuItems={menuItems}
       autoWidth={true}
       valueMember={'payload'}
       displayMember={'text'}
       selectedIndex={selectedIndex}
       onChange={this.onKbpsChange.bind(this)}
       ></DropDownMenu>
    } else {
      bitrateChanger = <RaisedButton
       href="http://douban.fm/settings/pro"
       label="购买Pro之后可以享受更高音质"
       primary={true}></RaisedButton>
    }

    return <div className="settings-page">
      <div className="container" style={{
          textAlign: 'center',
          paddingTop: 200
      }}>
        <h5>收听音质:</h5>
        {bitrateChanger}
        <h5>桌面提醒:</h5>
        <SettingDesktopNotification></SettingDesktopNotification>
        <h5>音量</h5>

        <Slider
         name="volume-slider"
         defaultValue={douradio.getVolume()}
         value={douradio.getVolume()}
         min={0} max={100}
         onChange={this.onVolumeChange.bind(this)}
         style={{width: 300, display: 'inline-block'}}
        ></Slider>

      </div>
      <Snackbar
        ref="snackbar"
        message={this.state.snackMessage}
        action="undo"
        autoHideDuration={this.state.snackHideDuration}
        onActionTouchTap={this._handleAction}
        openOnMount={true}
      />
    </div>
  }

}

SettingPage.childContextTypes = {
  muiTheme: React.PropTypes.object
}
