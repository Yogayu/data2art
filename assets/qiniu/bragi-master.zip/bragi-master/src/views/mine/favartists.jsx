import React from "react"
import request from "utils/request"
import {SearchResult} from "views/search/result"
import douradio from "douradio"
import union from "lodash/union"
import GuessArtists from "./GuessArtists"
import styles from "./favartists.module.css"
import TitleWithTooltip from "components/tooltip/TitleWithTooltip"
import Icon from "ui/icon"
import Link from "ui/link"
import EmptyView from 'views/login/tips/MineEmptyView'

import range from "lodash/range"
import { ArtistPlaceHolder  } from './placeholder'

let NoArtists = () => {
  return <p
    className="center"
    style={{textAlign: 'center'}}>没有收藏的艺术家</p>
}


export default class FavArtists extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      artists: []
      , isFetching: true
    }
  }

  componentDidMount() {
    this.request = request({
      url: 'artist/user_liked'
    }).then(({artists, limit, start, total}) => {
      if(!this.request) { return }
      this.setState({
        artists, limit, start, total, isFetching: false
      })
    })
  }

  componentWillUnmount() {
    if(this.request) {
      this.request.abort()
      this.request = null
    }
  }

  onLoadMore() {
    if(this.request) {
      this.request.abort()
    }

    let limit = 20

    this.request = request({
      url: 'artist/user_liked'
      , method: 'get'
      , data: {
        start: this.state.start + limit
        , limit: limit
      }}
    ).then(({artists, limit, start, total}) => {
      if(!this.request) { return }
      artists = union(this.state.artists, artists)
      this.setState({
        artists, limit, start, total, isFetching: false
      })
    })
  }

  addFavArtist(artist) {
    this.state.artists.unshift(artist)
    this.forceUpdate()
  }

  renderPlaceHolder() {
    return range(0, 6).map((i) => {
      return <ArtistPlaceHolder key={i} />
    })
  }

  render() {
    if(!douradio.isLogin()) {
      return <EmptyView>登录后查看并永久保留喜欢的艺术家</EmptyView>
    }

    let artists = this.state.artists.map((ar) =>
      new douradio.Artist(
        Object.assign(ar, {like: true}),
        {douradio: douradio}
      )
    )
    , isFetching = this.state.isFetching

    return <div className="container" style={{width: 660}}>
      {isFetching ? null :
        <GuessArtists
          addFavArtist={this.addFavArtist.bind(this)}
        ></GuessArtists>
      }

      <div className={styles.block}>
        <div className={styles.hd}>
          <TitleWithTooltip
            title={'已喜欢的艺术家'}
            tooltip={<span>FM会同步你在<Link href="//music.douban.com/mine" target="_blank">豆瓣音乐</Link>的数据</span>}
            icon={<Icon
              i={'info'}
              style={{position: 'relative', top: -2}}
            ></Icon>}
          ></TitleWithTooltip>
        </div>

        {!artists || artists.length === 0 ? (isFetching ? this.renderPlaceHolder() : <NoArtists></NoArtists>)
          : <SearchResult
          title={""}
          results={artists}
          total={this.state.total}
          type={'artist'}
          onLoadMore={this.onLoadMore.bind(this)}
          limit={20}
        ></SearchResult>}
      </div>

    </div>
  }
}
