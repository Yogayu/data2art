import "./songlist.scss"
import "./collection.scss"

import get from "lodash/get"

import React from "react"
import request from "utils/request"
import Cover from "components/cover"
import douradio from "douradio"
import Link from "ui/link"

import {CollectedChannel, } from "views/explore/channel"
import {ChannelList, } from "views/explore/channels"

import Notification from "ui/notification"
import MigratedSonglists from "views/dj-migrate"

import NoLoginView from 'views/login/tips/MineEmptyView'

import {SonglistsPlaceHolder, ChannelsPlaceHolder} from './placeholder'
import EmptyView from './EmptyView'


class CollectedChannels extends React.Component {

  componentDidMount() {
    // userinfo hack
    // may unmounted before callback
    douradio.getCurrentUser().then(() => {
      this.forceUpdate()
    })
  }

  // componentWillUnmount() {}

  handleClick(e) {
    e.preventDefault()
    e.stopPropagation()

    window.app.root.displayOverlay(
      <MigratedSonglists onClose={() => {
        this.forceUpdate()
        return window.app.root.hideOverlay('migrated')
      }}></MigratedSonglists>
    , 'migrated')
  }

  render() {
    let hasCollectedChannel = get(douradio, [
      'options', 'userinfo', 'has_collected_channel_songlist'
    ])

    return <div className="container">
      <ChannelList
        ChannelClass={CollectedChannel}
        type="collected"
        title={<h3>我收藏的兆赫</h3>}
        url="channel_collection"
        PlaceHolder={ChannelsPlaceHolder}
        limit="50">
        {hasCollectedChannel ? <Notification>
          你收藏的部分兆赫变成了歌单，请
          <a onClick={this.handleClick.bind(this)} href="">查看</a>
        </Notification> : null}
      </ChannelList>
    </div>
  }

}

class CollectedSonglist extends React.Component {

  constructor(props) {
    super(props)
    this.state = {removed: false}
  }

  onPlay(e) {
    e.preventDefault()
    let id = this.props.songlist.id
    return douradio.switchSonglist(id)
  }

  toggleCollect(e) {
    e.preventDefault()
    let id = this.props.songlist.id
    let sl = douradio.getSonglist(id)

    return  (this.state.removed ? sl.collect : sl.uncollect)
      .call(sl).then(() => {
        this.setState({
          removed: !this.state.removed
        })
      })
  }

  render() {
    let sl = this.props.songlist

    return <li
      className="link-collected link-songlist-collected"
    >
      <Cover size={48} src={sl.cover} onPlay={this.onPlay.bind(this)}></Cover>

      <div className="inner">
        <Link className="title" href={"/songlist/" + sl.id}>{sl.title}</Link>
        <p className="desc">2015.03.21 更新</p>
        <a
          className="link-toggle-collected"
          onClick={this.toggleCollect.bind(this)} href="#"
        >{this.state.removed ? '收藏' : '取消收藏'}</a>
      </div>
    </li>
  }
}


class CollectedSonglists extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      songlists: []
      , total: undefined
    }
  }

  componentDidMount() {
    this.request = request({
      url: 'programme/collection'
    }, 1000).then((response) => {
      if(!this.request) {
        return
      }
      this.setState({
        'songlists': response.programmes
        , 'total': response.total
      })
      this.request = null
    })
  }

  componentWillUnmount() {
    this.request && this.request.abort && this.request.abort()
    this.request = null
  }

  renderSonglists() {
    const {songlists, total} = this.state
    if(total === undefined) {
      return <SonglistsPlaceHolder></SonglistsPlaceHolder>
    }

    if(total === 0) {
      return <EmptyView>收藏的歌单会收集在这里</EmptyView>
    }

    return this.state.songlists.map((sl) => {
      return <CollectedSonglist
        key={"songlist-" + sl.id}
        songlist={sl}></CollectedSonglist>
    })
  }

  render() {
    // <p>曲目 {sl.songs_count}&nbsp;收藏 {sl.collected_count}</p>

    return <div className="container block">
      <h3>我收藏的歌单</h3>
      <ul className={'pl-list'}>{this.renderSonglists()}</ul>
    </div>
  }
}


export default function MyCollection() {
  if(!douradio.isLogin()) {
    return <NoLoginView></NoLoginView>
  }

  if(
    douradio.userinfo('channel_collected_num') === 0 &&
    douradio.userinfo('programme_collected_num') === 0
  ) {
    return <EmptyView>收藏的兆赫和歌单会收集在这里</EmptyView>
  }

  return <div className="my-collection">
   <CollectedChannels></CollectedChannels>
   <CollectedSonglists></CollectedSonglists>
  </div>
}
