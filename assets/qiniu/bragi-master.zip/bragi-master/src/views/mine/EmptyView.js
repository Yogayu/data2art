import React from 'react'
import IconEmpty from 'icons/icon-empty'
import Link from "ui/link"

export default function EmptyView({
  children
  , className
}) {
  return <div className={className || 'my-collection'} style={{
    textAlign: 'center'
    , paddingTop: '10%'
    , paddingBottom: '10%'
  }}>
    <IconEmpty></IconEmpty>
    <p style={{
      lineHeight: '24px'
      , color: '#757880'
    }}>
      {children}<br />
      去<Link href="/explore/channels" style={{color: '#45a156'}}>发现更多好音乐</Link>
    </p>
  </div>

}
