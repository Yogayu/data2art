import React from 'react'
import PlaceHolder, { PlaceHolderAlbumCover, } from 'components/place-holder'
import Cover from 'components/cover'
import range from "lodash/range"

export function ChannelsPlaceHolder() {
  return <ul className={'pl-list'}>{range(0, 3).map((i) =>
    <li className="link-collected" key={i}>
      <PlaceHolder
        width={66}
        height={66}
      ></PlaceHolder>

      <PlaceHolder
        width={108}
        height={14}
        style={{
          verticalAlign: 'top'
          , marginLeft: 12
        }}
      ></PlaceHolder>
    </li>
  )}</ul>
}

export function SonglistPlaceHolder () {
  return <li className="link-collected">
    <PlaceHolderAlbumCover
      size={66}
    ></PlaceHolderAlbumCover>

    <PlaceHolder
      width={108}
      height={14}
      style={{
        verticalAlign: 'top'
        , marginLeft: 12
      }}
    ></PlaceHolder>
  </li>
}

export function SonglistsPlaceHolder() {
  return <ul className={'pl-list'}>{range(0, 3).map((i) =>
    <SonglistPlaceHolder key={i}></SonglistPlaceHolder>
  )}</ul>
}

export function ArtistPlaceHolder () {
  return <div style={{
    marginTop: 30
  }}>
    <Cover
      size={48}
      rounded={true}
      src="//img1.doubanio.com/f/fm/ccf59e9485e4db05d7bc6df8931a67f925636f91/pics/fm/artist/default_avatar/person_small.png"></Cover>

    <PlaceHolder
      width={108}
      height={14}
      style={{
        verticalAlign: 'top'
        , marginLeft: 12
        , marginTop: 20
      }}
    ></PlaceHolder>
  </div>

}
