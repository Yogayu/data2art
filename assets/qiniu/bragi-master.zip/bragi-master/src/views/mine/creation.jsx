// 我制作的歌单
import "./songlist.scss"
import "./creation.scss"

import React from "react"
import {Songlist as ExploreSonglist} from "views/explore/songlists"
import request from "utils/request"
import douradio from "douradio"
import Cover from "components/cover"
import Link from "ui/link"
import classnames from "classnames"
import EmptyView from 'views/login/tips/MineEmptyView'

import { SonglistPlaceHolder } from './placeholder'
import range from 'lodash/range'


class CreationSonglist extends ExploreSonglist {

  onPlay() {
    let sl = this.props.songlist
    return douradio.switchSonglist(sl.id)
  }

  componentDidMount() {
    let songlist = this.props.songlist
    , needConfirm = songlist.need_user_confirm

    if(needConfirm) {
      this.setState({
        fade: true
      })

      // confirm songlist
      request({
        url: 'songlist/confirm'
        , data: {
          type: 'created'
          , id: songlist.id
        }
        , method: 'post'
      })
    }
  }

  render() {
    let sl = this.props.songlist
    , needConfirm = sl.need_user_confirm

    return <li
      key={"songlist-" + sl.id}
      className={classnames("link-collected", "link-songlist-collected", {
        "fade": needConfirm
      })}
    >
      <Cover size={66} src={sl.cover} onPlay={this.onPlay.bind(this)}>
        {!sl.is_public ? <div
          style={{
            position: 'absolute'
            , textAlign: 'center'
            , color: '#fff'
            , fontSize: 10
            , bottom: 0
            , left: 0
            , right: 0
            , lineHeight: '17px'
            , height: 17
            , backgroundColor: 'rgba(0, 0, 0, .7)'
          }}
        >未公开</div> : null}
      </Cover>
      <div className="inner">
        <Link href={'songlist/' + sl.id} className="title">{sl.title}</Link>
        <p className="subtitle">
          {sl.songs_count}首歌 {sl.collected_count}收藏
        </p>

        <div className="ft">
          <p>{sl.updated_time.slice(0, 10)} 更新</p>
        </div>
      </div>
    </li>
  }
}


export default class CreationPage extends React.Component {

  constructor(props) {
    super(props)
    // this.state = {sls: []}
  }

  componentDidMount() {
    return this.props.requestCreatedSonglists()

    /*
    douradio.mineSonglists.getAll()
    douradio.on('change:mine-songlist', () => {
      this.forceUpdate()
    }, this) */

  }

  componentWillUnmount() {
    // douradio.off(null, null, this)
  }

  handleCreateSonglist(e) {
    e.preventDefault()
    e.stopPropagation()

    ga('send', 'event', 'mine', 'CreateSonglist')

    require(['views/songlist/dialog-create'], (DialogCreateSonglist) => {
      // let id = 'dialog-create-songlist'
      window.app.root.displayOverlay(<DialogCreateSonglist
        onClose={window.app.root.hideOverlay.bind(null, 'dialog')}
      ></DialogCreateSonglist>, 'dialog')
    })
  }

  render () {
    // @todo update creation stats
    let {songlists, total, error, isFetching} = this.props.createdSonglists

    if(!douradio.isLogin()) {
      return <EmptyView></EmptyView>
    }

    return <div className="sl-make">
      <div className="container" style={{width: 660}}>
        <div className="block">
          <ul className="pl-list pl-list-mine">
            <li
              className="link-new-songlist"
              onClick={this.handleCreateSonglist.bind(this)}>
              <i className="icon-add"></i>
              制作新歌单
            </li>
            {isFetching ? range(0, 5).map((i)=> {
              return <SonglistPlaceHolder key={i}></SonglistPlaceHolder>
            }) : songlists.map((sl) =>
              <CreationSonglist
                key={'csl-' + sl.id}
                songlist={sl} />
            )}
          </ul>
        </div>
      </div>
    </div>
  }
}
