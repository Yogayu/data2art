import "./hearts.scss"
import "scss/ui/paginate.scss"

import React from "react"
import douradio from "douradio"
import Loading from "ui/loading"
import {SongList} from "../songlist"
import shallowCompare from "react/lib/shallowCompare"
import IconPlay from "icons/icon-play"
import debounce from "lodash/debounce"
import NoLoginView from 'views/login/tips/MineEmptyView'

import Waypoint from 'react-waypoint'
import IconScrollTop from 'icons/icon-scrolltop'

import { windowScrollY } from 'utils/domutils'

import EmptyView from './EmptyView'

// @todo Pagination
function log(action, label, value) {
  return ga('send', 'event', 'mine', action, label, value)
}

class HeaderCover extends React.Component {

  play(event) {
    log('RedheartPlayAll')
    event.preventDefault()
    douradio.switchSonglist(this.props.heartlist, true)
  }

  render() {
    let hl = this.props.heartlist
    let total = hl.length

    /* <div className="fr">
      <i className="icon-mobile"></i>
      在手机上收听
    </div>
    // disable for now
    */
    return <div className="header-cover">
      <button className="button button-rounded"
        onClick={this.play.bind(this)}>
        <IconPlay
          color={'#ffffff'}
          size={12}
          center={true}
          offsetLeft={1}
        ></IconPlay>
      </button>
      {total} 首红心歌曲
    </div>
  }
}

export default class HeartsPage extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      heartlist: douradio.getHeartlist()
      , limit: 30
    }

    this.onScroll = this.onScroll.bind(this)
  }

  componentWillMount() {
    let hl = this.state.heartlist

    hl.on('add remove reset', debounce((event) => {
      this.forceUpdate()
    }, 50), this)

    hl.fetch()
    douradio.on('login', () => hl.fetch(), this)

    window.addEventListener('scroll', this.onScroll)
  }

  onScroll(e) {
    let displayScrollTop = windowScrollY() > 50

    if(this.state.displayScrollTop === displayScrollTop) {
      return
    }

    this.setState({displayScrollTop})
  }

  componentWillUnmount() {
    this.state.heartlist.off(null, null, this)
    douradio.off(null, null, this)
    window.removeEventListener('scroll', this.onScroll)
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  onLoadMore(waypointEvent, num = 20) {
    // console.log('[waypoint] load more', arguments)
    this.setState({ limit: this.state.limit + num })
  }

  scroll2Top() {
    window.scrollTo(0, 0)
  }

  render() {
    if(!douradio.isLogin()) {
      return <NoLoginView>登录后查看并永久保留红心歌曲</NoLoginView>
    }
    let hl = this.state.heartlist
    , isReady = hl.info

    if(isReady && hl.length === 0) {
      return <EmptyView>红心歌曲可以帮助豆瓣FM为你推荐更对味的歌曲</EmptyView>
    }

    if(!isReady) {
      return <div className="page-heart-songs">
        <Loading className="center"></Loading>
      </div>
    }

    return <div className="page-heart-songs container" style={{
      width: 600
      , paddingBottom: 100
    }}>
      <HeaderCover heartlist={hl}></HeaderCover>
      <SongList
        begin={0}
        end={this.state.limit}
        songlist={hl}
      ></SongList>
      <Waypoint onEnter={this.onLoadMore.bind(this)}></Waypoint>

      {this.state.displayScrollTop ? <IconScrollTop
        onClick={this.scroll2Top.bind(this)}
        style={{
          position: 'fixed'
          , left: '50%'
          , marginLeft: 300
          , bottom: 105
        }}
      ></IconScrollTop> : null}
    </div>
  }

}
