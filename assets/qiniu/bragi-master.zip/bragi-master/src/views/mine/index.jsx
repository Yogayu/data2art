import React from "react"
import _findIndex from "lodash/findIndex"
import SectionSwitcher from "ui/section-switcher"

import HeartsPage from "./hearts"
import FavArtists from "./favartists"
// import {SLMade} from 'views/explore/songlists'
import MyCollection from "./collection"
import CreationPage from "./creation"
import douradio from 'douradio'

function log(action, label, value) {
  // console.log('send-event-explore:',Array.prototype.join.call(arguments, ' '))
  return ga('send', 'event', 'mine', action, label, value)
}

class MineSectionSwitcher extends SectionSwitcher {

  componentDidMount() {
    super.componentDidMount()

    douradio.on('login', () => {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    super.componentWillUnmount()

    douradio.off(null, null, this)
  }
}

export default class MinePage extends React.Component {
  constructor(props) {
    super(props)
    this.state = {page: null}

    this.sections = [
      {
        component: HeartsPage
        , title: '我的红心'
        , url: 'hearts'
      }, {
        component: MyCollection
        , title: '我的收藏'
        , url: 'collection'
      }, {
        component: CreationPage
        , title: '我制作的歌单'
        , url: 'created'
      }, {
        component: FavArtists
        , title: '我喜欢的艺术家'
        , url: 'artists'
      }
    ]
  }

  onSwitch(section) {
    // Switch Channel
    log('SwitchTab', section.url)

    window.app.navigate(
      'mine/' + section.url,
      {trigger: true}
    )
  }

  render() {
    let currentIndex = _findIndex(this.sections, (section, index) => {
      return section.url === this.props.subpage
    })

    if(currentIndex < 0) {
      currentIndex = 0
    }

    return <MineSectionSwitcher
      onSwitch={this.onSwitch}
      className="section-switcher section-switcher-mine"
      sections={this.sections}
      currentIndex={currentIndex}
    ></MineSectionSwitcher>
  }

}
