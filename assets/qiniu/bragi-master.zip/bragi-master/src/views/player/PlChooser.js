// default style
import styles from './PlChooser.module.css'
import { Motion, spring } from 'react-motion'
import React from 'react'
import classnames from 'classnames'
import Cover from 'components/cover'
import douradio from 'douradio'

import isString from "lodash/isString"
import find from "lodash/find"

import IconPlaying from 'icons/icon-playing-wave'
import IconHeart from 'icons/icon-heart'
import IconAngle from 'icons/icon-angle'
import IconOpen from 'icons/icon-open'

import IconShare from 'icons/icon-share'
import IconLink from 'icons/icon-link'
import IconStar from 'icons/icon-star'

import DailySonglistCover from 'views/songlist/daily-songlist-cover'

import { Link } from 'react-router'
import shallowCompare from 'react/lib/shallowCompare'

// import RecentPlaylist from 'views/settings/RecentPlaylist'

function getPlTitle(pl) {
  if(pl.type === 'channel') {
    return pl.title + ' MHz'
  }
  return pl.title
}

const switchPlaylist = (pl) => {
  if(pl.type === 'songlist'){
    douradio.switchSonglist(pl.id)
  } else {
    douradio.switchChannel(pl.id)
  }
}


class Pl extends React.Component {

  static defaultProps = {
    title: '我的私人'
    , type: 'channel'
    , id: 0
    , avatar: ''
    , disabled: false
    , isCurrent: false

    , rounded: true

    , shareable: true
    , collectable: true
  }

  constructor(props) {
    super(props)
    let {type, id} = props
    this.state = {
      model: this.getModel(type, id)
      , isFetching: false
    }
  }

  getModel(type, id) {
    let pl = type === 'songlist' ?
      douradio.getSonglist(id) : douradio.getChannel(id)
    return pl
  }

  componentDidMount() {
    this.setState({ isFetching: true })

    this.state.model.fetch().then(() => {
      this.setState({ isFetching: false })
    })
  }

  onClick(e) {
    e.preventDefault()

    if(
      this.props.disabled
      || this.props.isCurrent
    ) {
      e.stopPropagation()
      return
    }

    switchPlaylist({ type: this.props.type, id: this.props.id })
    this.props.onClose()
  }

  onShare(e) {
    let { type, id } = this.props
    let pl = type === 'songlist' ?
      douradio.getSonglist(id) : douradio.getChannel(id)

    pl.fetch().then(() => {
      window.app.share(null, pl)
    })
  }

  handleCollect() {
    let model = this.state.model
    return (
      model.isCollect() ? model.uncollect() : model.collect()
    ).then(() => {
      this.forceUpdate()
    })
  }

  onNavigate() {
    let { type, id } = this.props

    if(type === 'songlist') {
      window.app.navigate('/songlist/' + id)
    }
  }

  render() {
    let isCollected = this.state.model.isCollect()

    return <li
      className={classnames(styles.pl, this.props.isCurrent ? styles.plCurrent : null)}
      style={this.props.style}
    >
      {this.props.isCurrent ? <div className={styles.wave}>
        <IconPlaying></IconPlaying>
      </div> : null}

      <div
        onClick={this.onClick.bind(this)}
      >
        {isString(this.props.avatar) ?
          <Cover
            size={20}
            rounded={this.props.type === 'channel'}
            src={this.props.avatar}
          ></Cover> : this.props.avatar}
        <span className={styles.plTitle}>{this.props.title}</span>
      </div>

      <div className={styles.actions}>
        {this.props.type === 'songlist' ? <IconLink
          onClick={this.onNavigate.bind(this)}
          style={{marginLeft: 10}}></IconLink> : null}
        {this.props.collectable ? <IconStar
          onClick={this.handleCollect.bind(this)}
          color={isCollected ? '#2f9842' : '#C6C6C6'}
          style={{marginLeft: 10}}></IconStar> : null}
        {this.props.shareable ? <IconShare
          style={{marginLeft: 10}}
          onClick={this.onShare.bind(this)}
        ></IconShare> : null}
      </div>
    </li>
  }
}

/**
 * @todo merge recentPlaylists With fixed Playlists
 */
function FixedChannels (props) {
  const {
    onClose
    , currentPl
    , showRecentCollected
    , recentPlaylists
  } = props

  const defaultPls = [{
    title: '我的私人'
    , type: 'channel'
    , id: 0
    , avatar: douradio.userinfo('icon') || 'https://img3.doubanio.com/icon/ul2419751-51.jpg'

    , shareable: false
    , collectable: false
  }, {
    title: '我的红心歌曲'
    , type: 'songlist'
    , id: 'redheart'
    , avatar: <IconHeart
    size={18}
    liked={true}
    style={{ top: -5 }}
    ></IconHeart>

    , shareable: false
    , collectable: false
  }, {
    title: '每日私人歌单'
    , type: 'songlist'
    , id: 'user_daily'
    , avatar: <DailySonglistCover
      src={props.dailySonglistCover}
      size={20}></DailySonglistCover>

    , shareable: false
    , collectable: false
  }, {
    title: '豆瓣精选'
    , type: 'channel'
    , id: -10
    , avatar: 'https://img3.doubanio.com/f/fm/55cc7ebd1777d5101a82d7d6ce47ffc5e114131d/pics/fm/san_favicon.png'

    , shareable: true
    , collectable: false
  }]

  // let toAppendList = defaultPls.filter((pl) => {
  //   return findIndex(
  //     recentPlaylists,
  //     (rpl) => rpl.id == pl.id && rpl.type == pl.type
  //   ) < 0
  // })

  let hasCurrent = false
  , pls = recentPlaylists
  // .concat(toAppendList)
  .map(function (o) {
    // replace current pl with special pl
    let findedSpecialPl = find(
      defaultPls,
      (rpl) => rpl.id == o.id && rpl.type == o.type
    )

    if(findedSpecialPl) {
      o = findedSpecialPl
    }

    if(currentPl && o.type == currentPl.type && o.id == currentPl.id) {
      hasCurrent = true
      return Object.assign({}, o, { isCurrent: true })
    }

    return o
  })

  if(!hasCurrent && currentPl) {
    pls = pls.unshift({
      title: currentPl.getTitle()
      , id: currentPl.id
      , type: currentPl.type
      , avatar: currentPl.getCover()
      , isCurrent: true
    })
  }

  // console.log('PLS:::', pls.toJSON())

  return <div>
    <div className={styles.inner}>
      {pls.map((info, i) => {
        return <Pl
          rounded={false}
          onClose={onClose}
          key={info.type + '-' + info.id}
          style={i === 0 ? {marginTop: 0} : {}}
          {...info}
          title={getPlTitle(info)}
          ></Pl>
      })}
    </div>
    <hr className={styles.hr} />
    <div className={styles.inner}>
      <a
        className={styles.link}
        href=""
        onClick={showRecentCollected.bind(this)}
      >
        我最近收藏的兆赫和歌单
        <IconAngle
          direction="right"
          style={{
            position: 'absolute'
            , right: 28
            , bottom: 20
          }}
        ></IconAngle>

      </a>
    </div>
  </div>
}


class RecentCollected extends React.Component {

  constructor(props) {
    super(props)
  }

  render() {
    let { playlists, } = this.props.recentCollected

    return <div>
      <div className={styles.inner}>
        <a
          className={styles.link}
          href=""
          onClick={this.props.hideRecentCollected}
        >
        <IconAngle
          direction="left"
          style={{
            position: 'absolute'
            , left: 18
            , top: 22
          }}
        ></IconAngle>
        我最近收藏的兆赫和歌单
        </a>
      </div>
      <hr className={styles.hr} />
      <div className={styles.inner}>
        {playlists.length > 0 ? playlists.map(pl =>
          <Pl
            key={pl.type + '-' + pl.id}
            onClose={this.props.onClose}
            title={getPlTitle(pl)}
            avatar={pl.cover}
            id={pl.id}
            type={pl.type}

            collectable={false}
            shareable={false}
          ></Pl>
        ) : <div className={styles.noContent}>
          暂无收藏 <Link
            className={styles.linkGreen}
            to={'/explore/channels'}>去发现音乐</Link>
        </div>}

        {playlists.length > 0 ? <li className={styles.pl}>
          <Link
            to={'mine/collection'}
            className={styles.linkGreen}>
            查看全部收藏
          </Link>
        </li> : null}
      </div>
    </div>
  }
}


class PlChooserOverlay extends React.Component {

  static defaultProps = {}

  constructor() {
    super()
    this.state = { showRecentCollected: false }
  }

  componentDidMount() {}

  onClick(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  showRecentCollected (e) {
    e.preventDefault()

    this.props.fetchRecentCollect()
    this.setState({ showRecentCollected: true })
  }

  hideRecentCollected (e) {
    e.preventDefault()
    this.setState({ showRecentCollected: false })
  }

  render() {
    return <div
      className={styles.PlChooserOverlay}
      onClick={this.onClick.bind(this)}
      style={this.props.style}
    >
      {this.state.showRecentCollected ?
        <RecentCollected
          hideRecentCollected={this.hideRecentCollected.bind(this)}
          {...this.props}></RecentCollected>
        : <FixedChannels
          showRecentCollected={this.showRecentCollected.bind(this)}
          {...this.props}></FixedChannels>}
      </div>
  }

}

class PlChooser extends React.Component {
  constructor (props) {
    // store played playlist here
    super(props)
    this.state = {}
  }

  componentDidMount() {
    this.props.fetchRecentPlaysource()
  }

  prependPl() {
    let random = parseInt(Math.random() * 1000 , 10)
    this.state.pls.unshift({
      type: 'channel'
      , id: random
      , title: `兆赫-${random}`
    })
    this.forceUpdate()
  }

  displayMore(e) {
    e.preventDefault()
    e.stopPropagation()
    this.props.togglePlChooser()
  }

  onSwitchPl(pl) {
    if(pl.type === 'songlist'){
      douradio.switchSonglist(pl.id)
    } else {
      douradio.switchChannel(pl.id)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    const willUpdate = shallowCompare(this, nextProps, nextState)
    // willUpdate && console.count('render:PlChooser')
    return willUpdate
  }

  renderOverlay(customStyle={}) {
    return this.props.showPlChooser ?
      <PlChooserOverlay
        style={customStyle}
        currentPl={this.props.currentPlaylist}
        onClose={this.props.togglePlChooser}
        fetchRecentCollect={this.props.fetchRecentCollect}
        recentCollected={this.props.recentCollected}
        recentPlaylists={this.props.recentPlaylists}
        dailySonglistCover={this.props.dailySonglistCover}
      ></PlChooserOverlay> : null
  }

  renderMini() {
    let pls = this.props.recentPlaylists
    , pl = pls.first()

    if(!pl) {
      return null
    }

    let fontSize = 13
    , fontWeight = 400
    , height = 18
    , opacity = 1

    return <div  className={styles.plChooser}>
      <div
        onClick={this.displayMore.bind(this)}
        style={{
          fontSize
          , fontWeight
          , height
          , lineHeight: `${height}px`
          , color: '#2f9842'
          , bottom: 0
          , left: 0
          , position: 'absolute'
          , width: 280
          , opacity
        }}
      >
        {getPlTitle(pl)}
        <IconOpen
          size={14}
          style={{top: -2, marginLeft: 0}}
        ></IconOpen>
      </div>
      {this.renderOverlay({
        top: -18
        , left: 0
      })}
    </div>
  }

  render () {
    if(this.props.ap > 0.5) {
      return this.renderMini()
    }

    let pls = this.props.recentPlaylists

    return <div
      className={styles.plChooser}
      onClick={this.displayMore.bind(this)}
    >
      <IconPlaying
        size={12}
        style={{
          position: 'absolute'
          , left: -22
          , bottom: 4
        }}
        color={this.props.color}
      ></IconPlaying>

      {pls.slice(0, 1).map((pl, i) => {
        let style
        , isCurrent = false

        if(i === 0) {
          style = {
            fontSize: spring(16)
            , fontWeight: 400
            , height: 22
            , y: spring(0)
            , opacity: spring(1)
          }
          isCurrent = true
        } else if(i === 1) {
          style = {
            fontSize: spring(13)
            , fontWeight: 300
            , height: 18
            , y: spring(30)
            , opacity: spring(0.6)
          }
        } else if (i === 2) {
          style = {
            fontSize: spring(12)
            , fontWeight: 300
            , height: 17
            , y: spring(52)
            , opacity: spring(0.3)
          }
        } else {
          // fade out
          style = {
            fontSize: 12
            , fontWeight: 300
            , height: 17
            , y: spring(70)
            , opacity: spring(0)
          }
        }

        return <Motion
          defaultStyle={{
            fontSize: 16
            , fontWeight: 400
            , height: 22
            , y: -30
            , opacity: 0
          }}
          style={style}
          key={`${pl.type}-${pl.id}`}
        >
          {({fontSize, fontWeight, height, y, opacity}) => {
            return <div
              style={{
                fontSize
                , fontWeight
                , height
                , lineHeight: `${height}px`
                , color: this.props.color || '#2f9842'
                , bottom: y
                , left: 0
                , position: 'absolute'
                , width: 430
                , opacity

                , overflow: i === 0 ? '' : 'hidden'
              }}>
                {getPlTitle(pl)}
                {isCurrent ? <IconOpen
                  style={{top: -2, marginLeft: 14}}
                  color={this.props.color}
                ></IconOpen> : null}
              </div>
          }}
        </Motion>
      })}

      {this.renderOverlay()}
    </div>
  }
}

import { connect } from 'react-redux'

export default connect((state) => {
  let rp = state.player.recentPlaylists

  if(!douradio.userinfo('is_personal_service_enabled')) {
    rp = rp.delete('songlist|user_daily')
  }

  return {
    recentPlaylists: rp.map(key => state.playlists.get(key)).toList()
  }
}, (dispatch) => {
  return {}
})(PlChooser)
