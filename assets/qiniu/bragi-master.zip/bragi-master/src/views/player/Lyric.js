import './lyric.scss'
import React from "react"
import douradio from 'douradio'
import Lyrics from "components/lyrics"

export default class PlayingLyrics extends React.Component {

  constructor(props) {
    super(props)
    this.state = {lyric: null}
  }

  initLyric(model) {
    this.setState({lyric: null})

    if(!model || !model.get('sid')) {
      return
    }

    this.forceUpdate()

    this.request = douradio.getLyric(model).then((lyric) => {
      this.setState({lyric: lyric})
      this.forceUpdate()
    }, () => {
      // #if failed, set as no lyric
      this.setState({lyric: ""})
      this.forceUpdate()
    })
  }

  handleReportLyric(e) {
    e.preventDefault()
    console.debug('open a report window or do something here')
  }

  onClose(e) {
    e.preventDefault()
    this.props.onClose()
  }

  shouldComponentUpdate(nextProps, nextState) {
    return false
  }

  componentDidMount() {
    if(!this.state.lyric && douradio.currentSong) {
      this.initLyric(douradio.currentSong)
    }
    douradio.on('switch_song', this.initLyric, this)
  }

  componentWillUnmount() {
    this.request && this.request.abort && this.request.abort()
    douradio.off(null, null, this)
  }

  render() {
    return <div className="playing-lyrics">
      <Lyrics
        className={'lyrics'}
        lyric={this.state.lyric}
        douradio={douradio}
      ></Lyrics>
      <div className="lyrics-toolbar">
        <a onClick={this.onClose.bind(this)} href="#">关闭歌词</a>
      </div>
    </div>
  }
}
