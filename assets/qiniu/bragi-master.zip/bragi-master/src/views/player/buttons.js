// List of player buttons
import React from 'react'
import douradio from 'douradio'

// base class for player-buttons
class PlayerButton extends React.Component {
  // trigger action and send events to ga
  triggerAction(name) {
    // events available here, toggleLike, prev, trash, skip
    let fn = douradio[name]
    if(fn) {
      fn.apply(douradio)
      window.ga && window.ga('send', 'event', 'fullplayer', name)
    }
  }
}

import IconHeart from "icons/icon-heart"
export class Heart extends PlayerButton {
  static defaultProps = {
    size: 26
  }

  componentDidMount() {
    douradio.on('like unlike switch_song', () => {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  render () {
    let liked = douradio.currentSong && douradio.currentSong.isLike()

    return <IconHeart
      onClick={this.triggerAction.bind(this, 'toggleLike')}
      size={this.props.size}
      color={'#4A4A4A'}
      liked={liked}
      label={liked ? '取消红心' : '加红心'}
    ></IconHeart>
  }

}

import IconTrash from 'icons/icon-trash'

export class Trash extends PlayerButton {
  render () {
    return <IconTrash
      size={this.props.size}
      onClick={this.triggerAction.bind(this, 'ban')}
      label={'不再播放'}
    ></IconTrash>
  }
}

import IconPlay from "icons/icon-play"
import IconPause from "icons/icon-pause"

export class TogglePause extends PlayerButton {

  render () {
    let isPlaying = !this.props.paused

    let onClick = this.triggerAction.bind(this, 'togglePause')

    return isPlaying ? <IconPause
      label={'暂停'}
      color={'#4a4a4a'}
      size={this.props.size}
      onClick={onClick}>
    </IconPause> : <IconPlay
      label={'播放'}
      size={this.props.size}
      color={'#4a4a4a'}
      onClick={onClick}
    ></IconPlay>
  }

}


import IconSonglist from 'icons/icon-list'

export class ToggleSonglist extends PlayerButton {

  render () {
    return <IconSonglist
      label={'展开歌单'}
      onClick={this.props.onClick}
      size={this.props.size}
      color={'#b9b9b9'}
    ></IconSonglist>
  }

}

import IconShuffle from 'icons/icon-shuffle'

export class ToggleShuffle extends PlayerButton {

  componentDidMount() {
    douradio.on('change:shuffle', () => {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  static defaultProps = {
    size: 17
  }

  render () {
    const isShuffle = douradio.isShuffle()

    return <IconShuffle
      label={isShuffle ? '随机播放' : '顺序播放'}
      size={this.props.size}
      onClick={douradio.toggleShuffle.bind(douradio)}
      color={isShuffle ? '#6BBD7A' : '#b9b9b9'}
    ></IconShuffle>
  }

}


import IconPrev from 'icons/icon-prev'
import IconSkip from 'icons/icon-skip'

export class Prev extends PlayerButton {
  render () {
    return <IconPrev
      label={'上一首'}
      onClick={this.triggerAction.bind(this, 'prev')}
      size={this.props.size}></IconPrev>
  }
}

export class Skip extends PlayerButton {
  render () {
    return <IconSkip
      label={'下一首'}
      onClick={this.triggerAction.bind(this, 'skip')}
      size={this.props.size}></IconSkip>
  }
}

// end of button declear
class Space extends React.Component {

  render () {
    return <span style={{
      width: this.props.width
      , display: 'inline-block'
    }}></span>
  }

}

import IconLyric from 'icons/icon-lyric'
import IconPush2Mobile from 'icons/icon-push2mobile'
import IconAdd from 'icons/icon-add'
import IconShare from 'icons/icon-share'
import shallowCompare from 'react/lib/shallowCompare'

export class SubButtons extends React.Component {

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  render () {
    let isLogin = douradio.isLogin()

    return <div className="sub-buttons">
      <IconLyric
        size={20}
        label={'显示歌词'}
        onClick={this.props.toggleLyric}
      ></IconLyric>
        <Space width={25}></Space>
      <IconPush2Mobile
        size={20}
        label={'离线歌曲到手机'}
        onClick={(e) => {
          e.stopPropagation()
          this.props.push2Device(douradio.currentSong, e)
        }}
      ></IconPush2Mobile>
        <Space width={25}></Space>
      {isLogin ? <IconAdd
        size={20}
        label={'添加歌曲到歌单'}
        onClick={(e) => {
          e.stopPropagation()
          this.props.add2songlist(douradio.currentSong, e)
        }}
      ></IconAdd> : null}
      {isLogin ? <Space width={25}></Space> : null}
      <IconShare
        size={20}
        label={'分享这首歌'}
        onClick={(e) => {
          e.stopPropagation()
          this.props.share(douradio.currentSong, douradio._playlist)
        }}
      ></IconShare>
    </div>
  }

}

// export class MainButtons extends React.Component {
export class MainButtons extends React.Component {
  shouldComponentUpdate(np, ns) {
    const willUpdate =  shallowCompare(this, np, ns)
    // if(willUpdate) {console.count('WillUpdate')}
    return willUpdate
  }

  render () {
    const props = this.props
    , playlist = props.currentPlaylist

    if(!playlist) {
      return null
    }

    let isSonglist = !playlist.isChannel()
    , isMini = props.ap === 1

    , size = isMini ? 16 : 26
    , middleSize = isMini ? 16 : 22
    , smallerSize = isMini ? 14 : 17

    , btnToggleSonglist = <ToggleSonglist
      size={smallerSize}
      onClick={props.togglePlayerSonglist}
    ></ToggleSonglist>

    return <div className="buttons">
      <Heart size={size}></Heart>

        <Space width={isMini ? 22 : 32}></Space>

      <Trash size={size}></Trash>

        {isMini ? <Space width={isSonglist ? 30 : 22}></Space> : null}

      <div style={
        props.ap < 0.5 ?
          { position: 'absolute', right: 0, top: 2 }
        : { display: 'inline-block' }
      }>
        {isSonglist ? <span>
          {isMini ? null : <span>
            {btnToggleSonglist}
            <Space width={20}></Space>
          </span>}

          <ToggleShuffle size={smallerSize}></ToggleShuffle>

          <Space width={isMini ?  15 : 30}></Space>

          <Prev size={middleSize}></Prev>
          <Space width={isMini ? 22 : isSonglist ? 40 : 60}></Space>
        </span> : null}

        <TogglePause
          size={middleSize}
          paused={props.paused}
          ></TogglePause>

        <Space width={isMini ? 22 : isSonglist ? 40 : 60}></Space>

        <Skip size={middleSize}></Skip>

        {isSonglist && isMini ? <span>
          <Space width={12}></Space>
          {btnToggleSonglist}
        </span>: null}
      </div>
    </div>
  }
}
