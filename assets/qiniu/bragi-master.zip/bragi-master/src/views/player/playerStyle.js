function alignVerticalCenter(height, offsetY) {
  return {
    top: '50%'
    , marginTop: (-1 * height / 2) + offsetY + 30
    , position: 'absolute'
  }
}

function alignHorizontalCenter(width, offsetX) {
  return {
    left: '50%'
    , marginLeft: (-1 * width / 2) + offsetX
    , position: 'absolute'
  }
}

function middlePlus(height, margin) {
  if(margin > 0) {
    return {
      position: 'absolute'
      , top: margin
      , height: height
      , lineHeight: `${height}px`
    }
  } else if (margin < 0) {
    return {
      position: 'absolute'
      , bottom: -1 * margin
      , height: height
      , lineHeight: `${height}px`
    }
  } else {
    return { position: 'absolute' }
  }
}

export const styles = {
  player: {
    backgroundColor: 'rgba(250, 250, 250, 0.93)'
    , position: 'relative'
    , width: '100%'
  }

  , header: Object.assign({
    position: 'absolute'
    , top: 0
  })

  , left: Object.assign(
    {}
    , alignVerticalCenter(200, 0)

    // 距离中间60px
    , alignHorizontalCenter(
      200, -1 * (430 / 2 + 200 / 2 + 60)
    )
    , {
      // backgroundColor: 'rgb(231, 76, 60)',
      width: 200
      , height: 200
    }
  )

  // middle
  , middle: Object.assign(
    { width: 430 },
    alignVerticalCenter(0, 0)
    , alignHorizontalCenter(430, 0)
  )

  // right
  , right: Object.assign(
    {
      width: 240
      , height: 240
    }
    , alignVerticalCenter(240, 0)
    , alignHorizontalCenter(240, 430 / 2 + 120 + 40)
  )

  // progress is in the middle of the canvas
  , progress: Object.assign({
    position: 'absolute'
    , top: 0
    , left: 0
  })

  , progressAbove1: Object.assign(
    middlePlus(13, -10)
    , {
      fontSize: 11
      , fontWeight: 400
      , color: '#9b9b9b'
      , width: '100%'
    }
  )

  , progressAboveSubtitle: Object.assign(middlePlus(18, -38), {
    fontSize: 15
    , fontWeight: 400
    , lineHeight: 1.2
    , color: '#4a4a4a'
    , opacity: 1
  })

  , progressAboveTitle: Object.assign(middlePlus(32, -64), {
    fontSize: 25
    , fontWeight: 400
    , lineHeight: 1.28
    , color: '#030303'

    , whiteSpace: 'nowrap'
    , textOverflow: 'ellipsis'
    // middle width
    , maxWidth: '100%'
    , overflow: 'hidden'

    , zIndex: 1000
  })

  , progressAbovePlChooser: Object.assign(
    middlePlus(0, -156)
  )

  , buttons: Object.assign(
    middlePlus(25, 59)
    , {
      height: 16
      , lineHeight: 1
      , width: '100%'

      , x: 0
      , y: 0
    }
  )
}


export const miniStyles = {
  progressAboveTitle: {
    bottom: 8
    , height: 16
    , fontSize: 14
    , fontWeight: 400
    , lineHeight: 1.14
    , color: '#030303'
    , width: 330
  }

  , progressAboveSubtitle: {
    y: 30
    , x: 260
    , opacity: 0
  }

  , progressAbove1: {
    y: 26// styles.progressAbove1.height + styles.progressAbove1.bottom + 5
    , x: 0
  }

  , buttons: {
    y: -68
    , x: 390
  }

}

import keys from 'lodash/keys'
import mapValues from 'lodash/mapValues'
import isNumber from "lodash/isNumber"
import omit from "lodash/omit"
import map from "lodash/map"

import { supportTransform } from 'utils/feature-detect'

const transformMap = {
  x: 'translateX'
  , y: 'translateY'
  , scale: 'scale'
  , rotate: 'rotate'
}

export default function getAnimationStyle(name, ap) {
  let styleBegin = styles[name]
  , styleEnd = miniStyles[name]

  if(!styleEnd) { return styleBegin }

  if(supportTransform) {
    let motionStyle = mapValues(styleEnd, (valueEnd, key, object) => {
      let valueBegin = styleBegin[key]

      if(transformMap[key] && !valueBegin) {
        valueBegin = 0
      }

      if(isNumber(valueEnd) && isNumber(valueBegin)) {
        return valueBegin + ap * (valueEnd - valueBegin)
      }

      if(ap > 0.8) {
        return valueEnd
      } else {
        return valueBegin
      }
    })

    let transformStr = map(transformMap, (funcName, key) => {
      let value = motionStyle[key]
      if(value) {
        let unit = ''
        if(key === 'x' || key === 'y') {
          unit = 'px'
        } else if (key === 'rotate') {
          unit = 'deg'
        }
        return `${funcName}(${value}${unit})`
      } else {
        return null
      }
    }).filter(function (s) { !!s }).join(' ')

    let result = Object.assign({},
      styleBegin
      , omit(motionStyle, keys(transformMap))
      , { transform: transformStr }
    )
    return result
  } else {
    return Object.assign(
      {}, styleBegin,
      ap === 1 ? omit(styleEnd, keys(transformMap)) : null
    )
  }
}
