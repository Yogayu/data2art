import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'

import TextAd from "components/tooltip/textAd"
import { adLog } from 'app/actions/log'

export default connect((state) => {
  return state.player.textAd || {}
}, (dispatch) => {
  return bindActionCreators({
    onDisplay: adLog.bind(null, 'show')
    , onClick: adLog.bind(null, 'click')
  }, dispatch)
})(TextAd)
