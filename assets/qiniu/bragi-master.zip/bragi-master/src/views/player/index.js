// Rewrite the Player Component
import "./cover.scss"

import titleStyles from './title.module.css'

// basic libs
import React from 'react'

import get from "lodash/get"
import pick from 'lodash/pick'

import lang from "i18n"

// animation related libs
import gas, { styles, miniStyles } from './playerStyle'
import { Motion, spring } from 'react-motion'

// sub components
import {TimeLabel, Progress} from "views/playing/progress"
import VolumeSlider from "views/playing/volume-slider"

import PlayingLyrics from './Lyric'
import PlayingSonglist from "views/songlist/playing"

import PlayingCover from "components/playing-cover"
import PlChooser from './PlChooser'
import {MainButtons, SubButtons} from './buttons'

import TextAd from "./textAd"

// help components
import Background from "views/playing/background"
import PlaceHolder from 'components/place-holder'
import ArtistLabels from "views/common/artists"
import OverflowText from "components/overflow-text"
import Link from 'ui/link'

import shallowCompare from 'react/lib/shallowCompare'
import { transformPrefix } from 'utils/feature-detect'
import { transform } from 'utils/domutils'

//
import douradio from 'douradio'

// animation helper
function fromTo(from, to, progress=0) {
  return from + (to - from) * progress
}

import { supportTransform } from 'utils/feature-detect'

// heres what todo with the animation
export default class FMPlayer extends React.Component {

  static defaultProps = {
    mh: 100
  }

  constructor(props) {
    super(props)
    this.state = {
      ani: false
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if(nextProps.ap > 0 && nextProps.ap < 1) {
      return false
    }

    return shallowCompare(this, nextProps, nextState)
  }

  componentDidMount() {
    // window.setInterval(this.toggleAnimated.bind(this), 2000)
  }

  handleDrag() {
    // handle mouse drag, scrollDrag and touchDrag
  }

  toggleAnimated() {
    // this.setState({ani: !this.state.ani})
    this.props.togglePlayer()
  }

  getAnimationStyle (name, ap) {
    return gas(name, ap)
  }

  viewAlbum(url, event) {
    event.preventDefault()
    window.open(url, '_blank')
  }

  onLogin(e) {
    e.preventDefault()
    window.app.showLogin()
  }

  renderTips() {
    let hasCollectedChannel = douradio.userinfo('has_created_channel_songlist')

    if(hasCollectedChannel) {
      return <Notification style={{
        position: 'absolute'
      , right: 0
      , top: 87
      }}>
        你制作的兆赫已经变成歌单了，请
        <Link onClick={() => {
          // hide this link after confirmed
          douradio.options.userinfo.has_created_channel_songlist = false
        }} href="/mine/created">查看</Link>
      </Notification>
    } else {
      return null
    }
  }

  render () {
    // data source
    let song = this.props.currentSong
    , pl = this.props.currentPlaylist
    // , userinfo = get(douradio, ['options', 'userinfo']) || {}
    // , isLogin = !!userinfo.id
    , ap = this.props.ap

    // theme config
    let bgad = (pl && pl.info && pl.info.bg_ad) || {}

    return <div
      style={Object.assign({}, styles.player, {
        height: '100%'
        , width: '100%'
        , position: 'static'
      })}
    >
      <Motion
        style={{
          opacity: spring(1 - ap)
          , scale: spring(1 - ap)
        }}
      >{(motionStyle) => {
        let { showLyric, showPlayerSonglist } = this.props.leftArea

        return <div
          style={Object.assign({
            [transformPrefix]: `scale(${motionStyle.scale})`
            , opacity: motionStyle.opacity
            , display: motionStyle.opacity === 0 ? 'none' : null
          }, styles.left)}
          className="left"
        >
          {showLyric ?
            <PlayingLyrics
              onClose={this.props.toggleLyric}></PlayingLyrics> : null}
          {(!showLyric && showPlayerSonglist
            && !pl.isChannel())
            ? <PlayingSonglist
              onClose={this.props.togglePlayerSonglist}
              songlist={pl}></PlayingSonglist> : null}

          {bgad.pic ? <div style={{
            backgroundImage: `url(${bgad.pic})`
            , backgroundSize: 'cover'
            , width:  170
            , height: 170
            , position: 'absolute'
            , top: -150
            , left: 0
            , zIndex: 0
          }}></div> : null}

        </div>
      }}</Motion>

      <Motion
        style={{
          y: spring(ap * ((this.props.win.height - this.props.mh) / 2 - 50 - 30))
          , x: spring( ap * -110 )
          , width: 430 - 100 * ap
          , ap: spring(ap)
        }}
      >{(motionStyle) => {
        let motionAp = motionStyle.ap

        return <div
          className="middle"
          style={{
            ...styles.middle
            , ...transform(motionStyle.x, motionStyle.y)
            , width: motionStyle.width
          }}
        >
          <div
            style={Object.assign({}, styles.progressAbovePlChooser, {
              bottom: fromTo(styles.progressAbovePlChooser.bottom, -26, motionAp)
            })}
          >
            <PlChooser
              {...pick(this.props
                , 'recentCollected', 'fetchRecentCollect',
                'fetchRecentPlaysource', 'togglePlChooser', 'showPlChooser', 'ap', 'currentPlaylist', 'dailySonglistCover')}
              color={bgad.color}
            ></PlChooser>
          </div>

          <div style={this.getAnimationStyle('progressAboveTitle', motionAp)}>
            {song ?
              <Link
                ga={{
                  category: 'fullplayer'
                  , action: 'SongSel'
                }}
                href={song.isAd() ?
                  song.get('album')
                  : "/song/" + song.objectId()}
                className={titleStyles.title}
                style={{
                  fontSize: motionAp < 0.5 ? 25 : 14
                  , fontWeight: 400
                  , color: bgad.color || '#030303'
                }}
              >{song.get('title')}</Link>
              : <PlaceHolder width={323} height={20}></PlaceHolder>}

            {song && ap > 0.6 ?
              <span> - <ArtistLabels
                song={song}
                childStyle={{
                  fontSize: 14
                  , fontWeight: 400
                  , color: bgad.color || '#030303'
                }}
                ga={{category: 'miniplayer', action: 'ArtistSel'}}
              ></ArtistLabels></span>
            : null}
          </div>

          <div style={this.getAnimationStyle('progressAboveSubtitle', motionAp)}>
            {song ?
              <ArtistLabels
                childStyle={{
                  fontSize: 15
                  , fontWeight: 400
                  , lineHeight: 1.2
                  , color: bgad.color || '#4a4a4a'
                }}
                song={song}
                ga={{
                  category: 'fullplayer'
                  , action: 'ArtistSel'
                }}
              ></ArtistLabels> : <PlaceHolder width={103} height={14}></PlaceHolder>}
          </div>

          <div style={styles.progressAbove1}>
            <div
              style={{
                ...transform(0, motionAp * 23)
                , display: 'inline-block'
                , float: motionAp > 0.5 ? 'right' : null
                , color: '#9b9b9b'
              }}
              className="volume-and-time"
            >
              <TimeLabel style={{
                color: '#9b9b9b'
                , fontWeight: 400
                , marginRight: ap === 0 ? 10 : 5
                , display: 'inline-block'
                , width: 40
              }}></TimeLabel>
              <VolumeSlider
                size={15}
              ></VolumeSlider>
            </div>

            <Motion style={{
              opacity: 1 - ap
            }}>{({opacity}) => {
              if(song && song.isAd()) {
                return null
              }

              return <div
                className="sub-buttons-wrapper"
                style={{
                  float: 'right'
                  , opacity
                  , display: opacity === 0 ? 'none' : null
                }}>
              <SubButtons {...this.props}></SubButtons>
            </div>}}</Motion>
          </div>

          <Progress
            className="playing-progress"
            style={styles.progress}
            barColor={bgad.bar_color}
            bgColor={null}
          ></Progress>

          <Motion
            style={{
              x: spring(
                ap * miniStyles.buttons.x
              )
              , y: spring(
                ap * miniStyles.buttons.y
              )
              , width: ap === 0 ? 430 : 380
              , scale: spring(1) // spring(ap === 0 ? 1 : 0.61)
            }}
          >{({x, y, width, scale}) => {
            return <div style={Object.assign({}, styles.buttons, {
              ...transform(x, y, 0, scale)
              , width
            })}>
              <MainButtons
                {...pick(
                  this.props,
                  'currentPlaylist'
                  , 'ap'
                  , 'togglePlayerSonglist'
                  , 'paused'
                )}
              ></MainButtons>
            </div>
          }}</Motion>
        <TextAd display={ap === 0} {...this.props.textAd} />
        </div>
      }}</Motion>


      <Motion
        style={{
          opacity: spring(1 - ap)
          , scale: spring(1 - ap)
        }}
      >{(motionStyle) => {
        return <div
          className="right"
          style={Object.assign({}, styles.right, {
            [transformPrefix]: `scale(${motionStyle.scale})`
            , opacity: motionStyle.opacity
            , display: motionStyle.opacity === 0 ? 'none' : null
          })}
        >
          <PlayingCover
            size={240}
            paused={!douradio.isPlaying()}
            loading={douradio.isLoading()}
            src={song ? song.get('picture') : null}
            onClick={song ? this.viewAlbum.bind(this, song.albumLink()) : null}
          >
            <span className="hover-tip">
              {song && song.isAd() ?
                '查看详情' : lang('PLAYING_VIEW_ALBUM')}
            </span>
          </PlayingCover>
        </div>
      }}</Motion>
    </div>
  }

}
