// Single Song Page
import "./song-page.scss"

import React from "react"
import request from "utils/request"
import Loading from "ui/loading"
// import Popup from 'ui/popup'
import Link from "ui/link"
import parseLyrics from "components/lyrics/parser"
import Cover from "components/cover"
import douradio from "douradio"
import Song from "douradio/song"
import Icon from "ui/icon"
import IconHeart from "icons/icon-heart"
import IconPlay from "icons/icon-play"

import ArtistLabels from "views/common/artists"

import {Songlist} from "views/explore/songlists"
import IconPush2Mobile from 'icons/icon-push2mobile'
import IconAdd from 'icons/icon-add'
import IconShare from 'icons/icon-share'
// import douradio from 'douradio'


class LyricsView extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      expend: false
      , lines: parseLyrics(props.lyrics).lines
    }
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.lyrics !== this.props.lyrics) {
      this.setState({
        lines: parseLyrics(nextProps.lyrics).lines
        , expend: false
      })
    }
  }

  onExpend(e) {
    e.preventDefault()
    this.setState({
      expend: true
    })
  }

  render() {
    let lines
    if(this.state.expend) {
      lines = this.state.lines
    } else {
      lines = this.state.lines.slice(0, 10)
    }

    return <pre className="page-lyrics">
      {lines.map((line, index) => {
        return <p key={index}>{line.lyric}</p>
      })}
      {this.state.expend ?
        null :
        <a href="#" className='expend'
           onClick={this.onExpend.bind(this)}>展开全部歌词</a>
      }
    </pre>
  }
}

class Button extends React.Component {

  render() {
    return <button {...this.props}>{this.props.children}</button>
  }

}

export default class SingleSongPage extends React.Component {

  constructor(props) {
    super(props)
    this.state = {}
    this.model = new Song({
      sid: props.sid
    })
    this.model.fetch(request)
  }

  componentWillMount() {
    this.model.on('sync change', () => {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    this.model.off(null, null, this)
  }

  onShare(e) {
    e.preventDefault()
    e.stopPropagation()
    return window.app.share(this.model)
  }

  onClose(e) {
    e.preventDefault()
    return this.props.onClose()
  }

  playChannel(e) {
    e.preventDefault()
    let channel = this.model.get('related_channel')
    if(channel) {
      douradio.switchChannel(channel.id)
    }
  }

  onToggleLike(e) {
    e.preventDefault()

    return this.model.toggleLike(request)
  }

  onBan(e) {
    e.preventDefault()
    return this.model.toggleBan(request)
  }

  render() {
    let song = this.model
    , relatedSonglists = song.relatedSonglists()

    , isLogin = douradio.isLogin()

    if(!song.has('title')) {
      return <Loading className="center"></Loading>
    }

    // below: tst hack

    // relatedSonglists = []
    // song.set('lyric', null)
    // song.set('related_channel', null)

    //

    let isPlayable = song.isPlayable()

    return <div className="song-page">
      <div className="header">
        <Cover size={168} src={
          song.get('picture') || song.get('related_channel').cover
        }></Cover>

        <div className="contents">
          <h1 className="title">
            <span>{song.get('title')}</span>
            {!isPlayable ? <span className="noplable">未上架</span> : null}
          </h1>

          <div className="infos">
            <p
              className="subtitles"
              style={{
                height: 34
              }}
            >
              <ArtistLabels song={song}></ArtistLabels>
              <Icon i="point" size={9}></Icon>
              <Link href={song.albumLink()} target="_blank">{song.get('albumtitle')}</Link>
              <Icon i="point" size={9}></Icon>
              {song.get("public_time")}
            </p>

            <p style={{margin: '0 0 5px 0'}}>
              {isPlayable ? '从这首歌出发收听' : '收听相似歌曲'}
            </p>
            {song.get('related_channel') ? <Button
              className="button button-primary"
              onClick={this.playChannel.bind(this)}
              style={{
                maxWidth: 290
              }}
            >
              <IconPlay color={'white'} size={13} style={{
                top: -1
              }}></IconPlay>
              &nbsp; &nbsp;
              {song.get('related_channel').name}
              <small>MHz</small>
            </Button> : <button className="button button-primary button-disable">
              <IconPlay color={'#C4C4C4'} size={13} style={{
                top: -1
              }}></IconPlay>
              &nbsp; &nbsp;
              收听数据准备中
            </button>}
          </div>

          <div className="ft">
            <a href="#" className="button-white" onClick={this.onToggleLike.bind(this)}>
              <IconHeart liked={song.isLike()} size={14}></IconHeart>
              {song.get('liked_count')}
            </a>

            <a href="#"
               className="button-white"
               onClick={window.app.push2Device.bind(null, song)}
            >
              <IconPush2Mobile
                size={16}
                style={{marginTop: -1}}></IconPush2Mobile>
              离线到手机
            </a>

            {isLogin ? <a
              href="#"
              className="button-white"
              onClick={window.app.add2songlist.bind(null, song)}
            >
              <IconAdd size={15}></IconAdd>
              添加到歌单
            </a> : null}

            <a className="button-white"
              href="#"
              onClick={this.onShare.bind(this)}>
                <IconShare size={15}></IconShare>分享
            </a>

          </div>
        </div>
      </div>

      {song.get('lyric') ?
        <LyricsView lyrics={song.get('lyric')}></LyricsView> : <p className="empty-msg">暂无歌词</p>}

      {relatedSonglists && relatedSonglists.length > 0 ?
        <div className={'related-songlists'}>
          <h3>包含这首歌的歌单</h3>

          <div className="songlists">{song.relatedSonglists().map((sl) => {
            return <Songlist key={'songlist-' + sl.id} songlist={sl}></Songlist>
          })}</div>
      </div> : <p className="empty-msg">暂无包含这首歌的歌单</p>}

    </div>
  }
}
