// the artist page
import "./artist-page.scss"

import React from "react"

import request from "utils/request"
import douradio from "douradio"
import Artist from "douradio/artist"

import Loading from "ui/loading"
import Cover from "components/cover"
import Icon from "ui/icon"
import Button from "components/button"

import {ChannelLink, SonglistLink} from "ui/link"
import {ArtistSonglistSong} from "views/songlist/song"

class ArtistSonglist extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      full: false
    }
  }

  showMore(e) {
    e.preventDefault()
    let songlist = this.props.songlist
    // this.setState({full: true})
    return window.app.navigate("/songlist/" + songlist.id, {trigger: true})
  }

  render() {
    return <ul className="artist-songlist">{(this.state.full ?
      this.props.songlist : this.props.songlist.slice(0, 5)
    ).map((song, index) => {
      return <ArtistSonglistSong
        key={'song-' + song.id}
        song={song}
        index={index}
      ></ArtistSonglistSong>
    })}
    {this.state.full ? null : <li>
      <a className="more-link" onClick={this.showMore.bind(this)}
         href="#">查看全部精选歌曲</a>
    </li>}
    </ul>
  }
}

export default class ArtistPage extends React.Component {
  constructor(props) {
    super(props)
  }

  initModel(aid) {
    if(this.model) {
      this.model.off(null, null, this)
    }
    this.model = new Artist({id: aid})
    this.model.on('sync change', () => this.forceUpdate(), this)
    this.model.fetch(request)
  }

  componentWillMount() {
    this.initModel(this.props.aid)
  }

  componentWillUnmount() {
    this.model.off(null, null, this)
  }

  componentWillReceiveProps(nextProps) {
    // console.log(nextProps)
    if(nextProps.aid !== this.props.aid) {
      this.initModel(nextProps.aid)
    }
  }

  onClose(e) {
    e.preventDefault()
    return this.props.onClose()
  }

  onShare(e) {
    e.preventDefault()
    e.stopPropagation()
    return window.app.share(this.model)
  }

  handleLike(e) {
    e.preventDefault()
    return this.model.toggleLike(request)
  }

  jump2(id, event) {
    return window.app.navigate(
      '/artist/' + id,
      {trigger: true}
    )
  }

  render() {
    let artist = this.model
    if(!artist.has('name_usual')) {
      return <Loading className="center"></Loading>
    }

    let songlist = artist.getSonglist(douradio)
    let channel = artist.get('related_channel')

    return <div className="artist-page">
      <div className="banner">
        <div className="top">
          <a onClick={this.onShare.bind(this)} href="#share">
            <Icon i="share"></Icon>
            分享
          </a>
        </div>
        <Cover
          rounded={true}
          className="avatar"
          size={168}
          src={artist.get('avatar')}
        ></Cover>

      </div>

      <div className="inner">
        <h1 className="artist-name">{artist.get('name_usual')}</h1>

        <p className="styles">{artist.get('style').join(' / ')}</p>

        <div className="actions">

          <Button
            onClick={this.handleLike.bind(this)}
            height={24}
            {...(artist.get('like') ? {
              color: '#FF2C56'
              , borderColor: 'rgba(255, 44, 86, .3)'
            } : {
              color: '#8F8E94'
              , borderColor: '#E0E0E0'
            })}
          >
            {artist.get('like') ? '已喜欢' : '喜欢'} {artist.get('liked_count') || ''}
          </Button>

        </div>

        {songlist ? <div className="related-block">
          <SonglistLink
            color={'#45A156'}
            songlist={songlist}>全部精选歌曲</SonglistLink>
          <ArtistSonglist
            songlist={songlist}
          ></ArtistSonglist>
        </div> : null}

        {channel ? <div className="related-block">
          <ChannelLink
            color={'#45A156'}
            className="playable-button"
            id={channel.id}>{channel.name}</ChannelLink>
          <p>该兆赫可能包含以下相似艺术家的歌曲</p>
          <ul className="similar-artists">
            {(artist.get('related_channel').similar_artists || []).map((artist) => {
              let onClick = this.jump2.bind(this, artist.id)

              return <li onClick={onClick} key={'artist-' + artist.id} className="similar-artist">
                <Cover onClick={onClick} rounded={true} size={78} src={artist.avatar}></Cover>
                <h3>{artist.name_usual}</h3>
              </li>
            })}
          </ul>
        </div> : null}
      </div>
    </div>
  }

}
