import styles from "./migrate.module.scss"

import get from "lodash/get"
import classnames from "classnames"
import douradio from "douradio"

import React from "react"
import request from "utils/request"
import Popup from "ui/popup"
import Cover from "components/cover"
import Icon from "ui/icon"
import Link from "ui/link"

import some from "lodash/some"

let MigratedSonglist = ({
  cover, title, onCollect, onDismiss, description="", isCollected
}) => {
  return <div className={styles.songlist}>
    <Cover className={styles.cover} src={cover} size={48}></Cover>
    <div className={styles.content}>
      <h3>{title}</h3>
      <button
        className={classnames('button', styles.button, styles.submit)}
        onClick={onCollect}>{isCollected ? '取消收藏' : '收藏'}</button>

      {isCollected ? null : <button
        className={classnames('button', styles.button, styles.ignore)}
        onClick={onDismiss}>忽略</button>}

      <p>{description}</p>
    </div>
  </div>
}

export default class MigrateSonglists extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      songlists: []
    }
  }

  componentDidMount() {
    request({
      url: 'songlist/collected_need_confirm'
    }).then((response) => {
      if(response.length === 0) {
        return this.onClose()
      }

      this.setState({
        songlists: response
      })
    })
  }

  _removeSonglist(removeSonglist) {
    let songlists = this.state.songlists.filter((sl) => {
      return sl !== removeSonglist
    })

    this.setState({
      songlists
    })

    if(songlists.length === 0) {
      return this.onClose()
    }
  }

  onCollect(songlist) {
    if(songlist.is_collected) {
      // uncollect here
      return request({
        url: 'programme/uncollect'
        , method: 'post'
        , data: {
          id: songlist.id
        }
      }).then(() => {
        songlist.is_collected = false
        return this.forceUpdate()
      })
    }

    // confirm and collect
    return request({
      url: 'songlist/confirm'
      , method: 'post'
      , data: {
        type: 'collected'
        , collect: 1
        , id: songlist.id
      }
    }).then(() => {
      songlist.is_collected = !songlist.is_collected
      return this.forceUpdate()
      // this._removeSonglist(songlist)
    })
  }

  onDismiss(songlist) {
    request({
      url: 'songlist/confirm'
      , method: 'post'
      , data: {
        type: 'collected'
        , id: songlist.id
      }
    }).then(() => {
      return this._removeSonglist(songlist)
    })
  }

  handleClick(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  onClose() {
    let hasUncollect = some(this.state.songlists, function (songlist) {
      return !songlist.is_collected
    })

    if(!hasUncollect) {
      douradio.options.userinfo.has_collected_channel_songlist = false
    }

    this.props.onClose()
  }

  render() {
    // let hasSonglist = len(this.state.songlists) > 0
    let hasCollectedChannel = get(douradio, [
      'options', 'userinfo', 'has_created_channel_songlist'
    ])

    return <Popup className={styles.popup}>
      <div
        onClick={::this.handleClick}
        className="container popup-wrapper"
        style={{
          marginTop: 130
          , padding: '30px 30px 0 30px'
        }}
      >
        <h3 className={styles.sectionTitle}>你收藏的部分兆赫已经变成以下歌单</h3>
        <div className={styles.songlists}>{
          this.state.songlists.map((songlist) => {
            return <MigratedSonglist
              key={'songlist-' + songlist.id}
              cover={songlist.cover}
              title={songlist.title}
              description={`由 ${songlist.title} 兆赫迁移`}
              onCollect={this.onCollect.bind(this, songlist)}
              onDismiss={this.onDismiss.bind(this, songlist)}
              isCollected={songlist.is_collected}
            ></MigratedSonglist>
          })}
        </div>

        {hasCollectedChannel ?
        <div className={styles.block}>
            你制作的兆赫已经变成歌单，请<Link
            href={'/mine/created'}
            onClick={() => {
              this.onClose()
            }}>查看</Link>
        </div> : null}
      </div>

      <a href="#"
         className={'link-close'}
         onClick={() => {this.onClose()}}
      >
        <Icon i={'close'}></Icon>
      </a>
    </Popup>
  }

}
