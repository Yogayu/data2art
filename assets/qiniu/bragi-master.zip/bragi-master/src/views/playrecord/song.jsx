import React from "react"
import Cover from "components/cover"
import {SonglistSong} from "../songlist/song"
import styles from "./song.module.css"
import {IconClose} from "icons"
import IconHeart from "icons/icon-heart"
import Link from "ui/link"
import douradio from "douradio"
import ArtistLabels from "views/common/artists"
import Icon from "ui/icon"

let request = douradio.apiClient.request

export default class Song extends SonglistSong {

  constructor(props) {
    super(props)
    this.state = {
      hidden: false
    }
  }

  onUpdate() {
    this.forceUpdate()
    // this.props.onUpdate && this.props.onUpdate()
  }

  // toggleLike() {}
  onToggleBanned() {
    // unban a song
    this.setState({hidden: true})
  }

  onPlay() {
    return douradio.switchChannel(this.props.song.relatedChannelId())
  }

  render() {
    if(this.state.hidden) {
      return false
    }

    let {song} = this.props
    // , isCurrent = false

    return <li
      key={'song-' + song.id}
      className={styles.song}
    >
      <Cover
        size={36}
        iconSize={12}
        src={song.get('picture')}
        className={styles.cover}
        onPlay={this.onPlay.bind(this)}
      ></Cover>

      <div className={styles.titleGroup}>
        <div className={styles.title}>
          <Link href={'/song/' + song.objectId()}>{song.get('title')}</Link>
        </div>
        <div className={styles.subtitle}>
          <ArtistLabels song={song}></ArtistLabels>
          <Icon i={'point'} size={9}></Icon>
          {this.renderAlbum()}
          <Icon i={'point'} size={9}></Icon>
          {song.get("public_time")}
        </div>
      </div>

      <div className={styles.actions}>
        {this.props.heart ?
          <IconHeart
            onClick={() => {
              return song.toggleLike(request).then(this.onUpdate.bind(this))
            }}
            size={12}
            color={'#e1e1e1'}
            liked={song.isLike()}
            style={{
              position: 'absolute'
              , right: 0
              , top: 12
            }}
          ></IconHeart> : <IconClose
            onClick={() => {
              return song.toggleBan(request).then(this.onToggleBanned.bind(this))
            }}
            color={'#d8d8d8'}
            bgColor={'#ffffff'}
            hasCircle={false}
            size={28}
            style={{
              position: 'absolute'
              , top: 4
              , right: -8
            }}
        ></IconClose>}
      </div>
    </li>
  }

}
