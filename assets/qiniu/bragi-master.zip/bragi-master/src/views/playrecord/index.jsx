// full feature list of playrecords
import React from "react"
import douradio from "douradio"
import Song from "./song"
import styles from "./dialog.module.css"
import {ParallelogramLabel} from "../common/label"

function renderSongs(sl, songAttributes={}) {
  return <div className={styles.songs}>
    {sl.map((song) => {
      return <Song
        key={`playrecord-${song.id}`}
        song={song}
        {...songAttributes}
      ></Song>
    })}
  </div>
}

export class PlayRecords extends React.Component {

  componentDidMount() {
    douradio.playRecords.fetch()

    douradio.playRecords.on('update reset', function () {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    douradio.playRecords.off(null, null, this)
  }


  render() {
    let num = douradio.options.userinfo.played_num //douradio.playRecords.total

    return <div className={styles.dialog}>
      <h3 className={styles.title}>
        收听记录
        <div className={styles.fr}>
          累计收听
          &nbsp;
          <ParallelogramLabel>{num}首</ParallelogramLabel>
        </div>
      </h3>

      {renderSongs(douradio.playRecords, {heart: true})}

      <div className={styles.statusMessage}>
        <span className={styles.inner}>豆瓣FM暂时只能为你提供最近100条播放记录</span>
      </div>
    </div>
  }
}

export class BannedSongs extends React.Component {

  componentDidMount() {
    douradio.bannedSongs.fetch()
    douradio.bannedSongs.on('update reset', () => this.forceUpdate(), this)
  }

  componentWillUnmount() {
    douradio.bannedSongs.off(null, null, this)
  }

  render() {
    let number = douradio.bannedSongs.total

    return <div className={styles.dialog}>
      <h3 className={styles.title}>不再播放  ({number})</h3>
      {renderSongs(douradio.bannedSongs, {heart: false})}
    </div>
  }
}

// ->
//
