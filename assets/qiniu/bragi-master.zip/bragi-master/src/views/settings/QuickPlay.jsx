import React from "react"
import {ContextMenu, } from "components/context-menu"
import douradio from "douradio"

import IconPlay from "icons/icon-play"
import IconPlaying from "icons/icon-playing-wave"

import RecentPlaylist from "./RecentPlaylist"
import styles from "./quick-play.module.css"

import request from "utils/request"
import get from 'lodash/get'

class FixedPlaylist extends React.Component {

  static defaultProps = {
    title: '我的私人兆赫'
    , type: 'channel'
    , id: 0
    , height: 24
    , disabled: false
  }

  constructor(props) {
    super(props)
  }

  isCurrent() {
    let cpl = douradio.getCurrentPlaylist()
    return cpl && cpl.type === this.props.type && cpl.id == this.props.id
  }

  onClick(e) {
    e.preventDefault()
    if(this.props.disabled) {
      return
    }

    // let url = `/${this.props.type === 'channel' ? 'channel' : 'songlist'}/${this.props.id}`
    // log('fixedPlaylist', this.props.type, this.props.id)

    if(this.props.type === 'channel') {
      douradio.switchChannel(this.props.id)
    } else {
      douradio.switchSonglist(this.props.id)
    }
  }

  render() {
    return <a
      href={this.props.href}
      className={styles.fixedPl}
      onClick={this.onClick.bind(this)}
      style={Object.assign({
        lineHeight: `${this.props.height}px`
        , height: this.props.height
        , marginTop: (24 - this.props.height) / 2
      }, this.props.disabled ? {
        borderColor: '#c6c6c6'
        , color: this.props.disabled ? '#c6c6c6' : ''
        , cursor: this.props.disabled ? 'not-allowed' : 'pointer'
      }: {})}
      title={this.props.disabled ? '你还没有红心歌曲' : this.props.title}
    >
      {this.isCurrent() ? <IconPlaying
        animate={true}
        size={12}
        style={{
          marginTop: -2
          , marginRight: 4
        }}
      ></IconPlaying> : <IconPlay
      color={this.props.disabled ? '#c6c6c6' : undefined}
      size={8}
      style={{
        marginTop: -2
        , marginRight: 8
      }}></IconPlay>}

      {this.props.title}
    </a>
  }
}

export default class QuickPlay extends React.Component {

  constructor(props) {
    super(props)
    this.state = {playlists: []}
  }

  componentDidMount() {
    this.request = request({url: 'recent_collected'}).then((response) => {
      if(!this.request) {
        return
      }

      this.setState({
        playlists: response
      })
    }, (error) => {
      console.log(error)
    })

    douradio.on('switch_channel switch_songlist', () => {
      this.forceUpdate()
    }, this)

  }

  componentWillUnmount() {
    this.request = null
    douradio.off(null, null, this)
  }

  openUserGuide() {
    // this will trigger an event
    douradio.canSwitchPlaylist('channel', 0)
  }

  render() {
    const personalChannel = <FixedPlaylist type="channel" id={0} title={"我的私人兆赫"}></FixedPlaylist>
    , choosedChannel = <FixedPlaylist type="channel" id={-10} title={"豆瓣精选兆赫"}></FixedPlaylist>
    , userDaily = <FixedPlaylist type="songlist" id={'user_daily'} title={"每日私人歌单"}></FixedPlaylist>
    , redHeart = <FixedPlaylist
      disabled={douradio.userinfo('liked_num') == 0}
      type="songlist" id={'redheart'} title={"我的红心歌单"}
    ></FixedPlaylist>

    , hasPersonalService = douradio.hasPersonalService()

    return <ContextMenu {...this.props}>
      <div className={'inner'}>
        <div className={styles.plBox}>
          {hasPersonalService ?
            <div style={{marginBottom: 10}}>
              {personalChannel}
              <span className={styles.blank}>&nbsp;</span>
              {choosedChannel}
            </div>
            : <div style={{marginBottom: 10}}>
              {choosedChannel}
              <span className={styles.blank}>&nbsp;</span>
              {redHeart}
            </div>
          }

          {hasPersonalService ? <div>
            {userDaily}
            <span className={styles.blank}>&nbsp;</span>
            {redHeart}
          </div> : <div className="">
            <a className={styles.boxGreen} href="#" onClick={this.openUserGuide.bind(this)}>
              去开启我的私人兆赫
            </a>
          </div>}
        </div>

        <div className={styles.box}>
          <RecentPlaylist playlists={this.state.playlists}></RecentPlaylist>
        </div>

      </div>
    </ContextMenu>
  }

}
