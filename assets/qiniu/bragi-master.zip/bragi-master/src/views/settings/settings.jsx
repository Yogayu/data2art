import styles from "./settings.module.css"

import React from "react"
import RadioGroup from "react-radio-group"
import isEmpty from "lodash/isEmpty"
import IconAngle from "icons/icon-angle"

import {ContextMenu, ContextMenuItem, ContextMenuLine} from "components/context-menu"

import Link from 'ui/link'

import douradio from "douradio"

export class SettingsPro extends React.Component {

  onKbpsChange(value) {
    console.log('onKbpsChange', value)
    douradio.setKbps(value).then((success) => {
      // display message for bitrate change
      console.log('kbps value: ', value)
      this.forceUpdate()
    })
  }

  render() {
    return <div className={styles.settingsPage}>
      <li className={styles.back} onClick={this.props.onSwitch.bind(null, ['main'])}>
        <IconAngle direction="left" size={20}></IconAngle>
        PRO 设置
      </li>

      <RadioGroup
        name="kbps"
        selectedValue={douradio.getKbps()}
        onChange={this.onKbpsChange.bind(this)}
      >{(Radio)=> {
        return <div className={styles.kbpsOptions}>
          <li>
            <Radio value={'auto'}></Radio>
            自动调节音质
          </li>
          <li>
            <Radio value={'320'}></Radio>
            最佳音质
          </li>
          <li>
            <Radio value={'192'}></Radio>
            高音质
          </li>
          <li>
            <Radio value={'128'}></Radio>
            中等音质
          </li>

          <li>
            <Link href={"https://douban.fm/settings/pro/"}>续费与赠送</Link>
          </li>

        </div>
      }}</RadioGroup>
    </div>
  }
}

export class SettingsAccount extends React.Component {

  render() {
    return <div>
      <li onClick={this.props.onSwitch.bind(null, ['main'])}>
        <IconAngle direction="left" size={20}></IconAngle>
        <span style={{paddingLeft: 20}}>账户设置</span>
      </li>

      <ContextMenuLine></ContextMenuLine>

      <li onClick={this.props.onSwitch.bind(null, ['main', 'account', 'password'])}>
        更改密码
        <IconAngle direction="right" size={20}></IconAngle>
      </li>

      <li onClick={this.props.onSwitch.bind(null, ['main', 'account', 'phone'])}>
        绑定手机
        <IconAngle direction="right" size={20}></IconAngle>
      </li>
    </div>
  }

}

export class SettingsPassword extends React.Component {

  render() {
    return <div>
      <li onClick={this.props.onSwitch.bind(null, ['main', 'account'])}>
        <IconAngle direction="left" size={20}></IconAngle>
        &nbsp; &nbsp; 更改密码
      </li>

      <ContextMenuLine></ContextMenuLine>
      <li>
        <a target="_blank" href="https://www.douban.com/accounts/editpassword">去豆瓣修改密码</a>
      </li>


    </div>
  }
}

export class SettingsPhone extends React.Component {

  render() {
    return <div>
      <li onClick={this.props.onSwitch.bind(null, ['main', 'account'])}>
        <IconAngle direction="left" size={20}></IconAngle>
        &nbsp; &nbsp; 绑定手机
      </li>
      <ContextMenuLine></ContextMenuLine>
      <li>
        <a target="_blank" href="https://www.douban.com/accounts/phone/bind">去豆瓣绑定手机</a>
      </li>
    </div>
  }

}
