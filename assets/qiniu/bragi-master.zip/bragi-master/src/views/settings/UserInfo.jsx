import React from "react"
import styles from "./userinfo.module.css"
import Cover from "components/cover"
import Link from "ui/link"
// import clns from 'classnames'
import {ProLabel, } from "views/common/label"

export default function UserInfo (props) {
  let {isLogin, isPro, userinfo} = props

  return <div className={styles.block}>
    {isLogin ?
    <div className={styles.userinfo}>
      <Cover
        className={styles.avatar}
        rounded={true}
        size={36}
        src={userinfo.icon}
      ></Cover>

      {isPro ? <div className={styles.proTitle}>
        <span className={styles.username}>{userinfo.name}</span>
        &nbsp;&nbsp;
        <ProLabel></ProLabel>
      </div> : <div>
        <span className={styles.username}>{userinfo.name}</span>
        <br />
        <span className={styles.pro}>
          升级到 <Link href="//douban.fm/upgrade">
            <ProLabel className={styles.proLabel} disable={true}></ProLabel>
          </Link>
        </span>
      </div>}

    </div> : null}

    <div className={styles.records}>
      累计收听<Link href={"/mine/played"} className={styles.link}>{userinfo.played_num}</Link>首
      <br />
      红心<Link href={"/mine/hearts"} className={styles.link}>{userinfo.liked_num}</Link>首
      &nbsp;
      不再播放<Link href={"/mine/banned"} className={styles.link}>{userinfo.banned_num}</Link>首
    </div>
  </div>

}
