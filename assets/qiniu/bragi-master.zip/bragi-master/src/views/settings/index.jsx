// import './settings.scss'
import styles from "./dialog.module.scss"
import {ContextMenu, ContextMenuItem, ContextMenuLine} from "components/context-menu"

// settings popup
import React from "react"
// import douradio from 'douradio'
// import Cover from 'components/cover'
// import IconAngle from 'icons/icon-angle'
import shallowCompare from "react/lib/shallowCompare"

/*
class SettingsMainOld extends React.Component {

  componentWillMount() {
    // check
    if(!douradio.options.user_info) {
      douradio.getCurrentUser().then(() => {
        this.forceUpdate()
      })
    }
  }

  onLogout(e) {
    e.preventDefault()
    return douradio.logout()
  }

  openRouter(uri) {
    return window.app.router.navigate(uri, {trigger: true})
  }

  render() {
    if(!douradio.isLogin()) {
      return null
    }

    let userinfo = douradio.options.userinfo

    return <div>
      {userinfo ?
      <div className="username">
        <Cover rounded={true} size={36} src={userinfo.icon}></Cover>
        <span className="title">
          {userinfo.name}
          {douradio.isPro() ?
            <span className="label-pro">PRO</span>
          : null}
        </span>
      </div> : null}

      <ContextMenuLine></ContextMenuLine>

      <ContextMenuItem
        title={'我的FM'}
        href={'/mine'}
        onClick={this.openRouter.bind(this, '/mine')}
      ></ContextMenuItem>

      <ContextMenuLine></ContextMenuLine>

      {douradio.isPro() ? <li onClick={this.props.onSwitch.bind(null, ['main', 'pro'])}>
        Pro 设置
        <div className="subtitle">{userinfo.pro_expire_date}到期</div>
        <IconAngle direction="right" size={20}></IconAngle>
      </li> : null}

      <li onClick={this.props.onSwitch.bind(null, ['main', 'account'])}>
        账户设置
        <IconAngle direction="right" size={20}></IconAngle>
      </li>

      <ContextMenuItem
        href={"http://douban.fm/upgrade"}
        title={"升级/赠送 Pro"}
        target={'_blank'}
      ></ContextMenuItem>

      <ContextMenuItem
        onClick={this.onLogout.bind(this)}
        title={"退出"}
      ></ContextMenuItem>
    </div>
  }
}
*/

import SettingsMain from "./main"
import SettingsPro from './pro'

const PAGE_MAP = {
  'main': SettingsMain
  , 'pro': SettingsPro
  // , 'account': SettingsAccount
  // , 'password': SettingsPassword
  // , 'phone': SettingsPhone
}

export default class Settings extends React.Component {
  // init: ['main', null, null]
  // > pro: ['main', 'pro']
  // > settings: ['main', 'settings', 'password']
  // > settings: ['main', 'settings', 'phone']

  constructor(props) {
    super(props)
    this.state = {
      pages: this.props.pages || ['main']
      , popupHeight: null
    }
  }

  componentWillUnmount() {
    this.props.onClose && this.props.onClose()
  }

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  setPopupHeight() {
    // due
    return

    let currPage = this.state.pages[this.state.pages.length - 1]
    , dom = this.refs['page' + currPage]
    this.setState({
      popupHeight: dom.offsetHeight
    })
  }

  componentDidMount() {
    return this.setPopupHeight()
  }

  componentDidUpdate() {
    return this.setPopupHeight()
  }

  switchChild(childs, e) {
    e.preventDefault()
    return this.setState({pages: childs})
  }

  onRightClick(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  onClick(e) {
    e.stopPropagation()
  }

  render() {
    let width = 260
    , offset = width * (this.state.pages.length - 1)

    // console.debug('Settings Page', this.props)

    return <ContextMenu
      className={styles.dialog}
      {...this.props}
    >
      <div className={styles.wrapper} style={{
        transform: "translateX(" + -1 * offset + "px)"
        , height: this.state.popupHeight
      }}>
      {this.state.pages.map((key, index) => {
        let el = PAGE_MAP[key]
        return <div
          ref={'page' + key}
          className={styles.placeHolder}
          key={index}
        >{React.createElement(el, {
          onSwitch: this.switchChild.bind(this)
        })}</div>
      })}
      </div>
    </ContextMenu>
  }

}
