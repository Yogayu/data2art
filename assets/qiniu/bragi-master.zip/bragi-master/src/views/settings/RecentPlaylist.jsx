import styles from "./recent-playlist.module.css"
import playlogStyles from "./playlog.module.css"

import React from "react"
// import IconPlay from 'icons/icon-play'
import Link, {ChannelLink, SonglistLink} from "ui/link"

export default class RecentPlaylist extends React.Component {

  render() {
    let fontColor = '#030303'
    , hasContent = this.props.playlists && this.props.playlists.length > 0

    return <div className={styles.block}>
      <h3 className={styles.title}>我最近收藏的兆赫和歌单</h3>

      {hasContent ? this.props.playlists.map((pl) => {
        return <div
          key={pl.type + pl.id}
          className={styles.playlist}
        >{(pl.type === 'channel') ?
          <ChannelLink
            className={styles.link}
            iconSize={8}
            color={fontColor}
            id={pl.id}>{pl.name}</ChannelLink>
          : <SonglistLink
            className={styles.link}
            iconSize={8}
            color={fontColor}
            id={pl.id}
          >{pl.title}</SonglistLink>}
        </div>
      }) : <div className={styles.noContent}>
        暂无收藏 <Link
          className={playlogStyles.linkGreen}
          href={'/explore/channels'}>去发现音乐</Link>
      </div>}

      <div className={styles.autoPadding}>
        {hasContent ? <Link href={'/mine/collection'} className={playlogStyles.linkGreen}>
          查看全部收藏
        </Link> : null}
      </div>
    </div>
  }

}
