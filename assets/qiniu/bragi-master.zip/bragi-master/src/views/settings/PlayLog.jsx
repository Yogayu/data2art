import React from "react"
import IconPlay from "icons/icon-play"
import IconHeart from "icons/icon-heart"
import styles from "./playlog.module.css"
import ArtistLabels from "views/common/artists"
import Link from "ui/link"
// import Loading from 'ui/loading'
// import isEmpty from 'lodash/lang/isEmpty'

import douradio from "douradio"
import request from "utils/request"


let Song = ({song, onLike, onPlay}) => {
  return <div className={styles.song}>
    <IconPlay onClick={onPlay} className={styles.iconPlay} size={8} color={'#c6c6c6'}></IconPlay>

    <div className={styles.songTitle}>
      <Link href={'/song/' + song.objectId()}>
        {song.get('title')}
      </Link>
    </div>

    <div className={styles.artistLabel}>
      <ArtistLabels song={song}></ArtistLabels>
    </div>

    <IconHeart onClick={onLike} liked={song.isLike()} size={10} className={styles.iconHeart}></IconHeart>

  </div>
}

export default class PlayLog extends React.Component {

  static defaultProps = {
    songs: []
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  onPlay(song) {
    // Will play the similar song?
    return douradio.switchChannel(song.relatedChannelId())
  }

  onLike(song) {
    return song.toggleLike(request).then(() => {
      this.forceUpdate()
    })

    this.forceUpdate()
  }

  render() {
    // let hasSongs = isEmpty(this.props.songs)

    return <div className={styles.block}>
      {this.props.songs.map((song) => {
        return <Song
          onPlay={this.onPlay.bind(this, song)}
          onLike={this.onLike.bind(this, song)}
          key={song.id} song={song}></Song>
      })}
      <Link className={styles.linkGreen} href="mine/played">查看收听记录</Link>
    </div>
  }
}
