import styles from "./settings.module.css"

import React from "react"
import RadioGroup from "react-radio-group"
import IconAngle from "icons/icon-angle"

import Link from 'ui/link'

import douradio from "douradio"

export default class SettingsPro extends React.Component {

  onKbpsChange(value) {
    console.log('onKbpsChange', value)
    douradio.setKbps(value).then((success) => {
      // display message for bitrate change
      // console.log('kbps value: ', value)
      this.forceUpdate()
    })
  }

  render() {
    return <div className={styles.settingsPage}>
      <li className={styles.back} onClick={this.props.onSwitch.bind(null, ['main'])}>
        <IconAngle direction="left" size={20}></IconAngle>
        PRO 设置
      </li>

      <RadioGroup
        name="kbps"
        selectedValue={douradio.getKbps()}
        onChange={this.onKbpsChange.bind(this)}
      >{(Radio)=> {
        return <div className={styles.kbpsOptions}>
          <li>
            <Radio value={'auto'}></Radio>
            自动调节音质
          </li>
          <li>
            <Radio value={'320'}></Radio>
            最佳音质
          </li>
          <li>
            <Radio value={'192'}></Radio>
            高音质
          </li>
          <li>
            <Radio value={'128'}></Radio>
            中等音质
          </li>

          <li>
            <Link href={"https://douban.fm/settings/pro/"}>续费与赠送</Link>
          </li>

        </div>
      }}</RadioGroup>
    </div>
  }
}
