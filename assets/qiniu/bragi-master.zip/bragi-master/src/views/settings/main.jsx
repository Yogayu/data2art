import React from "react"
import styles from "./dialog.module.scss"
import UserInfo from "./UserInfo"
import PlayLog from "./PlayLog"

import douradio from "douradio"

import IconAngle from "icons/icon-angle"

export default class UserDialog extends React.Component {

  constructor(props) {
    super()
    this.state = {
      songs: []
    }
  }

  componentDidMount() {
    this._isMounted = true

    douradio.getCurrentUser(true).then(() => {
      if(this._isMounted) {
        this.forceUpdate()
      }
    })

    douradio.playRecords.fetch()
    douradio.playRecords.on('update reset', function () {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount(nextProps, nextState) {
    this._isMounted = false
    douradio.playRecords.off(null, null, this)
  }

  openAccount(e) {
    e.preventDefault()
    return window.open(
      'https://douban.com/accounts'
      , '_blank'
    )
  }

  render() {
    let userinfo = douradio.options.userinfo
    , isPro = userinfo.pro_status === "S"

    return <div>
      <UserInfo
        isLogin={true}
        isPro={isPro}
        userinfo={userinfo}
      ></UserInfo>

      <PlayLog songs={douradio.playRecords.slice(0, 5)}></PlayLog>

      {isPro ? <li className={styles.item} onClick={this.props.onSwitch.bind(null, ['main', 'pro'])}>
        Pro 设置
        <IconAngle direction="right" size={20}></IconAngle>
      </li> : null}

      <li className={styles.item} onClick={this.openAccount.bind(this)}>
        账户设置
      </li>

      <li className={styles.item} onClick={() => {
        douradio.logout()
      }}>退出</li>
    </div>
  }

}
