// ProLabel, Normal Label

// ParallelogramLabel
import React from "react"
import clns from "classnames"
import styles from "./label.module.css"

export function ParallelogramLabel ({
  color = '#2f9842'
  , borderColor = '#8ed99c'
  , bgColor = 'transparent'

  , children
  , className
}) {
  return <span
    className={clns(styles.label, className)}
    style={{
      backgroundColor: bgColor
      , borderColor: borderColor
    }}
  >
    <span
      className={styles.inner}
      style={{
        color: color
      }}
    >{children}</span>
  </span>
}

export function ProLabel(props) {
  let newProps = Object.assign({}, props.disable ? {
    bgColor: '#c4c4c4'
    , borderColor: '#b2b2b2'
    , color: 'white'
  } : {
    borderColor: '#d3bb81'
    , color: '#977e42'
  }, props)

  return <ParallelogramLabel
    {...newProps}
  >PRO</ParallelogramLabel>
}
