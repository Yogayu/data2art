// utils
import Link from "ui/link"
import React from "react"

let ArtistLabels = (props) => {
  let song = props.song

  let singers = song.get("singers")

  if(!singers) {
    return <span>{song.get("artist")}</span>
  }

  return <span
    className={props.className}
    title={props.title}
  >{singers.map((singer, index) => {
    let results = []

    results.push(<Link
      onClick={props.onClick}
      href={"/artist/" + singer.id}
      className="artist-name"
      style={props.childStyle}
      ga={props.ga}
    >
      {singer.name}
    </Link>)

    /*
    if(singer.related_site_id) {
      results.push(<Link
        href={"http://site.douban.com/" + singer.related_site_id}
        target="_blank"
        className="artist-label">豆瓣音乐人</Link>)
    } */

    if(singers.length !== index + 1) {
      results.push(<span> / </span>)
    }

    return results
  })}</span>
}

export default ArtistLabels
