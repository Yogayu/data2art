import React from "react"
import douradio from "douradio"
import ReactDOM from "react-dom"
import Icon from "ui/icon"
import Popup from "ui/popup"

/**
 * Manager Popup with history(back)
 */
export default class PopupManager extends React.Component {

  constructor(props) {
    super(props)
    this.history = []
    this.state = {}
  }

  componentDidMount() {

    this.props.router.on('route:songlist', function (slid) {
      if(!douradio._playlist) {
        // window.app.navigate("/", {trigger: false})
        return douradio.switchSonglist(slid)
      }

      if(slid === 'redheart') {
        return window.app.navigate("mine/hearts", {trigger: true})
      }
      // root.setPlayerStatus(PLAYER_MINI)
      require(['views/songlist'], (Songlist) => {
        let el = React.createElement(Songlist.default, {
          key: 'songlist-' + slid
          , songlist: douradio.getSonglist(slid)
          , onClose: this.onClose.bind(this)
        })
        this.displayOverlay(el)
      })
    }, this)

    this.props.router.on('route:song', function (sid) {
      // root.setPlayerStatus(PLAYER_MINI)
      require(['views/song'], (SingleSongPage) => {
        this.displayOverlay(
          <SingleSongPage
            key={'song-' + sid}
            sid={sid}
            onClose={this.onClose.bind(this)}
          ></SingleSongPage>
        )
      })
    }, this)

    this.props.router.on('route:artist', function (aid) {
      // root.setPlayerStatus(PLAYER_MINI)
      require(['views/artist'], (ArtistPage) => {
        this.displayOverlay(<ArtistPage
          key={'artist-' + aid}
          aid={aid}
          onClose={this.onClose.bind(this)}
        ></ArtistPage>)
      })
    }, this)

    this.props.router.on('route:banned', function () {
      // root.setPlayerStatus(PLAYER_MINI)
      require(['views/playrecord'], ({BannedSongs}) => {
        this.displayOverlay(
          <BannedSongs></BannedSongs>
        )
      })
    }, this)

    this.props.router.on('route:played', function () {
      // root.setPlayerStatus(PLAYER_MINI)
      require(['views/playrecord'], ({PlayRecords}) => {
        this.displayOverlay(
          <PlayRecords></PlayRecords>
        )
      })
    }, this)

  }

  displayOverlay(component) {
    let root = this.props.root

    // @TODO use better way
    root.setAp(1)
    root.setState({hasPopup: true})

    // Change the ui
    try {
      let root = ReactDOM.findDOMNode(this)
      root.scrollTop = 0
    } catch (e) {}

    if(this.state.currPage) {
      this.history.push(this.state.currPage)
    }
    // document.body.style.overflow = 'hidden'
    this.setState({currPage: component})
  }

  onClose(e) {
    if(e) {
      e.preventDefault()
    }
    this.close()
  }

  onPrev(e) {
    e.preventDefault()
    if(this.history.length > 0) {
      let history = this.history.pop()
      this.setState({
        currPage: history
      })
    }
  }

  isActive() {
    return !!this.state.currPage
  }

  close() {
    this.history = []
    let root = this.props.root
    this.setState({currPage: null})
    root.setState({hasPopup: false})
    return window.app.navigate('/', {trigger: false})
  }

  render() {
    if(this.isActive()) {
      let hasPrev = this.history.length > 0
      return <Popup
        onClose={this.onClose.bind(this)}>
        <div className="popup-wrapper container">
          {this.state.currPage}
        </div>
      {hasPrev ? <a href="#" onClick={this.onPrev.bind(this)} className={'link-prev'}>&lt; 返回</a> : null}
      <a href="#" className={'link-close'} onClick={this.onClose.bind(this)}>
        <Icon i={'close'}></Icon>
      </a>
    </Popup>
    } else {
      return <Popup hidden={true}></Popup>
    }
  }

}
