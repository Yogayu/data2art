import styles from './footer.module.css'
import React from 'react'
import Link from 'ui/link'

export default function Footer () {
  let year = (new Date()).getFullYear()

  return <div className={styles.footer}>
    <p className={styles.footerTop}>
      © {year} douban <Link href="http://www.miibeian.gov.cn/">京ICP备11027288号 </Link>
      网络视听许可证0110418号 京公网安备110105012274
    </p>

    <p className={styles.footerBottom}>
      <span>
        广告合作: <Link href="mailto:adfm@douban.com">adfm@douban.com</Link>
      </span><span> | </span>
      <Link href="https://labs.douban.com">FM游乐场</Link><span> | </span>
      <Link href="https://douban.fm/user_guide">FM用户手册</Link><span> | </span>
      <a href="#" onClick={(e) => {
        e.preventDefault()
        window.app.displayReleaseNotes()}
      }>新版说明</a><span> | </span>
      <a href="#" onClick={(e) => {
        e.preventDefault()
        window.app.displayFeedback(true)
      }}>我要反馈</a><span> | </span>
      <Link href="https://douban.fm/support/">豆瓣FM中心</Link>
    </p>

  </div>
}
