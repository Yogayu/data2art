/**
  description:
    1. tooltip-guide is only enabled when userguide is finished
    2. tooltip-guide will not displayed when userguide has displayed before.
    3. tooltip component should be placed in `fullplayer` component

  test tips:
  1.force display tooltip guide
    window.tgm.hasTooltip = true
    window.app.root.forceUpdate()
*/

// One Place to Manage State
import TooltipGuide from './Component'
import React from 'react'
import store, {KEY_IS_SHOWED_USERGUIDE} from 'controllers/stores'

class TooltipGuideManager {

  constructor() {
    this.hasTooltip = false
  }

  /**
   * only use for debug
   */
  _forceDisplay() {
    this.hasTooltip = true
    window.app.root.forceUpdate()
  }

  display() {
    this.hasTooltip = true
  }

  onFinish() {
    this.hasTooltip = false
  }

  render({scrolled}) {
    if(!this.hasTooltip) { return null }

    return <TooltipGuide
      scrolled={scrolled}
      onFinish={this.onFinish.bind(this)}
    ></TooltipGuide>
  }
}

let tgm = new TooltipGuideManager

window.tgm = tgm

export default tgm
