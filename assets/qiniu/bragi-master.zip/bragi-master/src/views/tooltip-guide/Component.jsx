import React from 'react'
import CompTooltip from 'components/tooltip'
import IconMice from './mice'

const nof = function () {}
// State manager
// when to display tooltip, when to close tooltip

class Tooltip extends CompTooltip {

  fixPosition() {
    let el = this.refs.root
    , offsetY = 0
    , direction = this.props.direction

    if(direction === 'top') {
      offsetY = -1 * el.offsetHeight
    } else if (direction === 'bottom') {
      offsetY = 0
    }

    this.setState({
      offsetX: 0
      , offsetY
    })
  }

}


class TextTip extends React.Component {

  static defaultProps = {
    x: 117
    , y: -219
  }

  constructor(props) {
    super(props)
  }

  componentWillMount() {}

  componentDidUpdate() {}

  onIKnow(e) {
    e.preventDefault()
    this.props.onFinish()
  }

  // rgb(47, 152, 66)

  render() {
    return <Tooltip
      visiable={true}
      direction={this.props.direction || 'bottom'}
      backgroundColor={'#e7e7e7'}
      color={'#4a4a4a'}
      style={{
        position: 'absolute'
        , lineHeight: '34px'
        , top: '50%'
        , left: '50%'
        , marginTop: this.props.y
        , marginLeft: this.props.x
      }}
      arrowStyle={this.props.arrowStyle}
      innerStyle={{
        padding: '0px 8px'
      }}
      >
      {this.props.children}
      &nbsp;
      &nbsp;
      <a
        className={'link'}
        style={{
          color: '#2f9842'
        }}
        onClick={this.onIKnow.bind(this)}
        href="#"
      >我知道啦</a>
    </Tooltip>
  }
}

function Step2 (props) {
  return <div
    style={{
      position: 'absolute'
      , bottom: 30
      , left: '50%'
      , fontSize: 14
      , color: '#4a4a4a'
    }}
  >
    <IconMice style={{
      position: 'relative'
      , top: 7
      , right: 14
    }}></IconMice>

    试试滚动鼠标
  </div>
}

export default class TooltipGuide extends React.Component {

  static defaultProps = {
    step: 0
    , onNextStep: nof
  }

  render() {
    if (this.props.step === 0) {
      return <TextTip
        x={-214}
        y={-122}
        arrowStyle={{left: 20, top: 1}}
        onFinish={this.props.onNextStep}
      >快速切换收听其他常用频道</TextTip>
    } else if(this.props.step === 1) {
      return <TextTip
        y={117}
        x={-219}
        arrowStyle={{left: 17, top: 1}}
        onFinish={this.props.onNextStep}
      >标记红心歌曲，加速开启定制音乐服务</TextTip>
    } else {
      return <Step2 onFinish={this.props.onNextStep}></Step2>
    }
  }

}
