import "./dialog-create.scss"

import React from 'react'
import Dialog from "components/dialog"
import toObject from "lodash/fromPairs"
// import isBoolean from 'lodash/lang/isBoolean'
import Songlist from "douradio/songlist"
import douradio from "douradio"

import RadioGroup from "react-radio-group"
import TextArea from "react-textarea-autosize"

let preventDefault = (e) => {
  e.preventDefault()
}


class DialogDeleteConfirm extends React.Component {

  handleCancel(e) {
    if(e) {e.preventDefault()}
    this.props.onNo()
  }

  handleConfirm(e) {
    e.preventDefault()
    this.props.onYes()
  }

  render() {
    let ftr = <div className="controls">
      <button
        onClick={this.handleConfirm.bind(this)}
        className="button button-submit fr"
        type="submit">确定</button>
      <button
         onClick={this.handleCancel.bind(this)}
         className="button fr" type="cancel">取消</button>
    </div>

    return <Dialog
      baseZIndex={30000}
      title={'删除歌单'}
      showMask={true}
      width={320}
      height={213}
      onClose={this.handleCancel.bind(this)}
      footer={ftr}
    >
      <p style={{
        fontSize: 13
        , color: '#111111'
        , lineHeight: '18px'
      }}>确定删除这个歌单吗?</p>
    </Dialog>
  }

}


export default class DialogCreateSonglist extends React.Component {

  static defaultProps = {
    songlist: null
  }

  constructor(props) {
    super(props)
    let sl = this.props.songlist
    if(sl) {
      this.state = {
        error: null
        , is_public: sl.info.is_public ? 1 : 0
        , description: sl.info.description || ''
        , title: sl.info.title || ''

        , showDeleteConfirm: false
        , deleteStatus: null
      }
    } else {
      this.state = {
        error: null
        , title: ''
        , description: ''
        , is_public: 1
      }
    }
  }

  /**
   * @todo
   *  1. error handing
   *  2. styles
   *  3. refresh creation list
   */
  handleSubmit(e) {
    e.preventDefault()

    let attrs = toObject(['title', 'description', 'is_public'].map((key) => {
      return [key, this.state[key]]
    }))

    if(this.validate(attrs)) {
      if(this.props.songlist) {
        return this.props.songlist.save(attrs).then((sl) => {
          this.props.onClose()
        })
      } else {
        return Songlist.create(douradio, attrs).then((sl) => {
          this.props.onClose()
          window.app.navigate('songlist/' + sl.id, {trigger: true})
        }, (err) => {
          console.error(err)
        })
      }
    } else {
      this.setState({
        error: true
      })
    }
  }

  handleCancel(e) {
    e.preventDefault()
    this.props.onClose()
  }

  handleDelete(e) {
    e.preventDefault()
    this.setState({showDeleteConfirm: true})
  }

  /**
   * @todo
   * @return {Object|null}
   */
  validate(attrs) {
    if(!attrs.title) {
      return false
    }

    if(!(
      attrs.is_public == 0 || attrs.is_public == 1
    )) {
      return false
    }

    return true
  }

  onChange(name, e) {
    let value
    if(name === 'is_public') {
      value = e
    } else {
      value = e.target.value
    }
    this.setState({[name]: value})
  }

  deleteSonglist() {
    this.setState({
      showDeleteConfirm: false
      , deleteStatus: '删除中'
    })

    let always = () => {
      this.props.onClose()
      window.app.navigate('mine/creation', {trigger: true})
      return douradio.mineSonglists.refresh()
    }

    return this.props.songlist.delete().then(() => {
      return always()
    }, (error) => {
      return always()
    })
  }

  renderConfirmDialog() {
    let close = () => {
      this.setState({showDeleteConfirm: false})
    }

    return <DialogDeleteConfirm
      onYes={this.deleteSonglist.bind(this)}
      onNo={close}
    ></DialogDeleteConfirm>
  }

  render() {
    if(this.state.showDeleteConfirm) {
      return this.renderConfirmDialog()
    }

    let sl = this.props.songlist
    let ftr = <div className="controls">
      <div className="is-public" style={{
        display: 'inline-block'
        , float: 'left'
        , marginTop: 22
      }}>
        <RadioGroup
          className="is-public"
          name="is_public"
          selectedValue={this.state.is_public}
          onChange={this.onChange.bind(this, 'is_public')}
          style={{
          }}
        >{(Radio)=> {
          return <div>
            <Radio value={1}></Radio>
            所有人可见
            &nbsp; &nbsp;
            <Radio value={0}></Radio>
            仅自己可见
          </div>
        }}</RadioGroup>
      </div>

      <button className="button button-submit fr" type="submit" onClick={this.handleSubmit.bind(this)}>
        {sl ? '更新' : '创建'}</button>
      <button onClick={this.handleCancel.bind(this)} className="button fr" type="cancel">取消</button>

      {sl ?
        (this.state.deleteStatus ?
          <a className="link link-delete fr" href="#" onClick={preventDefault}>{this.state.deleteStatus}</a>
        : <a className="link link-delete fr" href="#" onClick={this.handleDelete.bind(this)}>删除歌单</a>)
      : null}
    </div>

    return <Dialog
      baseZIndex={20000}
      title={'创建歌单'}
      showMask={true}
      width={660}
      height={443}
      onClose={this.props.onClose}
      footer={ftr}
      className="dialog-create-songlist"
    >
      <form className="pure-form pure-form-stacked form-popup" onSubmit={this.handleSubmit.bind(this)}>
        <fieldset className="pure-group field-group">
          <input
            ref="title"
            type="text"
            name="title"
            placeholder="歌单名"
            maxLength={40}
            onChange={this.onChange.bind(this, 'title')}
            value={this.state.title}
          />
          <TextArea
            ref="description"
            name="description"
            placeholder="介绍一下你的歌单吧"
            cols={30}
            rows={2}
            onChange={this.onChange.bind(this, 'description')}
            defaultValue={this.state.description}
            style={{
              maxHeight: 300
            }}
          ></TextArea>
        </fieldset>
      </form>
    </Dialog>
  }
}
