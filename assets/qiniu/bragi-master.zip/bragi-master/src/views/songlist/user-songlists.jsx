import "./user-songlists.scss"
import "../mine/songlist.scss"

import React from "react"
// import request from 'utils/request'
import Cover from "components/cover"
import Link from "ui/link"

export default class SongList extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      songlists: []
    }
  }

  componentWillMount() {
    this.request = this.props.songlist.getCreatorSonglists().then((songlists) => {
      if(!this.request) {
        return
      }

      this.setState({
        songlists: songlists
      })
    })
  }

  componentWillUnmount() {
    this.request = null
  }

  render() {
    return <ul className="pl-list user-songlists">{this.state.songlists.map((sl) => {
      return <li key={sl.id}>
        <Cover size={72} src={sl.cover}></Cover>
        <div className="inner">
          <Link href={'songlist/' + sl.id} className="title">{sl.title}</Link>
          <p>{sl.songs_count}首歌 {sl.collected_count}收藏</p>
          <div className="ft">
            <p>{sl.updated_time}更新</p>
          </div>
        </div>
      </li>
    })}</ul>
  }

}
