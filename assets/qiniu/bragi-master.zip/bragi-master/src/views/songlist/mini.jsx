import "./mini.scss"
import "./songlist-page.scss"

import React from "react"
import {MiniSonglistSong} from "./song"
import Dropdown from "ui/dropdown"
import douradio from "douradio"

class SongList extends React.Component {
  componentWillMount() {
    this.props.songlist.on("remove reset sort", () => {
      this.forceUpdate()
    }, this)

    this.props.songlist.on("add", (model) => {
      model.add = true
      this.forceUpdate()
    }, this)

    douradio.on("switch_song", (model) => {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    this.props.songlist.off(null, null, this)
    douradio.off(null, null, this)
  }

  render() {
    let songlist = this.props.songlist
    , baseIndex = 0

    if(songlist.length > 50) {
      let [index, ] = songlist.findCurrentSong()
      , begin = index - 50
      if(begin < 0) {
        begin = 0
      }
      songlist = songlist.slice(begin, begin + 100)
      baseIndex = begin
    }

    return <ul className="songlist">{songlist.map((song, index) => {
      return <MiniSonglistSong
        key={'song-' + song.id}
        song={song}
        index={baseIndex + index - 1}
      ></MiniSonglistSong>
    })}</ul>
  }
}

export default class MiniSonglist extends React.Component {

  shouldComponentUpdate(nextProps, nextState) {
    return this.props.songlist !== nextProps.songlist
  }

  render() {
    // change this if mini-songlist has no precise width
    // let elementWidth = 360
    // {x: the middle of an element, y: the bottom of an element}
    return <Dropdown {...this.props} height={400} className="mini-songlist">
      <SongList songlist={this.props.songlist}></SongList>
    </Dropdown>
  }

}
