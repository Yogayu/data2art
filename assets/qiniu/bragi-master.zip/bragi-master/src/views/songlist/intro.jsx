import React from "react"
import douradio from "douradio"
// import Loading from 'ui/loading'
import Cover from "components/cover"
import Link from "ui/link"
import IconPause from 'icons/icon-pause'
import IconStar from 'icons/icon-star'
import IconShare from 'icons/icon-share'

import IconPlay from "icons/icon-play"
import DailySonglistCover from "./daily-songlist-cover"
import defaults from "lodash/defaults"

import PlaceHolder, {PlaceHolderAlbumCover} from 'components/place-holder'

class ExpendableText extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      expend: false
    }
  }

  expendText(event) {
    event.preventDefault()
    this.setState({
      expend: true
    })
  }

  render() {
    // 90 + ... 更多
    let isExpend = !!this.state.expend
    let value = this.props.value

    if(!isExpend && value.length > this.props.breakLength) {
      value = <span>
        {value.slice(0, this.props.breakLength)}
        …
        <a
           href="#"
           className="more"
           onClick={this.expendText.bind(this)}>更多</a>
      </span>
    }

    return <p className={this.props.className} style={{
    }}>
      {value}
      {this.props.children}
    </p>
  }

}


export default class Intro extends React.Component {

  constructor() {
    super()
    this.state = {}
  }

  componentDidMount() {
    douradio.on('play pause resume', () => {
      this.forceUpdate()
    }, this)

    this.props.songlist.on('change', () => {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
    this.props.songlist.off(null, null, this)
  }

  onChange(key, value) { console.log('Change:', key, '->', value) }

  togglePlay(event) {
    event.preventDefault()
    ga('send', 'event', 'songlist',
      'PlayAll', null, this.props.songlist.id)

    if(this.props.songlist.isCurrent()) {
      return douradio.togglePause()
    } else {
      return douradio.switchSonglist(this.props.songlist, true)
    }
  }

  onShare(e) {
    e.preventDefault()
    e.stopPropagation()
    window.app.share(null, this.props.songlist)
  }

  onMobile() {}

  onClose(e) {
    e.preventDefault()
    this.props.onClose()
  }

  toggleCollect() {
    ga('send', 'event', 'songlist', 'Fav', null, this.props.songlist.id)

    this.props.songlist.toggleCollect().then(() => {
      this.forceUpdate()
    })
  }

  onEditSonglist(e) {
    e.preventDefault()
    require(['./dialog-create'], (Dialog) => {
      window.app.root.displayOverlay(
        <Dialog
          onClose={window.app.root.hideOverlay.bind(null, 'dialog')}
          songlist={this.props.songlist}
        ></Dialog>
      , 'dialog')
    })
  }

  renderPlaceHolder() {
    return <div className="container">
      <PlaceHolderAlbumCover
        size={114}></PlaceHolderAlbumCover>
      <div style={{
        width: 180
        , marginLeft: 20
        , display: 'inline-block'
        , verticalAlign: 'top'
      }}>
        <PlaceHolder width={180} height={20}></PlaceHolder>
        <PlaceHolder width={108} height={14}></PlaceHolder>
      </div>
    </div>
  }

  render() {
    if(!this.props.ready) {
      return this.renderPlaceHolder()
    }

    let songlist = this.props.songlist
      , info = songlist.info
      // , isCollected = info.is_collected
      , isUserDaily = songlist.id === 'user_daily'
      , isEditable = songlist.isEditable()
      , isLogin = douradio.isLogin()

    defaults(info, {
      created_time: ''
    })

    let playBtn = <a
      className="button-play"
      onClick={this.togglePlay.bind(this)}>
        {songlist.isCurrent() && douradio.isPlaying() ?
          <IconPause color="#fff" size={13} center={true} style={{
            marginLeft: -5
            , marginTop: -6
          }}></IconPause> : <IconPlay color="#fff" size={13} center={true} style={{
            marginLeft: -5
            , marginTop: -6
          }} />
        }
      </a>

    // hide this
    // <button className="button button-secondary" onClick={this.onMobile.bind(this)}><i className="icon-mobile"></i></button>
    let cover
    if(isUserDaily) {
      let firstSong = songlist.at(0)
      , coverSrc = firstSong && firstSong.get('picture')
      cover = <DailySonglistCover
        src={coverSrc}
      >{playBtn}</DailySonglistCover>
    } else {
      cover = <Cover
       size="114"
       src={info.cover}
       className="programme-cover">{playBtn}</Cover>
    }

    return <div className="programme-page container" onScroll={this.onScroll}>
      <div className="header">
        {cover}
        <div className="content">
          <h1>{info.title}</h1>

          <p className="meta">
            {!isUserDaily ? <span>
              <span className="avatar" style={{
                backgroundImage: 'url(' + info.creator.picture + ')'
                , backgroundSize: 'cover'
              }}></span>
              <Link
                target="_blank"
                href={info.creator.url}>{info.creator.name}</Link>
              &nbsp;创建&nbsp;
              {info.songs_count}首歌曲&nbsp;
              {info.created_time.slice(0, 10)}
            </span> : <span>更新于 {info.updated_time.slice(0, 10)} &nbsp; </span>}

            {isEditable ? <a
              className="link link-edit"
              style={{marginLeft: 20}}
              href="#" onClick={this.onEditSonglist.bind(this)}>
              编辑歌单
            </a> : null}
          </p>

          <ExpendableText
            className="intro"
            breakLength={44}
            value={info.description}
          >{isEditable ? <a href="#" onClick={this.onEditSonglist.bind(this)}>
            <i className="icon-edit"></i>
            {info.description ? '编辑' : '添加'}简介
          </a> : null}</ExpendableText>

          <div className="buttons">
            {!isUserDaily ? <span>
              {isLogin ? <button className="button button-secondary"
                onClick={this.toggleCollect.bind(this)}>
                <IconStar size={12} color={songlist.isCollect() ? '#44A156' : '#C6C6C6'}></IconStar>
                <span
                  style={{
                    display: 'inline-block'
                    , height: 12
                    , lineHeight: '12px'
                  }}
                >{info.collected_count}</span>
              </button> : null}

              <button
                 className="button button-secondary"
                 onClick={this.onShare.bind(this)}>
                <IconShare size={16}></IconShare>
              </button>

            </span> : null}
          </div>

        </div>
      </div>
    </div>
  }
}
