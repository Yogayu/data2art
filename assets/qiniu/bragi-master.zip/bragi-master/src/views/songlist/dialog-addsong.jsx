import "./dialog-addsong.scss"

import Dialog from "components/dialog"
import React from "react"
import OriginSearchInput from "views/search/input"
import request from "utils/request"
import debounce from "lodash/debounce"
import Icon from "ui/icon"
import IconPlay from "icons/icon-play"
import {IconClose, } from "icons"
import Waypoint from 'react-waypoint'


class SearchInput extends OriginSearchInput {

  render() {
    return <div
      className="search-input-wrapper dialog-search-input"
      onClick={this.onClick.bind(this)}
    >
      <div className="inner">
        <input
          ref="search"
          type="text"
          className="search"
          placeholder={'搜索歌名/艺术家/专辑名来加歌'}
          value={this.value}
          onFocus={this.onFocus.bind(this)}
          onBlur={this.onBlur.bind(this)}
          onChange={this.onChange.bind(this)}
        />

        {this.props.value ? <a
          className="button-close"
          onClick={this.onClear.bind(this)}
          href="#search">
            <IconClose size={13} color="#FFFFFF"></IconClose>
          </a> : <a className={"fr"} href="#" onClick={this.props.onOpenRedheartList}>从我的红心列表选歌</a>}
        <Icon i="search"></Icon>
      </div>
    </div>
  }
}

class ResultSong extends React.Component {

  onAudition(e) {

    e.preventDefault()
  }

  onAdd(e) {
    e.preventDefault()
    let song = this.props.song
    this.props.songlist.addSong(song.id).then((success) => {
      this.forceUpdate()
    })
  }

  render() {
    let {song, songlist} = this.props
    , hasSong = songlist.hasSong(song.id)

    /* todo, make audition works again
    <a href="#" onClick={this.onAudition.bind(this)}>
      <IconPlay color={'#9B9B9B'} size={10}></IconPlay>
      30
    </a>
    */
    return <li className="search-result" key={song.id}>
      <div className="titles">
        <span className="song-title">{song.title}</span>
        <span className="artist"> - {song.artist_name}</span>
      </div>

      {song.playable ? <span className="fr">
        {hasSong ?
          <Icon i={'right'}></Icon> :
          <Icon
            i={'add'} size={24} style={{left: 2, position: 'relative'}}
            onClick={this.onAdd.bind(this)}></Icon>}
      </span> : null}
    </li>
  }
}

let SearchResults = ({songs, songlist}) => {
  if(!songs || songs.length === 0) {
    return <div></div>
  }
  return <ul className="popup-search-results">{songs.map((song) => {
    return <ResultSong
      songlist={songlist}
      song={song}
      key={song.id}></ResultSong>
  })}</ul>
}

import {SonglistSong, } from "views/songlist/song"
import HeartsPage from "views/mine/hearts"

class HLSonglistSong extends SonglistSong {

  render() {
    let song = this.props.song
    if(!song.isReady()) {
      return null
    }
    return <ResultSong
      songlist={this.props.songlist}
      song={{
        title: song.get('title')
        , id: song.id
        , artist_name: song.get('artist')
        , playable: song.isPlayable()
      }}
    ></ResultSong>
  }

}

class DialogHearts extends HeartsPage {

  render() {
    let hl = this.state.heartlist
    let isReady = hl.info

    if(!isReady) {
      return <div className="heart-songs">
        <p style={{textAlign: 'center'}}>加载中...</p>
      </div>
    }

    // let {total, begin, end} = this.getPaginationData(10)
    let songs = hl.slice(0, this.state.limit)

    return <div className="heart-songs" style={{
      height: 500
      , overflow: 'scroll'
    }}>
      <ul className="popup-search-results">{songs.map((song) => {
        return <HLSonglistSong songlist={this.props.songlist} song={song} key={song.id}></HLSonglistSong>
      })}</ul>
      <Waypoint onEnter={this.onLoadMore.bind(this)}></Waypoint>
      <p style={{textAlign: 'center'}}>更多载入中...</p>
    </div>
  }
}

export default class DialogSearch extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      query: ''
      , results: []
      , heartList: false
    }
  }

  onSearch = debounce((query) => {
    if(this.request) {
      this.request.abort()
    }

    this.request = request({
      url: 'query/song'
      , method: 'get'
      , data: {
        q: query
        , start: 0
        , limit: 10
      }}
    ).then(({items, total, type}) => {
      if(!this.request) {return}
      this.setState({
        results: items
      })
      this.request = null
    })
  }, 200)

  onChange(query) {
    this.setState({
      query: query
    })
    this.onSearch(query)
  }

  componentWillUnmount() {
    if(this.request) {
      this.request.abort()
      this.request = null
    }
  }

  toggleRedheartList() {
    this.setState({
      heartList: !this.state.heartList
    })
  }

  render() {
    let query = this.state.query

    return <Dialog
      title={'添加歌曲'}
      showMask={true}
      width={660}
      height={768}
      onClose={this.props.onClose}
      className="dialog-addsong"
      baseZIndex={20000}
    >
      <div className="dialog-search" ref="content">
        {this.state.heartList ?
          <div className="search-input-wrapper dialog-search-input">
            <div className="inner">
              我的红心列表选歌
              <a className="button-close"
                onClick={this.toggleRedheartList.bind(this)}
                href="#search">
                <IconClose size={13} color="#FFFFFF"></IconClose>
              </a>
            </div>
          </div> : <SearchInput
            onSearch={this.onChange.bind(this)}
            onOpenRedheartList={this.toggleRedheartList.bind(this)}
            value={query} />
        }
        {this.state.heartList ?
          <DialogHearts songlist={this.props.songlist}></DialogHearts>
          : <SearchResults
          songs={this.state.results.filter((song) => {
            return song.playable
          })}
          songlist={this.props.songlist}></SearchResults>}
      </div>
    </Dialog>
  }
}

// function AddSongDialog ({songlist, onClose}) {
//   return <Dialog
//     title={'添加歌曲'}
//     showMask={true}
//     width={660}
//     height={763}
//     onClose={onClose}
//     className="dialog-addsong"
//     baseZIndex={20000}
//   >
//     <DialogSearch songlist={songlist}></DialogSearch>
//   </Dialog>
// }
