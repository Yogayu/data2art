module.exports = {
  "start": 0,
  "total": 6,
  "count": 20,
  "comments": [
    {
      "text": "楼主你还在用windows xp吗？",
      "vote_count": 0,
      "author": {
        "name": "听临",
        "is_suicide": false,
        "avatar": "http://img3.douban.com/icon/u2419751-49.jpg",
        "uid": "hearlisten",
        "alt": "http://www.douban.com/people/2419751/",
        "type": "user",
        "id": "2419751",
        "large_avatar": "http://img3.douban.com/icon/up2419751-49.jpg"
      },
      "id": "1016787945",
      "time": "2015-11-06 10:45:15"
    },
    {
      "author": {
        "name": "涛小涛",
        "is_suicide": false,
        "avatar": "http://img3.douban.com/icon/user_normal.jpg",
        "uid": "75772379",
        "alt": "http://www.douban.com/people/75772379/",
        "type": "user",
        "id": "75772379",
        "large_avatar": "http://img3.douban.com/icon/user_large.jpg"
      },
      "text": "对啊，不过一般只有发布Windows程序的时候才用Windows XP。",
      "quote_comment": {},
      "vote_count": 0,
      "time": "2015-11-06 11:05:58",
      "id": "1016800242"
    },
    {
      "text": "你这是把flash抠出来了嘛？",
      "vote_count": 0,
      "author": {
        "name": "听临",
        "is_suicide": false,
        "avatar": "http://img3.douban.com/icon/u2419751-49.jpg",
        "uid": "hearlisten",
        "alt": "http://www.douban.com/people/2419751/",
        "type": "user",
        "id": "2419751",
        "large_avatar": "http://img3.douban.com/icon/up2419751-49.jpg"
      },
      "id": "1016801131",
      "time": "2015-11-06 11:07:23",
      "sub_comments": [{
        "author": {
          "name": "涛小涛",
          "is_suicide": false,
          "avatar": "http://img3.douban.com/icon/user_normal.jpg",
          "uid": "75772379",
          "alt": "http://www.douban.com/people/75772379/",
          "type": "user",
          "id": "75772379",
          "large_avatar": "http://img3.douban.com/icon/user_large.jpg"
        },
        "text": "额，我只是把播放器flash移到了页面左上角，然后把窗口尺寸缩放成和播放器一样的大小。。。",
        "vote_count": 0,
        "time": "2015-11-06 11:11:56",
        "id": "1016803927"
      }, {
        "text": "学习了，不过网页有什么缺点呢，一定要做桌面版？",
        "vote_count": 0,
        "author": {
          "name": "听临",
          "is_suicide": false,
          "avatar": "http://img3.douban.com/icon/u2419751-49.jpg",
          "uid": "hearlisten",
          "alt": "http://www.douban.com/people/2419751/",
          "type": "user",
          "id": "2419751",
          "large_avatar": "http://img3.douban.com/icon/up2419751-49.jpg"
        },
        "id": "1016806183",
        "time": "2015-11-06 11:15:40"
      }, {
        "author": {
          "name": "涛小涛",
          "is_suicide": false,
          "avatar": "http://img3.douban.com/icon/user_normal.jpg",
          "uid": "75772379",
          "alt": "http://www.douban.com/people/75772379/",
          "type": "user",
          "id": "75772379",
          "large_avatar": "http://img3.douban.com/icon/user_large.jpg"
        },
        "text": "我觉得听歌还要专门开一个浏览器好烦啊，而且网页上还会看到广告。",
        "vote_count": 0,
        "time": "2015-11-06 11:21:20",
        "id": "1016809659"
      }]
    }
  ]
}
