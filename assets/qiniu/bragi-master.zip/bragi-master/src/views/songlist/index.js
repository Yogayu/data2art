import "./songlist-detail.scss"
import "./songlist-page.scss"

import React from "react"
import douradio from "douradio"
import SectionSwitcher from "ui/section-switcher"
import Intro from "./intro"
import {SonglistSong, SongPlaceHolder} from "./song"
import isEmpty from "lodash/isEmpty"
import map from "lodash/map"
import zip from "lodash/zip"
import range from "lodash/range"
import sortedIndex from "lodash/sortedIndex"
import SonglistComments from "./comments"
import UserSonglists from "./user-songlists"
import Icon from "ui/icon"
// import PlaceHolder from 'components/place-holder'

export class SongList extends React.Component {

  defaultProps = {
    begin: 0
    , end: null
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  componentWillMount() {
    this.props.songlist.on("remove reset sort", () => {
      this.forceUpdate()
    }, this)

    this.props.songlist.on("add", (model) => {
      model.add = true
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    this.props.songlist.off(null, null, this)
    douradio.off(null, null, this)
  }

  componentDidMount() {
    if(this.props.songlist.isEditable()) {
      this.updatePosMap()
    }
  }

  componentDidUpdate() {
    if(this.props.songlist.isEditable()) {
      this.updatePosMap()
    }
  }

  /**
   * [target1](pos1)[target2](pos2)
   * @return {[type]} [description]
   */
  updatePosMap() {
    if(!this.refs.songlist) {
      return
    }

    let [posTop, posBottom] = zip.apply(null, map(this.refs.songlist.children, (node, i) => {
      return [node.offsetTop, node.offsetTop + node.offsetHeight]
    }))

    this._posMap = {
      top: posTop
      , bottom: posBottom
    }
  }

  processDragData(index, offset) {
    if(!this._posMap || !this._posMap.top) {
      return
    }
    let {top: posTop, bottom: posBottom} = this._posMap

    if(offset > 0) {
      let originTop = posTop[index]
      , dragPosition = originTop + offset
      let i = sortedIndex(posBottom, dragPosition)
      // console.log(dragPosition, posBottom)
      return [i, posBottom[i]]
    } else {
      let originTop = posTop[index]
      , dragPosition = originTop + offset
      let i = sortedIndex(posTop, dragPosition)
      return [i, posTop[i]]
    }

  }

  handleDrag(index, offsetTop) {
    let [i, top] = this.processDragData(index, offsetTop)
    if(this.state.dragIndex === i) {
      return
    }

    // console.log('drag', [i, top])

    this.setState({
      dragIndex: i
      , lineStyle: (i !== index) ? {top: top} : null
    })

  }

  handleDragStop(fromIndex, offsetTop) {
    let [toIndex, ] = this.processDragData(fromIndex, offsetTop)
    if(toIndex === null) {
      return
    }

    console.log("<DragEnd from=" + fromIndex + " toIndex=" + toIndex + ">")

    this.props.songlist.moveFrom(fromIndex, toIndex)
    this.setState({dragIndex: null, lineStyle: null})
  }

  onAddSong(e) {
    e.preventDefault()
    e.stopPropagation()
    return this.props.onAddSong()
  }

  renderEmpty(isEditable) {
    return <p className="tip tip-no-song">
      还没有歌曲
      {isEditable ? <span>
        ，<a onClick={this.onAddSong.bind(this)} href="#">添加歌曲</a>
      </span> : null}
    </p>
  }

  renderPlaceHolder() {
    return range(0, 20).map((i) => {
      return <SongPlaceHolder key={'place-holder-' + i}></SongPlaceHolder>
    })
  }

  render() {
    let sl = this.props.songlist
    , songs = this.props.songlist.slice(
      this.props.begin,
      this.props.end
    )
    , isReady = !isEmpty(sl.info)
    , isEditable = sl.isEditable()

    return <div className="container" style={{
      width: "100%"
      , borderCollapse: "collapse"
    }}>
      {isReady && songs.length === 0 ? this.renderEmpty(isEditable) : null}
      <ul ref="songlist" className="songlist">{isReady ? songs.map((song, index) => {
        // song.index = index
        return <SonglistSong
          index={index}
          key={song.id}
          song={song}
          editable={isEditable}
          onDrag={isEditable ? this.handleDrag.bind(this, index) : null}
          onDragStop={isEditable ? this.handleDragStop.bind(this, index) : null}
        ></SonglistSong>
      }) : this.renderPlaceHolder()}</ul>
      {isEditable && this.state.lineStyle ?
        <div style={this.state.lineStyle} className="sortable-line"></div> : null}
    </div>
  }
}

export default class SonglistDetail extends React.Component {

  static defaultProps = {
    songlist: null
    , onError: () => {}
  }

  constructor(props) {
    super(props)
    this.state = {
      ready: false // data ready
    }
  }

  // fetch data
  componentDidMount() {
    this.request = this.props.songlist.fetch().then(() => {
      this.setState({ready: true})
    }, () => {
      // fetch data error
      console.error('Songlist Not Exist?')
      this.props.onError()
    })
  }

  componentWillUnmount() {
    if(this.request) {
      // this.request.abort && this.request.abort()
      this.request = null
    }
  }

  handleAddSong() {
    require(['./dialog-addsong'], (AddSongPopup) => {
      window.app.root.displayOverlay(
        <AddSongPopup
          onClose={window.app.root.hideOverlay.bind(null, 'dialog')}
          songlist={this.props.songlist}
        ></AddSongPopup>
      , 'dialog')
    })
  }

  onClose(e) {
    if(e) {
      e.preventDefault()
    }
    return this.props.onClose()
  }

  renderContent() {
    let sl = this.props.songlist
    , info = sl.info

    if(
      isEmpty(info)
    ) {
      return <div>
        <SongList
          songlist={this.props.songlist}
        ></SongList>
      </div>
    }

    if(sl.id === 'user_daily' || sl.id ===  'user_share') {
      // render without section switcher
      return <div className="user-daily-wrapper" style={{
        background: '#FFFFFF'
        , borderTop: '1px solid #EAEAEA'
        , marginTop: 25
      }}>
        <SongList className="user-daily" songlist={this.props.songlist}></SongList>
      </div>
    } else {
      let isEditable = this.props.songlist.isEditable()
      , songCount = sl.length
      , commentCount = info.comments_count
      , username = info.creator.name
      , userSonglistCount = info.creator.songlists_count - 1

      if(userSonglistCount < 0) {
        userSonglistCount = 0
      }

      return <SectionSwitcher
        defaultIndex={0}
        lineStyle={null}
        className="section-switcher section-switcher-songlist"
        onSwitch={function (section) {
          ga('send', 'event', 'songlist', 'SwitchTab', section.name)
        }}
        sections={[{
          title: "歌曲列表(" + songCount + ")"
          , name: 'songlist'
          , component: SongList
          , props: {
            songlist: this.props.songlist
            , onAddSong: this.handleAddSong.bind(this)
          }
        }, {
          title: `评论(${commentCount || 0})`
          , name: 'comments'
          , component: SonglistComments
          , props: {songlist: this.props.songlist}
        }, (userSonglistCount > 0) ? {
          title: `${username}的其他歌单(${userSonglistCount})`
          , name: 'user-songlists'
          , component: UserSonglists
          , props: {
            songlist: this.props.songlist
          }
        } : {}]}>
        {isEditable ?
          <a className="fr" href="#" onClick={this.handleAddSong.bind(this)}>
            <Icon size={20} i={'add'} style={{top: -1}}></Icon>
            添加歌曲
          </a> : null}
        </SectionSwitcher>
    }
  }

  render() {
    return <div style={{
      padding: '40px 30px 35px 50px'
    }}>
      <Intro
        {...this.props}
        ready={this.state.ready}
      ></Intro>
      {this.renderContent()}
    </div>
  }

}
