// # Pager = require('react-pager')
import "./comments.scss"
import React from "react"
import Cover from "components/cover"
import request from "utils/request"
import douradio from "douradio"
import cls from "classnames"

class Comment extends React.Component {

  static defaultProps = {
    iconSize: 42
  }

  constructor(props) {
    super(props)
    this.state = {
      reply: false
    }
  }

  onReply(e) {
    e && e.preventDefault()
    if(this.props.onReply) {
      return this.props.onReply()
    } else {
      this.setState({
        reply: true
      })
    }
  }

  onSubmit(value) {
    return this.props.onSubmit(value)
  }

  render() {
    let {author, time, text, sub_comments} = this.props.comment
    , me = douradio.options.userinfo
    , isLogin = douradio.isLogin()

    return <li className="comment">
      <Cover src={author.avatar} size={this.props.iconSize} rounded={true}></Cover>
      <div className="hd">
        {author.name} <span className="time">{time}</span>
      </div>
      <div className="bd">{text}</div>
      {isLogin ?
        <a className="link-reply" href="#" onClick={this.onReply.bind(this)}>回复</a>
        : null}
      {sub_comments && sub_comments.length > 0 ? <ul>{sub_comments.map((comment) => {
        return <Comment
          onReply={this.onReply.bind(this)}
          key={comment.id}
          comment={comment}
          iconSize={28}
        ></Comment>
      })}</ul> : null}
      {this.state.reply && isLogin ? <div className="comment">
        <Cover src={me.icon} size={28} rounded={true}></Cover>
        <CommentInput
          text={'回复'}
          placeholder={'写下你的回复吧...'}
          onSubmit={this.onSubmit.bind(this)}
          className="reply"
        ></CommentInput>
      </div> : null}
    </li>
  }
}


class CommentInput extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      focus: false
      , value: ""
    }
  }

  onSubmit(e) {
    e.preventDefault()
    let value = this.refs.input.value
    this.props.onSubmit(value)
    this.setState({
      focus: false
      , value: ""
    })
  }

  toggleFocus(value) {
    this.setState({
      focus: value
    })
  }

  onChange(e) {
    this.setState({
      value: this.refs.input.value
    })
  }

  render() {
    let hasValue = this.state.value.length > 0 ? 'active' : null

    return <form
      className={cls('comment-form', this.props.className)}
      action="comment"
      onSubmit={this.onSubmit.bind(this)}>
      <textarea
       placeholder={this.props.placeholder || '写下你的评语吧...'}
       value={this.state.value}
       onBlur={this.toggleFocus.bind(this, false)}
       onFocus={this.toggleFocus.bind(this, true)}
       onChange={this.onChange.bind(this)}
       maxLength="280"
       name="text"
       className="comment-text"
       rows={(this.state.focus || this.state.value) ? 4 : 1}
       cols="70"
       autoComplete="off"
       ref="input"
      ></textarea>
      <input
        onClick={hasValue ? this.onSubmit.bind(this) : null}
        className={cls(
          "button",
          "button-green",
          "button-submit",
          hasValue ? 'active' : null
        )}
        type="submit"
        value={this.props.text} />
    </form>
  }
}


export default class SonglistComments extends React.Component {
  static defaultProps = {}

  constructor(props) {
    super(props)
    this.state = {
      comments: []
    }
  }

  componentWillMount() {
    this.request = request({
      url: 'songlist/' + this.props.songlist.id + '/comments'
    }).then((response) => {
      this.setState(response)
    })
  }

  onSubmit(comment=null, value) {
    if(this.request) {
      console.error('prevent comment twice!')
    }

    ga('send', 'event', 'songlist', comment ? 'CommentReply' : 'CommentAdd')
    // console.debug('Comment to ', comment, ' Content:', value)

    this.request = request({
      url: 'songlist/' + this.props.songlist.id + '/comments'
      , method: 'post'
      , data: {
        content: value
        , reply_to: comment && comment.id
        // , sync_mb: false // 是否转发到豆瓣广播
      }
    }).then((response) => {
      if(comment) {
        comment.sub_comments.push(response)
      } else {
        this.state.comments.push(response)
      }
      this.request = null
      this.forceUpdate()
    })
  }


  render() {
    let comments = this.state.comments || []
    , me = douradio.options.userinfo
    , isLogin = douradio.isLogin()

    return <div className="songlist-comments">
      {isLogin ? <div className="comment">
        <Cover src={me.icon} size={42} rounded={true}></Cover>
        <CommentInput
          text={"发表评论"}
          onSubmit={this.onSubmit.bind(this, null)}
        ></CommentInput>
      </div> : null}

      <ul>{comments.map((comment, index) => {
        if(!comment.sub_comments) {
          comment.sub_comments = []
        }
        return <Comment
          onSubmit={this.onSubmit.bind(this, comment)}
          key={comment.id}
          comment={comment}
        ></Comment>
      })}</ul>
    </div>
  }

}
