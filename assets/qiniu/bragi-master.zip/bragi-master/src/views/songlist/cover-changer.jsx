//

import Dropzone from "react-dropzone"
import React from "react"

export default class DropzoneDemo extends React.Component {

  onDrop(files) {
    console.log('Received Files', files)
  }

  render() {
    return <div className="dropzone">
      <Dropzone
        onDrop={this.onDrop.bind(this)}
        multiple={false}
      ></Dropzone>
    </div>
  }

}
