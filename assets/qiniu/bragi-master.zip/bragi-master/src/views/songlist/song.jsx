// types of different views of song
import "./song.scss"

import React from "react"
import Cover from "components/cover"
import {ContextMenu, ContextMenuItem} from "components/context-menu"
import {SonglistChooser} from "views/actions/add2songlist"

import Link from "ui/link"
import Icon from "ui/icon"
import IconHeart from "icons/icon-heart"
import IconTrash from 'icons/icon-trash'

import IconPlayingWave from "icons/icon-playing-wave"

import shallowCompare from "react/lib/shallowCompare"
import classnames from "classnames"
import Draggable from "react-draggable"

import douradio from "douradio"
import lang from "i18n"
import ArtistLabels from "views/common/artists"
import {getScrollY} from "utils/domutils"

import PlaceHolder from 'components/place-holder'


export class CommentEditable extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      value: this.props.defaultValue
      , edit: false
    }
  }

  toggleEditable(e) {
    e.preventDefault()
    e.stopPropagation()

    this.setState({
      edit: !this.state.edit
    })
  }

  handleCancel(e) {
    e.preventDefault()
    this.setState({
      edit: false
      , value: this.props.defaultValue
    })
  }

  handleChange(e) {
    e.preventDefault()
    this.setState({
      value: e.target.value
    })
  }

  handleSave(e) {
    e.preventDefault()
    this.setState({
      edit: false
    })
    let {song, } = this.props
    song.collection.editComment(song.id, this.state.value).then(() => {
      this.setState({
        value: song.get('item_info').comment
      })
    })
  }

  renderForm() {
    let maxLength = 250

    return <div className="pure-form">
      <textarea
        name="comments"
        cols="30"
        rows="10"
        onChange={this.handleChange.bind(this)}
        value={this.state.value}
        style={{
          width: '100%'
          , color: '#4A4A4A'
        }}
      ></textarea>
      <div className="ft">
        <button onClick={this.handleCancel.bind(this)} className="button fr" type="cancel">取消</button>

        <button
          className="button button-submit"
          type="submit"
          onClick={this.handleSave.bind(this)}>保存</button>

        <span className="tip">还可以输入 {maxLength - this.state.value.length} 字</span>
      </div>
    </div>
  }

  renderText() {
    return <span>
      {this.state.value ? this.state.value : '给这首歌添加评语'}
    </span>
  }

  render() {
    if(this.state.edit) {
      return <div className="comments comments-editable">
        {this.renderForm()}
      </div>
    } else {
      return <div
        style={{cursor: 'pointer'}}
        className="comments" onClick={this.toggleEditable.bind(this)}>
        {this.renderText()}
      </div>
    }
  }

}

export function SongPlaceHolder () {
  return <li className="songlist-song">
    <div className="top">
      <PlaceHolder
        width={36}
        height={36}
        ></PlaceHolder>

      <PlaceHolder
        width={120}
        height={14}
        style={{marginLeft: 24, verticalAlign: 'top'}}
        ></PlaceHolder>
    </div>
  </li>
}

export class SonglistSong extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      drag: false
    }
  }

  log(action, label, value) {
    let song = this.props.song
    return ga('send', 'event',
      song.collection.id === 'redheart' ? 'mine' : 'songlist',
      action, label || null, value || song.id
    )
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  componentWillUnmount() {
    this.props.song.off(null, null, this)
  }

  componentDidMount() {
    let {song} = this.props

    // check song is ready
    if(!song.isReady()) {
      song.fetch({force: false})
    }

    this.props.song.on("change:isPlaying change:title", function () {
      this.forceUpdate()
    }, this)
  }

  preventDefault(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  displayContextMenu(e) {
    e.preventDefault()
    e.stopPropagation()

    let {song, } = this.props

    window.app.displayContextMenu(
      <ContextMenu
       song={song}
       x={e.clientX}
       y={e.clientY}
      >
        <ContextMenuItem
         onClick={this.displayShareMenu.bind(this)}
         title={lang('MENU_SHARE_SONG')}></ContextMenuItem>

        <ContextMenuItem
          onClick={window.app.push2Device.bind(window.app, song)}
          title={lang('MENU_SENT_TO_PHONE')}></ContextMenuItem>

        <ContextMenuItem
          onClick={this.onPlaySimilarChannel.bind(this)}
          title={"启动单曲兆赫"}></ContextMenuItem>
      </ContextMenu>
    )
  }

  onPlaySimilarChannel(e) {
    this.log('SimilarSong')
    e.preventDefault()
    return douradio.switchChannel(
      this.props.song.relatedChannelId()
    )
  }

  displayShareMenu(e) {
    e.preventDefault()
    window.app.share(this.props.song)
  }

  displayAddSongToList(e) {
    e.preventDefault()
    e.stopPropagation()
    return window.app.displayContextMenu(
      <SonglistChooser
        song={this.props.song}
        x={e.pageX}
        y={e.pageY - getScrollY()}
      ></SonglistChooser>)
  }

  handleDelete(e) {
    let song = this.props.song
    song.collection.removeSong(song.id)
  }

  // componentWillUnmount() {}

  toggleLike(e) {
    e.preventDefault()
    e.stopPropagation()

    this.props.song.toggleLike(douradio.apiClient.request).then(() => {
      this.forceUpdate()
    })
  }

  toggleBan(e) {
    e.preventDefault()
    e.stopPropagation()

    return this.props.song.toggleBan(douradio.apiClient.request).then(() => {
      this.forceUpdate()
    })
  }

  switchSong(e) {
    if(this.props.song.isBan()) {
      douradio.trigger('error', '该歌曲不可播放，请先取消垃圾桶')
      return
    }

    if(!this.props.song.isPlayable()) {
      return
    }

    this.log('PlayOnDemand')

    // song.isCurrent()
    if(douradio.currentSong === this.props.song) {
      return
    }

    douradio.switchSonglist(
      this.props.song.collection, this.props.song.id
    )
  }

  renderArtist() {
    return <ArtistLabels
      onClick={() => this.log('ArtistTitleSel')}
      song={this.props.song}></ArtistLabels>
  }

  renderAlbum() {
    let song = this.props.song

    return <Link className="link-album" href={song.albumLink()} target="_blank">
      {song.get('albumtitle')}
    </Link>
  }

  // drag related
  handleDrag(e, ui) {
    // let node = ReactDOM.findDOMNode(this)
    // console.log(ui)
    this.props.onDrag(ui.y)
  }

  handleStart(e, ui) {
    this.setState({
      drag: true
    })
  }

  handleStop(e, ui) {
    this.setState({drag: false})
    this.props.onDragStop(ui.y)
  }

  renderTasteButton (song) {
    // <a
    //   className={song.isLike() ? "like" : ""}
    //   onClick={this.toggleLike.bind(this)}
    //   href="#"
    //   title={song.isLike() ? '取消红心' : '红心'}
    //   >
    //   <IconHeart liked={song.isLike()} size={12} />
    // </a>
    let isInRedheartSonglist = song.collection.id === 'redheart'
    , isLike = song.isLike()

    // if(isInRedheartSonglist) { return }

    if(song.isBan()) {
      return <a
        className="like"
        href="#"
        title="移出垃圾桶"
      >
        <IconTrash
          color={'#acacac'}
          onClick={this.toggleBan.bind(this)}
          size={12}></IconTrash>
      </a>
    }

    return <a
      className={isLike ? 'like' : null}
      href="#"
      onClick={this.toggleLike.bind(this)}
      title={isLike ? '取消红心' : '红心'}
    >
      <IconHeart liked={isLike} size={12} />
    </a>
  }

  render() {
    let {song} = this.props

    if(!song.isReady()) {
      return <SongPlaceHolder></SongPlaceHolder>
    }

    let itemInfo = song.get("item_info")
      , comment = itemInfo ? itemInfo.comment : ""
      , isCurrent = !!song.get('isPlaying')
      , isAvailable = song.get('status') === 0
      , isLogin = douradio.isLogin()

    let top = <div className="top" onClick={this.switchSong.bind(this)}>
      {this.props.editable ? <span
        className="handle"
        onClick={this.preventDefault}
      >
        <Icon i="more"></Icon>
      </span> : null}

      <span className="index">{isCurrent ?
        <IconPlayingWave size={12}></IconPlayingWave> : song.formatedIndex(this.props.index)
      }</span>

      <Cover
        src={song.get("picture")}
        size="36"
        className="cover">
      </Cover>

      <div className="titles">
        <h3>
          <Link onClick={() => {
            this.log('SongTitleSel')
          }} tag={'span'} href={'/song/' + song.objectId()}>{song.get('title')}</Link>
          {!isAvailable ? <span className="noplable">未上架</span> : null}
        </h3>
        <p>
          {this.renderArtist()}
          <Icon i={'point'} size={9}></Icon>
          {this.renderAlbum()}
          <Icon i={'point'} size={9}></Icon>
          {song.get("public_time")}
        </p>
      </div>

      <div className="actions" onClick={this.preventDefault.bind(this)}>
        {this.renderTasteButton(song)}

        {isAvailable && isLogin ? <a onClick={this.displayAddSongToList.bind(this)} href="#">
          <Icon i="add" />
        </a> : null}

        {isAvailable ? <a onClick={this.displayContextMenu.bind(this)} href="#">
          <Icon i="more" />
        </a> : <a href="#" onClick={this.onPlaySimilarChannel.bind(this)} title="收听相似歌曲">
          <Icon i="related"></Icon>
        </a>}

        {this.props.editable ?
          <a onClick={this.handleDelete.bind(this)} href="#">
            <Icon i="close"></Icon>
          </a> : null}
      </div>

      {!isAvailable ? <div className="not-available-layer"></div> : null}
    </div>

    return <li
       key={'song-info-' + song.id}
       className={classnames('songlist-song', {
         'current': isCurrent
       }, this.props.className)}
       style={this.props.style}>

      {this.props.editable ? <Draggable
        ref="dragger"
        axis="y"
        handle=".handle, .handle *"
        bound="left right"
        defaultPosition={{x: 0, y: 0}}
        position={this.state.drag ? null : {x:0, y:0}}

        onStart={this.handleStart.bind(this)}
        onDrag={this.handleDrag.bind(this)}
        onStop={this.handleStop.bind(this)}
      >{top}</Draggable> : top}

      {this.state.drag ? React.cloneElement(top, {
        className: classnames('top', 'placeholder')
      }) : null}

      {this.props.editable && song.isPlayable() ? <CommentEditable
        song={song}
        defaultValue={comment} />
       : (comment ? <div className="comments">{comment}</div> : null)
      }
    </li>
  }

}


export class MiniSonglistSong extends SonglistSong {

  render() {
    let song = this.props.song
    , isCurrent = !!song.get('isPlaying')

    return <li
      className={
        "songlist-song mini-songlist-song" + (isCurrent ? " current" : "")
      }
      onClick={this.switchSong.bind(this)}
    >
      <span className="index">{song.formatedIndex(this.props.index)}</span>

      <Cover
        src={song.get("picture")}
        size="36"
        className="cover"
      ></Cover>
      <div className="titles" style={{display: 'inline-block'}}>
        <h3>{song.get("title")}</h3>
        <p>{this.renderArtist()}&nbsp;&nbsp;{this.renderAlbum()} {song.get("public_time")}</p>
      </div>
    </li>
  }
}

export class PlayingSonglistSong extends SonglistSong {

  render() {
    let song = this.props.song
    , isCurrent = !!song.get('isPlaying')
    , itemInfo = song.get("item_info")
    , comment = itemInfo ? itemInfo.comment : ""
    , isRedheart = song.collection.id === 'redheart'

    return <li
      onClick={this.switchSong.bind(this)}
      className={classnames(
        'songlist-song', 'playing-songlist-song', {'current': isCurrent}
      )}
    >
      <div className="info">
        {this.props.index}. {song.get('title')} - {song.get('artist')}
        &nbsp;
        {song.isLike() && !isRedheart ?
          <IconHeart liked={song.isLike()} size={12} />
        : null}
      </div>
      {comment ?
        <div className="comments">{comment}</div> : null}
    </li>
  }

}

export class ArtistSonglistSong extends SonglistSong {
  render() {
    let song = this.props.song
    , isCurrent = !!song.get('isPlaying')

    return <li
      key={'song-' + song.id}
      className={"song" + isCurrent ? " current" : ""}
      onClick={this.switchSong.bind(this)}
    >
      <Cover size={18} src={song.get('picture')} className="cover"></Cover>
      {this.props.index >= 0 ?
        <span>{this.props.index + 1}.</span>
        : null}
      &nbsp;
      {song.get('title')}
    </li>
  }
}
