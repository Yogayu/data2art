// Playing Songlist
import "./playing-songlist.scss"

import React from "react"
import ReactDOM from "react-dom"
import Scrollbar from "ui/scrollbar"
import {PlayingSonglistSong } from "./song"
import douradio from "douradio"
import shallowCompare from "react/lib/shallowCompare"
import PlaylistTitle from "views/playing/PlaylistTitle"
import Link from "ui/link"


export class InfinitySonglist extends React.Component {

  // shouldComponentUpdate(nextProps, nextState) {
  //   return shallowCompare(this, nextProps, nextState)
  // }

  scrollToCurrentSong() {
    let curr = ReactDOM.findDOMNode(this.refs.current)
    if(curr) {
      let node = ReactDOM.findDOMNode(this)
      let pos = curr.offsetTop - node.offsetHeight / 2
      if(pos < 0) {
        pos = 0
      }
      let scroller = this.refs.scroller
      scroller.scrollTo(pos, 1000)
    }
  }

  componentDidMount() {
    this.scrollToCurrentSong()
  }

  componentDidUpdate() {
    // console.log('PlayingSonglist DidUpdate, Done!')
    this.scrollToCurrentSong()

    /*
    const containerHeight = this.props.height
    let sl = this.refs.songlist

    if(sl && sl.offsetHeight < containerHeight) {
      sl.style.marginTop = `${parseInt((containerHeight - sl.offsetHeight) / 2, 10)}px`
    } else {
      sl.style.marginTop = ''
    }
    */

    // scroll into current song

  }

  render() {
    // @todo set max song here
    let playableList = this.props.songs
    , baseIndex = 0

    return <Scrollbar className="scroller" ref={'scroller'} scroller={{
      suppressScrollX: true
      , scrollYMarginOffset: 10
    }}>
      {this.props.childBefore}

      <ul ref="songlist" className="songlist">
        {playableList.map((song, index) => {
          return <PlayingSonglistSong
            ref={song.get('isPlaying') ? 'current' : null}
            key={'song-' + song.id}
            song={song}
            index={baseIndex + index + 1}
          ></PlayingSonglistSong>
        })}
        {this.props.children}
      </ul>
    </Scrollbar>
  }
}

export default class PlayingSonglist extends React.Component {

  componentDidMount() {
    this.props.songlist.on("remove sort", () => {
      this.forceUpdate()
    }, this)

    this.props.songlist.on('reset', () => {
      this.forceUpdate()
    }, this)

    this.props.songlist.on("add", (model) => {
      model.add = true
      this.forceUpdate()
    }, this)

    douradio.on("switch_song", (model) => {
      this.forceUpdate()
    }, this)
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  componentWillUnmount() {
    this.props.songlist.off(null, null, this)
    douradio.off(null, null, this)
  }

  onClose(e) {
    e.preventDefault()
    this.props.onClose()
  }

  render () {
    let songlist = this.props.songlist

    return <div
      className="playing-songlist"
    >
      <InfinitySonglist
        songs={this.props.songlist.getPlayableList()}
        childComponent={PlayingSonglistSong}
        height={328}
      >
        <li style={{height: 10}}></li>
      </InfinitySonglist>

      <a onClick={this.onClose.bind(this)} href="/" style={{
        fontSize: 13
        , fontWeight: 400
        , color: '#8f8e94'

        , position: 'relative'
        , top: 12
      }} href="">关闭列表</a>
    </div>
  }

}
