import React from "react"
import "./daily-songlist-cover.scss"
import {pad} from "utils"
import Cover from "components/cover"

// const DayOfWeekAbbr = ['Sun.', 'Mon.', 'Tues.', 'Wed.', 'Thurs.', 'Fri.', 'Sat.']
const DayOfWeekName = [
  '日', '一', '二', '三', '四', '五', '六'
]

const MonthNames = [
  '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'
]


export default class DailySonglistCover extends React.Component {

  static defaultProps = {
    date: new Date()
    , cover: null
    , size: 114
  }

  render() {
    let now = this.props.date || new Date()
    , day = pad(now.getDate())
    , dow = DayOfWeekName[now.getDay()]

    return <Cover
      {...this.props}
      className={"programme-cover daily-songlist-cover"}
    >
      <div className="white-box" style={{
        transform: `scale(${this.props.size / 114})`
      }}>
        <div className="dow">
          {'星期' + dow}
        </div>

        <div className="day">{day}</div>

        <div className="year">{now.getFullYear()}</div>

        <div className="month">
          {MonthNames[now.getMonth()]}月
        </div>
      </div>
      {this.props.children}
    </Cover>

    // return <div className="" style={{
    //   backgroundImage: `url(${this.props.cover})`
    //   , width: this.props.size
    //   , height: this.props.size
    // }}>
    // </div>
  }

}
