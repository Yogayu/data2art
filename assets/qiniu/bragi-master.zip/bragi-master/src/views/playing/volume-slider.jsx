import "./volume-slider.scss"

import Slider from "components/slider"
import VolumeIcon from "icons/icon-volume"
// import Icon from 'ui/icon'
import douradio from "douradio"
import React from "react"
import shallowCompare from 'react/lib/shallowCompare'

export default class VolumnSlider extends React.Component {

  static defaultProps = {
    size: 15
    , hideWaitTime: 500
  }

  constructor(props) {
    super(props)
    this.state = {
      showSlider: false
    }
  }

  onVolumeChange(e, value) {
    douradio.setVolume(value)
    this.forceUpdate()
  }

  toggleVolume(e) {
    e.preventDefault()
    let value = douradio.getVolume()

    if(douradio.getVolume() > 0) {
      this._prevValue = value
      douradio.setVolume(0)
    } else {
      douradio.setVolume(this._prevValue || 100)
    }
    this.forceUpdate()
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  onDisplay() {
    if(this.hideTimeHandler) {
      window.clearTimeout(this.hideTimeHandler)
    }

    this.setState({showSlider: true})
  }

  onHide() {
    this.hideTimeHandler = window.setTimeout(() => {
      this.hideTimeHandler = null
      this.setState({showSlider: false})
    }, this.props.hideWaitTime)

  }

  render() {
    const size = this.props.size

    let volume = douradio.getVolume()
    , level

    if(volume <= 0) {
      level = 0
    } else if(volume < 33) {
      level = 1
    } else if(volume < 66){
      level = 2
    } else {
      level = 3
    }

    return <span
      className="volume-slider"
      onMouseEnter={this.onDisplay.bind(this)}
      onMouseLeave={this.onHide.bind(this)}
      style={{
        height: size
        , position: 'relative'
        , top: 3
      }}
    >
      <VolumeIcon
        className="volume-icon"
        onClick={this.onDisplay.bind(this)}
        level={level}
        size={size}
        height={11}
        width={15}
        color={'#919191'}
      ></VolumeIcon>

      <Slider
        name="volume-slider"
        className="ui-slider"
        hide={!this.state.showSlider}
        defaultValue={douradio.getVolume()}
        value={douradio.getVolume()}
        min={0}
        max={100}
        width={50}
        height={size}
        onChange={this.onVolumeChange.bind(this)}
      ></Slider>
    </span>
  }

}
