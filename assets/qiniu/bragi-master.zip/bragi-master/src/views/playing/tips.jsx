// this is a tips manager including no-login tips
import React from 'react'

export default class Tips extends React.Component {
  static defaultProps = {}

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    return <div className="tips" style={{
      position: 'absolute'
      , top: '50%'
      , marginTop: 180
    }}>
      {this.props.children}
    </div>
  }
}
