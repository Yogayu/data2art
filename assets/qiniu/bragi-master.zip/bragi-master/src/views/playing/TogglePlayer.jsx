import React from "react"
import styles from "./toggle-player.module.css"
import IconAngle from "icons/icon-angle"
import onlyUpdateForKeys from 'recompose/onlyUpdateForKeys'

/* global ga */
const IconTogglePlayer = ({
  isMiniPlayer, togglePlayer, animationProgress, top
}) => {
  return <a
    className={styles.togglePlayer}
    onClick={() => {
      ga('send', 'event', 'fullplayer', isMiniPlayer ? 'show' : 'hide')
      togglePlayer()
    }}
    style={{
      position: 'absolute'
      , top: top
      , zIndex: 1000
    }}
  >
    <IconAngle
      direction={isMiniPlayer ? 'bottom' : 'top'}
      color={'#6bbd7a'}
      style={{
        top: isMiniPlayer ? -1 : -2
      }}
    ></IconAngle>
  </a>
}

export default onlyUpdateForKeys(['top'])(IconTogglePlayer)
