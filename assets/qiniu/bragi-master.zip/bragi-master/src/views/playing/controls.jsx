import React from "react"
import Icon from "ui/icon"
import douradio from "douradio"
import IconHeart from "icons/icon-heart"
import {IconShuffle} from "icons"
// import classnames from 'classnames'

export default class PlayingControls extends React.Component {

  componentDidMount() {
    douradio.on('like unlike change:shuffle', () => {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  onSkip() {
    // if(douradio.currentSong.status == 's') {return Promise.reject()}
    return this.triggerAction('skip')
  }

  // trigger action and send events to ga
  triggerAction(name) {
    // events available here, toggleLike, prev, trash, skip
    let fn = douradio[name]
    if(fn) {
      fn.apply(douradio)
      ga('send', 'event', 'fullplayer', name)
    }
  }

  render() {
    let iconSize = 28

    return <div className="controls">
      <IconHeart
        className="icon icon-heart icon-heart-playing"
        onClick={this.triggerAction.bind(this, 'toggleLike')}
        size={iconSize}
        color={'#4A4A4A'}
        liked={douradio.currentSong.isLike()}
      ></IconHeart>

      {douradio.isProgramme() ?
        <Icon size={iconSize} onClick={this.triggerAction.bind(this, 'prev')} i="prev"></Icon> :
        <Icon size={iconSize} onClick={this.triggerAction.bind(this, 'ban')} i="trash"></Icon>}
      <Icon size={iconSize} onClick={this.onSkip.bind(this)} i="skip"></Icon>

      {douradio.isProgramme() ? <IconShuffle
        size={iconSize}
        onClick={douradio.toggleShuffle.bind(douradio)}
        color={douradio.isShuffle() ? '#6BBD7A' : '#8f8e94'}
      ></IconShuffle> : null}
    </div>

  }
}
