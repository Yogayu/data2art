require('./mini.scss')

import React from "react"
import ReactDOM from "react-dom"
import extend from "lodash/extend"
import includes from "lodash/includes"
import get from "lodash/get"

// import clone from 'lodash/lang/clone'
import douradio from "douradio"
import lang from "i18n"
import Icon from "ui/icon"
import IconHeart from "icons/icon-heart"
import IconPlay from "icons/icon-play"
import {IconShuffle, } from "icons"
import IconAngle from "icons/icon-angle"

import FullPlayer from "./fullplayer"
import {Progress, TimeLabel} from "./progress"
import VolumeSlider from "./volume-slider"
import Link from "ui/link"
import classnames from "classnames"
import ArtistLabels from "views/common/artists"
import Loading from "ui/loading"
import DoubanAD from "components/douban-ad"

import Notification from "ui/notification"
import Header from "./header"
import Background from "./background"
import IconTogglePlayer from "./TogglePlayer"

import MiniSonglist from "views/songlist/mini"

import {getScrollY} from "utils/domutils"

/* global ga */
// logger for mini player
const log = (action, label, value) => {
  return ga('send', 'event', 'miniplayer', action, label, value)
}

// animation helper
function fromTo(from, to, progress=0) {
  return from + (to - from) * progress
}

export class PlayerView extends React.Component {
  static defaultProps = {
    animationProgress: 0
  }

  constructor(props) {
    super(props)
    this.state = {
      user: {}
      , positions: {}
      , fullplayerOffsetY: 0
    }
  }

  goHome(e) {
    e.preventDefault()

    if(this.props.isMiniPlayer) {
      this.props.togglePlayer()
    }

    window.app.navigate('/', {trigger: false})
  }

  componentDidMount() {
    // douradio.getCurrentUser()

    douradio.on('login', () => {
      this.forceUpdate()
    }, this)

    // player related
    douradio.on("play pause resume switch_song like unlike change:shuffle request", () => {
      this.setInitAnimationPosition()
    }, this)

    this.setInitAnimationPosition()
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  // animation related
  setInitAnimationPosition() {
    // const specialTargetPositions = {'progress': {top: this.props.maxHeight}}
    // console.debug('AnimationPosition: run')

    let ap = this.props.animationProgress
    if(ap < 1 && ap > 0) {
      console.debug('AnimationPosition: pass')
      return
    }

    // get element style(fixed)
    let getElStyle = (el, topOffset=0) => {
      let {top, left, width, height} = el.getBoundingClientRect()

      return {
        top: top + topOffset
        , left: left + window.scrollX
        , width
        , height
      }
    }

    let fp = ReactDOM.findDOMNode(this.refs.fullplayer)
    , results = {}
    , refSelMap = {
      'progress': 'fullplayer-progress'
      , 'plTitle': 'playlist-title'
      , 'title': 'title'
      , 'singers': 'subtitle'

      , 'heart': 'icon-heart-playing'

      , 'trash': 'icon-trash'
      , 'prev': 'icon-prev'
      , 'skip': 'icon-skip'

      // , 'actions': 'controls'
      // , 'volume': 'volume-slider'
      // , 'timelabel': 'time'
    }

    for(let refName in refSelMap) {
      let clsName = refSelMap[refName]
      let els = fp.getElementsByClassName(clsName)

      // console.debug(clsName, refName)

      if(!els || els.length == 0) {
        continue
      }

      let fromEl = els[0]

      let targetEl = this.refs[refName]
      if(!React.isValidElement(targetEl)) {
        targetEl = ReactDOM.findDOMNode(targetEl)
      }

      if(!targetEl) {
        continue
      }

      results[refName] = {
        from: getElStyle(fromEl, getScrollY())
        , to: getElStyle(targetEl)
      }
    }

    // console.debug('init animation state: ', results)

    return this.setState({
      positions: results
    })
  }

  /**
   * get animation style attributes of an element
   * @param {String} targetName
   * @param {Number} progress 0-1 float number of an animation
   * @param {Object} extraStyle
   */
  _getAnimationStyle (targetName, progress, defaultStyle={}, transformAttrs=[]) {
    if(progress < 0.01 || progress > 0.99) {
      return defaultStyle
    }

    let positionMap = this.state.positions[targetName]

    if(!positionMap) {
      return defaultStyle
    }

    let {from, to} = positionMap
    , fromAttr = from
    , targetAttr = to
    , styles = {
    }

    styles.top = fromTo(fromAttr.top, targetAttr.top, progress)
    styles.left = fromTo(fromAttr.left, targetAttr.left, progress)

    if(includes(transformAttrs, 'width')) {
      styles.width = fromTo(fromAttr.width, targetAttr.width, progress)
    }

    if(includes(transformAttrs, 'scale')) {
      let scale = fromTo(fromAttr.width / targetAttr.width, 1, progress)
      // , scaleY = fromTo(fromAttr.height / targetAttr.height , 1, progress)
      styles.transform = `scale(${scale}, ${scale})`
    }

    return Object.assign({}, defaultStyle, styles, {
      position: 'fixed'
    })
  }

  getAnimationProps(name, ...transformAttrs) {
    return {
      style: this._getAnimationStyle(name, this.props.animationProgress,
                                     {}, transformAttrs)
      , ref: name
    }
  }

  getAnimationOpacity(begin=0.2, end=0.8) {
    let ap = this.props.animationProgress
    if(ap < begin) {
      return 1 - ap / begin
    } else if(ap > end) {
      return (ap - end) / (1 - end)
    } else {
      return 0
    }
  }

  onLogin(e) {
    e.preventDefault()
    window.app.showLogin()
    // let redirectUrl = location.origin + '/#/login/success'
    // location.href = douradio.oauthUrl(redirectUrl)
  }

  onClick(e, target) {
    if(target.props.href) {
      window.app.navigate(target.props.href, {
        trigger: true
      })
    }
  }

  showMiniList(e) {
    let pl = douradio.getCurrentPlaylist()

    let {
      top, left, width, height
    } = ReactDOM
      .findDOMNode(this.refs.buttonList)
      .getBoundingClientRect()

    window.app.root.displayOverlay(
      <MiniSonglist
        x={left + width / 2}
        y={top + height}
        songlist={pl}
      ></MiniSonglist>
    )
  }

  renderMiniPlayer() {
    let ap = this.props.animationProgress
    , pStyle = this._getAnimationStyle('progress', ap, {
      zIndex: ap < 0.01 ? -1 : 1000
      , opacity: ap < 0.01 ? 0 : 1
    }, ['width'])

    let song = douradio.currentSong
    , isPlaying = douradio.isPlaying()
    , hidden = this.props.animationProgress < 0.01

    if(!song){
      return <div className="mini-player">
        {hidden ? null : <Loading center={true}></Loading>}
      </div>
    }

    // let plTypeName = douradio.isProgramme() ? '歌单' : '兆赫'
    let pl = douradio.getCurrentPlaylist()
    , plTitle = pl.getTitle()
    , isChannel = pl.isChannel()

    // this.props need to be hidden during animation
    , animationHiddenStyle = {
      style: {
        opacity: this.props.animationProgress < 0.99 ? 0 : 1
      }
    }

    return <div className={
      classnames("mini-player", isChannel ? null : 'playing-songlist')
    } style={hidden ? {
      opacity: 0
      , zIndex: -1000
      , position: 'relative'
    } : {
      opacity: 1
    }}>
      <div className="titles">
        <div className="title" title={song.get('title') +' - ' + song.get('artist')}>
          <Link
            {...this.getAnimationProps('title')}
            href={"/song/" + song.objectId()}>{song.get('title')}</Link>
          <span {...animationHiddenStyle}>&nbsp;-&nbsp;</span>

          <span
            {...this.getAnimationProps('singers')}
            className="singers">
            <ArtistLabels song={song}></ArtistLabels>
          </span>
        </div>

        <Progress ref={'progress'} style={pStyle}></Progress>

        <div className="extra-info" {...animationHiddenStyle}>
          <span className="pl-title">{isChannel ?
            pl.id == 0 ? <span>我的私人兆赫</span> : <span>
              {plTitle} <span className="mhz-identity">MHz</span>
            </span> : <Link href={"songlist/" + pl.id}>{plTitle}</Link>}
          </span>

          <div className="right-area">
            <TimeLabel></TimeLabel>
            <VolumeSlider></VolumeSlider>
          </div>

        </div>
      </div>

      <div
        className="actions">
        {douradio.isProgramme() ? <IconShuffle
          size={26}
          onClick={douradio.toggleShuffle.bind(douradio)}
          color={douradio.isShuffle() ? '#6BBD7A' : '#8f8e94'}
          {...animationHiddenStyle}
        ></IconShuffle> : null}

        {isPlaying ? <Icon
          i={'pause-mini'}
          className="play-pause-button"
          onClick={() => {
            log('togglePause')
            douradio.togglePause(douradio)
          }}
          size={18}
          {...animationHiddenStyle}
        ></Icon> : <IconPlay
          size={18}
          className="play-pause-button"
          onClick={() => {
            log('togglePause')
            douradio.togglePause(douradio)
          }}
          color={'#4a4a4a'}
          {...animationHiddenStyle}
        ></IconPlay>}

        <IconHeart
          className="icon icon-heart"
          onClick={() => {
            log('toggleLike')
            douradio.toggleLike(douradio)
          }}
          size={18}
          liked={douradio.currentSong.isLike()}
          color={'#4A4A4A'}
          {...this.getAnimationProps('heart', 'scale')}
        ></IconHeart>

        {douradio.isProgramme() ?
          <Icon
            {...this.getAnimationProps('prev', 'scale')}
            size={18}
            onClick={() => {
              log('prev')
              douradio.prev()
            }} i="prev"></Icon> : <Icon
              {...this.getAnimationProps('trash', 'scale')}
              size={18}
              onClick={() => {
                log('ban')
                douradio.ban()
              }} i="trash"></Icon>
        }
        <Icon
          {...this.getAnimationProps('skip', 'scale')}
          size={18}
          onClick={() => {
            log('skip')
            douradio.skip()
          }} i="skip"></Icon>

        {douradio.isProgramme() ? <Icon
          size={18}
          ref="buttonList"
          onClick={(e) => {
            log('songlistButton')
            this.showMiniList(e)
          }}
          i="list"
          {...animationHiddenStyle}
        ></Icon> : null}
      </div>
    </div>
  }

  renderTips() {
    let hasCollectedChannel = get(douradio, [
      'options', 'userinfo', 'has_created_channel_songlist'
    ])

    if(hasCollectedChannel) {
      return <Notification style={{
        position: 'absolute'
      , right: 0
      , top: 87
      }}>
        你制作的兆赫已经变成歌单了，请
        <Link onClick={() => {
          // hide this link after confirmed
          douradio.options.userinfo.has_created_channel_songlist = false
        }} href="/mine/created">查看</Link>
      </Notification>
    } else {
      return null
    }
  }

  render() {
    let userinfo = get(douradio, ['options', 'userinfo']) || {}

    let style = extend({
        height: this.props.maxHeight
        , background: this.props.isMiniPlayer ? 'transparent' : '#fff'
      }, this.props.style)
    , ap = this.props.animationProgress
    , hasAd = !douradio.isPro()

    let currentSong = douradio.currentSong

    return <div className={"cl-player"} style={style}>
      <Header
        ap={ap}
        renderTips={this.renderTips.bind(this)}
        isLogin={douradio.isLogin()}
        onLogin={this.onLogin.bind(this)}
        username={userinfo.name}
        avatar={userinfo.icon}
        playedNum={userinfo.played_num}
        isPro={douradio.isPro()}
        background={
          ap > 0.99 ? <Background
            src={currentSong && currentSong.get('picture')}
            mini={true}></Background> : null
        }
      >
        {this.renderMiniPlayer()}
      </Header>

      <div className="wrapper">
        <Background src={currentSong && currentSong.get('picture')}></Background>

        <FullPlayer
          animationProgress={ap}
          ref="fullplayer"
          style={{
            top: this.state.fullplayerOffsetY
          }}
        ></FullPlayer>

        <IconTogglePlayer {...this.props} style={{
          position: 'fixed'
          , top: fromTo(this.props.maxHeight - 86, 40, ap)
        }}></IconTogglePlayer>

        {ap < 0.01 && hasAd ? <DoubanAD
          onUpdate={(width, height) => {
            this.setState({
              fullplayerOffsetY: -1 * (height + 22) / 2
            })
          }}
          unit="dale_fm_channel_new"
          style={{
            position: 'absolute'
            , bottom: 22
            , left: 0
            , right: 0
          }}
        ></DoubanAD> : null}
      </div>

    </div>
  }

}
