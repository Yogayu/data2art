import "./mini.scss"

import React from "react"
import lang from "i18n"

import Cover from "components/cover"

import IconAngle from "icons/icon-angle"
import IconTrangle from "icons/icon-trangle"
import IconPoint from 'icons/icon-point'

import SettingsDialog from "views/settings"
import {ProLabel, ParallelogramLabel} from "views/common/label"
import uniqueId from "lodash/uniqueId"
import _get from 'lodash/get'

import AppBox from 'views/share/app-box'
import shallowCompare from 'react/lib/shallowCompare'


// user avatar, user dialog


class AppLink extends React.Component {

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  onClick(e) {
    e.preventDefault()
    e.stopPropagation()

    return

    let boxRect = this.refs.link.getBoundingClientRect()

    // console.debug(boxRect)

    let x = boxRect.left
    , y = boxRect.top

    window.app.root.displayOverlay(<AppBox
      onClose={window.app.root.hideOverlay.bind(window.app.root)}
      x={x}
      y={y}
    ></AppBox>)
  }

  render () {
    return <DropdownMenu
      dropdown={AppBox}
      hasTrangle={false}
      offsetY={-15}
    >
      <a ref={'link'} href="" onClick={this.onClick.bind(this)}>
        下载豆瓣FM APP
      </a>
    </DropdownMenu>
  }

}

function Feedbacks({ap}) {
  let canSwitchOldVersion = _get(
    window, ['bootstrap', 'can_switch_to_old_version'], true
  )

  return <div className="feedback" style={{
    display: ap < 0.01 ? null : 'none'
  }}>
    {canSwitchOldVersion ? <a
      onClick={(e) => {
        e.preventDefault()
        window.app.displayFeedback(false)
      }}
      className="version-switcher"
      href="/account/switch_version?san=0"
    >
      <IconAngle
        size={14}
        direction="left"
        style={{
          top: -1
        }}
      ></IconAngle>
      回旧版
    </a> : null}
    <AppLink></AppLink>

    <span> <IconPoint size={9}></IconPoint> </span>

    <a href="#" onClick={() => {window.app.displayFeedback(true)}}>我要反馈</a>
  </div>
}


class GlobalOverlay extends React.Component {

  // this is a special Component that will replace
  // `window.app.displayOverlay` && `window.app.hideOverlay`

  componentWillMount() {
    // !!!hack, window.root may not ready

    if(!window.app.root) {
      window.setTimeout(() => {
        this.displayOverlay()
      }, 0)
    } else {
      this.displayOverlay()
    }
  }

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  displayOverlay() {
    this.overlayId = 'overlay' + uniqueId()
    let overlay = React.Children.only(this.props.children)
    window.app.root.displayOverlay(overlay, this.overlayId)
  }

  componentWillUnmount() {
    window.app.root.hideOverlay(this.overlayId)
  }

  render() {
    return false
  }
}


class DropdownMenu extends React.Component {

  static defaultProps = {
    hasTrangle: true
    , offsetX: 0
    , offsetY: 0
  }

  constructor(props) {
    super(props)
    this.state = {
      mouseIn: false
      , mouseInDropdown: false
      , x: 0
      , y: 0
    }
  }

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  updatePosition() {
    // calculate {x, y} value of an dropdown menu
    let el = this.refs.root
    , {top, left, width} = el.getBoundingClientRect()
    , x = left + width + this.props.offsetX
    , y = top + el.offsetHeight + this.props.offsetY

    this.position = {x, y}
  }

  componentDidMount() {
    this.updatePosition()
  }

  componentDidUpdate() {
    this.updatePosition()
  }

  render() {
    let Element = this.props.dropdown
    , showOverlay = this.state.mouseIn || this.state.mouseInDropdown

    return <div
      ref="root"
      onMouseEnter={ (e) => {
        this.setState({
          mouseIn: true
        })
      }}
      onMouseLeave={() => {
        this.setState({
          mouseIn: false
        })
      }}

      className={this.props.className}
      style={{display: 'inline-block'}}
    >
      {this.props.children}

      {this.props.hasTrangle ? <IconTrangle
        size={16}
        style={{
          transform: showOverlay ? 'rotate(180deg)' : null
          , transition: 'all .3s ease-out'
        }}
      ></IconTrangle> : null}

    {showOverlay ?
      <GlobalOverlay
        onClose={() => {}}
      >
        <Element
          align={'right'}
          onMouseEnter={(e) => {
            this.setState({
              mouseInDropdown: true
            })
          }}
          onMouseLeave={(e) => {
            this.setState({
              mouseInDropdown: false
            })
          }}

          {...this.position}
        ></Element>
      </GlobalOverlay>
      : null}

    </div>
  }

}


const FMLogo = require('../../../assets/fm-logo.svg')

// background-image: url('../../../assets/fm-logo.svg');

export default class Header extends React.Component {

  shouldComponentUpdate(np, ns) {
    return shallowCompare(this, np, ns)
  }

  render() {
    let {
      isLogin
      , onLogin
      , isPro
      , playedNum
      , ap
      , goHome
      , avatar
      , renderTips
    } = this.props
    // let ap = this.props.animationProgress
    // goHome = this.goHome.bind(this)
    // isLogin = douradio.isLogin()
    // isPro = douradio.isPro

    // renderTips, renderMiniPlayer

    return <div
      style={this.props.style}
      className={this.props.isMiniPlayer ? "app-header mini" : "app-header"}>
      {this.props.background}

      <div className="inner">
        <div className="nav-logo" style={{zIndex: 1000}}>
          <div
            onClick={goHome}
            style={{
              backgroundImage: `url(${window.__webpack_public_path__ || ''}${FMLogo})`
            }}
          >{lang('COMMON_DOUBAN_FM')}</div>
          <a href="http://douban.fm/app" target="_blank">
            <i className="icon-mobile" title="豆瓣FM App"></i>
          </a>
        </div>

        <Feedbacks ap={ap}></Feedbacks>

        {this.props.children}

        <div className="fr">
          <div
            className="user-block"
            ref="userblock"
            style={{
              paddingRight: ap < 0.01 ? 0 : 36
            }}
          >
          {isLogin ? (
            <DropdownMenu
              dropdown={SettingsDialog}
            >
              <Cover
                rounded={true}
                src={avatar}
                size={22}
                style={{
                  verticalAlign: 'middle'
                  , marginRight: 6
                }}></Cover>
              {ap < 0.01 ? <span>
                {isPro ? <ProLabel></ProLabel> : null}
                &nbsp;&nbsp;
                <ParallelogramLabel
                  color={'#2f9842'}
                  borderColor={'#8ed99c'}
                >
                  已听{playedNum}首
                </ParallelogramLabel>
              </span> : null}
            </DropdownMenu>
          ) : (<div>
            <a
              href='#/login'
              className='login-link'
              onClick={onLogin}
            >{lang('COMMON_LOGIN')}</a>
            &nbsp;
            <span style={{color: '#d8d8d8', marginLeft: '10px'}}>|</span>
            <a
              href='#'
              className='login-link'
              onClick={(e) => {
                e.preventDefault()
                window.app.showLogin(true)
              }}
            >{lang('COMMON_REGISTER')}</a>
          </div>)
        }</div>

        </div>

        {ap < 0.01 ? renderTips() : null}

      </div>
    </div>
  }

}
