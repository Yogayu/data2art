import React from 'react'
import Icon from "ui/icon"
import Link from "ui/link"
import OverflowText from "components/overflow-text"

function SonglistTitle ({playlist, children}) {
  let pl = playlist
  , title = pl.getTitle()
  , href = 'songlist/' + pl.id
  , onClick = (e) => {
    e.preventDefault()
    return window.app.navigate(
      href, {trigger: true}
    )
  }

  if(pl.isChannel()) {
    return pl.id == 0 ? <span>
      我的私人兆赫
    </span> : <span>
      <span style={{
        float: 'left'
        , display: 'block'
        , textOverflow: 'ellipsis'
        , whiteSpace: 'nowrap'
        , overflow: 'hidden'
        , maxWidth: 370
      }}>{title}</span>
      <span className="mhz-identity">MHz</span>
      {children}
    </span>
  } else {
    return <OverflowText
      fontSize={16}
      lineHeight={1.2}
    >
      <Link
        ga={{
          category: 'fullplayer'
          , action: 'SonglistSel'
          , label: pl.isSpecialSonglist() ? pl.id : 'normal'
          , value: pl.id
        }}
        href={href}
        style={{
          color: '#7c7b82'
        }}
      >
        {title}
      </Link>

      &nbsp;

      <Icon
        size={12}
        i={'songlist'}
        onClick={onClick}
        style={{
          position: 'relative'
          , top: -2
        }}></Icon>

    </OverflowText>
  }
}

export default SonglistTitle
