import React from "react"
import PlayingProgress from "components/playing-progress"
import {formatTime} from "utils"
import douradio from "douradio"
import shallowCompare from "react/lib/shallowCompare"

export class TimeLabel extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      time: ""
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  componentWillMount() {
    douradio.on('playing', function ({position, duration}) {
      let formatedTime = "-" + formatTime(duration - position)
      this.setState({
        time: formatedTime
      })
    }, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  render() {
    return <span {...this.props} className="time">{this.state.time}</span>
  }
}

export class Progress extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      played: 0
      , loaded: 0
      // , position: 0
    }
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  componentDidMount() {
    douradio.on('playing', function ({position, duration}){
      const step = 2
      let played = Math.round(position / duration * 100 * step) / step
      this.setState({
        played: played
      })
    }, this)

    /*
    douradio.on('loading', function (currentAudio) {
      let {bytesLoaded, bytesTotal} = currentAudio
      , loaded = Math.round(bytesLoaded / bytesTotal * 100)
      this.setState({loaded: loaded})
    }, this)
    */

    douradio.on('switch_song', () => {
      this.setState({
        played: 0
        , loaded: 0
      })
    }, this)

  }

  render() {
    return <PlayingProgress
      {...this.props}
      {...this.state}
      style={this.props.style}
      className={this.props.className}
    ></PlayingProgress>
  }
}
