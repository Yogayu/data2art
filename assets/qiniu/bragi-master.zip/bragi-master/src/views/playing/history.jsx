// dropdown, playrecords, jobdown
import "./history.scss"
import Dropdown from "ui/dropdown"
import React from "react"
// import {MiniSonglistSong} from 'views/songlist/song'
import request from "utils/request"
import douradio from "douradio"
import map from "lodash/map"
import classnames from "classnames"
import IconHeart from "icons/icon-heart"
import Link from "ui/link"
import Song from "douradio/song"


class HistorySonglist extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      songlist: []
    }
  }

  componentWillMount() {
    this.request = request({
      url: 'user_play_record'
      , data: {
        type: 'played'
        , start: 0
      }
      , method: 'get'
    }).then((response) => {
      if(!this.request) {
        return
      }

      this.setState({
        songlist: map(response.songs, (attrs) => {
          return new douradio.Song({
            sid: attrs.id
            , ssid: attrs.ssid
            , like: attrs.liked
            , artist: attrs.artist
            , title: attrs.title
          })
        })
      })
    })
  }

  componentWillUnmount() {
    this.request.abort()
    this.request = null
  }

  toggleLike(song) {
    song.set({
      like: !song.isLike()
    })

    song.toggleLike(request).then(() => {
      this.forceUpdate()
    })
  }

  render() {
    let songlist = this.state.songlist
    // history song has different attributes

    return <ul className="songlist">{songlist.map((song, index) => {
      let {title, artist} = song.attributes
      , id = song.id

      return <li
        key={'song-' + id + '-index-' + index}
        className={classnames(
          'songlist-song', 'mini-songlist-song'
        )}
      >
        <div className="titles" style={{display: 'inline-block'}}>
          <h3 className="title"><Link href={'song/' + song.objectId()}>{title}</Link></h3>
          <p className="subtitle">{artist}</p>
        </div>
        <a
          className={classnames({
            'redheart': true
          })}
          onClick={this.toggleLike.bind(this, song)}
          href="#"
        >
          <IconHeart
            className="icon icon-heart"
            size={12}
            color={'#E1E1E1'}
            liked={song.isLike()}
          ></IconHeart>
        </a>
      </li>
    })}</ul>
  }

}


export default class UserPlayRecord extends React.Component {

  constructor(p) {
    super(p)
    this.state = {}
  }

  render() {
    return <Dropdown className="dropdown-play-record" {...this.props} width={292} height={500}>
      <HistorySonglist></HistorySonglist>
    </Dropdown>
  }
}
