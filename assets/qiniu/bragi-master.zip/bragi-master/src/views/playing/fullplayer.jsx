import "./layout.scss"

import once from "lodash/once"
import isBoolean from "lodash/isBoolean"

import React from "react"
import douradio from "douradio"
import PlayingCover from "components/playing-cover"
import PlayingControls from "./controls"
import Lyrics from "components/lyrics"
import Icon from "ui/icon"

import {getScrollY} from "utils/domutils"

import {IconPause, } from "icons"
import IconPlay from "icons/icon-play"
import IconRight from "icons/icon-right"

import {TimeLabel, Progress} from "./progress"
import Link from "ui/link"
import lang from "i18n"
import PlayingSonglist from "views/songlist/playing"
import {SonglistChooser} from "views/actions/add2songlist"
import {ContextMenu, ContextMenuItem, ContextMenuLine} from "components/context-menu"
import VolumeSlider from "./volume-slider"
import ArtistLabels from "views/common/artists"
import Loading from "ui/loading"
import PlaylistTitle from "views/playing/PlaylistTitle"
import OverflowText from "components/overflow-text"
import TitleWithTooltip from "components/tooltip/TitleWithTooltip"

import NoLoginTips from 'views/login/tips/PlayingTips'
import tooltipGuide from 'views/tooltip-guide'
import Tips from './tips'

const log = (action, label, value) => {
  return ga('send', 'event', 'fullplayer', action, label, value)
}

class PlayingContextMenu extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      message: false
    }
  }

  toggleCollect() {
    let {pl} = this.props
    return pl.toggleCollect().then(() => {
      this.setState({
        message: pl.isCollect() ? <span>
          <IconRight size={12} color={'#00B869'}></IconRight>  已收藏
        </span> : <span>已取消收藏</span>
      })
      this.closeTimeHandler = window.setTimeout(() => {
        window.app.hideContextMenu()
        this.closeTimeHandler = null
      }, 3000)
    })
  }

  componentWillUnmount() {
    if(this.closeTimeHandler) {
      window.clearTimeout(this.closeTimeHandler)
    }
  }

  render() {
    let {song, pl} = this.props
    let items = []

    let pushLine = once(() => {
      items.push(
        <ContextMenuLine key={"line"}></ContextMenuLine>
      )
    })

    if(song) {
      items.push({
        key: 'share-song'
      , title: lang("MENU_SHARE_SONG")
      , onClick: (e) => {
          log('ContextMenu', 'ShareSong')
          window.app.share(song, pl)
        }
      })
      items.push({
        key: 'send-song'
      , title: lang('MENU_SENT_TO_PHONE')
      , onClick: (e) => {
          log('ContextMenu', 'SendSong')
          window.app.push2Device(song, e)
        }
      })

      items.push({
        key: 'related-song-channel'
      , title: lang('MENU_SIMILAR_SONG')
      , onClick: (e) => {
          log('ContextMenu', 'SimilarSong')
          return douradio.playNext(song.relatedChannelId(), 'channel')
        }
      })
    }

    if(pl.isChannel()) {
      if(pl.shareable()) {
        pushLine()
        items.push({
          key: 'share-channel'
        , title: "分享兆赫"
        , onClick: () => {
            log('ContextMenu', 'ShareChannel')
            window.app.share(null, pl)
          }
        })
      }
      if(douradio.isLogin() && pl.collectable()) {
        pushLine()
        items.push({
          key: 'collect-channel'
        , title: pl.isCollect() ? "取消收藏" : '收藏兆赫'
        , onClick: () => {
            log('ContextMenu', 'CollectChannel')
            this.toggleCollect()
          }
        , autoClose: false
        })
      }
    } else {
      if(pl.shareable()) {
        pushLine()
        items.push({
          key: 'share-sl'
        , title: "分享歌单"
        , onClick: () => {
            log('ContextMenu', 'ShareSonglist')
            window.app.share(null, pl)
          }
        })
      }
      if(douradio.isLogin() && pl.collectable()) {
        pushLine()
        items.push({
          key: 'collect-sl'
        , title: pl.isCollect() ? "取消收藏" : "收藏歌单"
        , onClick: () => {
            log('ContextMenu', 'CollectSonglist')
            this.toggleCollect(this)
          }
        , autoClose: false
        })
      }
    }

    return <ContextMenu {...this.props}>{items.map((i) => {
      if(React.isValidElement(i)){
        return i
      } else {
        return <ContextMenuItem {...i}></ContextMenuItem>
      }
    })}
    {this.state.message ? <div className="message">
        {this.state.message}
      </div> : null}
    </ContextMenu>
  }

}


class NextTips extends React.Component {
  // dep douradio

  onCancel() {
    douradio.unplayNext()
    return this.forceUpdate()
  }

  render() {
    let np = douradio.getNextPlaylist()

    if(!np) {
      return null
    }

    return <div style={{
      display: 'block'
      , height: 28
      , borderRadius: 2
      , backgroundColor: '#e7e7e7'
      , fontSize: 13
      , color: '#4a4a4a'
      , height: 36
      , lineHeight: '36px'
      , padding: '0 10px'
      // , marginTop: 50
      , marginBottom: 32
    }}>
      下一首将播放相似歌曲 &nbsp;&nbsp; <span style={{
        color: '#2f9842'
        , cursor: 'pointer'
      }} onClick={this.onCancel.bind(this)}>撤销</span>
    </div>
  }

}


class PlayingInfo extends React.Component {

  static defaultProps = {
    primaryColor: null
    , secondaryColor: null
  }

  constructor(props) {
    super(props)
  }

  componentDidMount() {
    // douradio.on('switch_song play pause', function() {this.forceUpdate()}, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  onShare(playlist, event) {
    event.preventDefault()
    window.app.share(null, playlist)
  }

  togglePause() {
    log('togglePause')
    return douradio.togglePause()
  }

  playlistName() {
    let pl = douradio.getCurrentPlaylist()
    , title = <PlaylistTitle playlist={pl}></PlaylistTitle>

    return <div className="playlist-title" style={{
      color: this.props.primaryColor
    }}>{(() => {
      if(pl.isChannel()) {
        let channelType = pl.getChannelType()

        // channel type artist
        if(channelType == 1) {
          return <TitleWithTooltip
            icon={'cat-artist'}
            title={title}
            tooltip={'包含和该艺术家相似的一些艺术家的歌曲'}
            tooltipProps={{
              color: '#4a4a4a'
              , backgroundColor: '#E7E7E7'
            }}
          ></TitleWithTooltip>
        } else if (channelType == 2) {
          return <TitleWithTooltip
            icon={'cat-track'}
            title={title}
            tooltip={'包含和该单曲相似的一些歌曲'}
            tooltipProps={{
              color: '#4a4a4a'
              , backgroundColor: '#E7E7E7'
            }}
          ></TitleWithTooltip>
        } else if (pl.id == '-10') {
          return <TitleWithTooltip
            title={title}
            tooltip={'汇聚各种音乐风格的精选兆赫'}
            tooltipProps={{
              color: '#4a4a4a'
              , backgroundColor: '#E7E7E7'
            }}></TitleWithTooltip>
        }
      }

      return title

    })()}

    </div>
  }

  render() {
    let song = douradio.currentSong
    , isPlaying = douradio.isPlaying()

    let ap = this.props.animationProgress

    return <div
      className="playing-info"
      style={{
        opacity: ap === 0 ? 1 : 0
      }}
    >
      {this.playlistName()}

      <div className="titles">
        <OverflowText
          className="title"
          fontSize={26}
        >
          <Link ga={{
            category: 'fullplayer'
            , action: 'SongSel'
          }} href={"/song/" + song.objectId()}
          style={{
            color: this.props.primaryColor
          }}
          >{song.get('title')}</Link>
        </OverflowText>

        <div className="subtitle">
          <ArtistLabels song={song} ga={{
            category: 'fullplayer'
            , action: 'ArtistSel'
          }}></ArtistLabels>

          <div className="fr">
            <TimeLabel onClick={this.togglePause.bind(this)}></TimeLabel>
            {isPlaying ? <IconPause
              color={'#4a4a4a'}
              size={24}
              onClick={this.togglePause.bind(this)}>
            </IconPause> : <IconPlay
              size={24}
              viewBox={'-4 -4 23 23'}
              color={'#4a4a4a'}
              onClick={this.togglePause.bind(this)}
              style={{
                top: -2
              }}
            ></IconPlay>}
          </div>

        </div>

      </div>

      <Progress
        barColor={this.props.primaryColor}
        bgColor={this.props.secondaryColor}
        className="fullplayer-progress"
        style={{
          opacity: ap === 0 ? 1 : 0
        }}
      ></Progress>

      <div className="below-progress">
        <VolumeSlider></VolumeSlider>
        {this.props.children}
      </div>

      <div className="playing-controls">
        <PlayingControls></PlayingControls>
      </div>


    </div>
  }
}

class PlayingLyrics extends React.Component {

  constructor(props) {
    super(props)
    this.state = {lyric: null}
  }

  initLyric(model) {
    this.setState({lyric: null})

    if(!model || !model.get('sid')) {
      return
    }

    this.forceUpdate()

    this.request = douradio.getLyric(model).then((lyric) => {
      this.setState({lyric: lyric})
      this.forceUpdate()
    }, () => {
      // #if failed, set as no lyric
      this.setState({lyric: ""})
      this.forceUpdate()
    })
  }

  handleReportLyric(e) {
    e.preventDefault()
    console.debug('open a report window or do something here')
  }

  onClose(e) {
    e.preventDefault()
    this.props.onClose()
  }

  shouldComponentUpdate(nextProps, nextState) {
    return false
  }

  componentDidMount() {
    if(!this.state.lyric && douradio.currentSong) {
      this.initLyric(douradio.currentSong)
    }
    douradio.on('switch_song', this.initLyric, this)
  }

  componentWillUnmount() {
    this.request && this.request.abort && this.request.abort()
    douradio.off(null, null, this)
  }

  render() {
    // <a onClick={this.handleReportLyric.bind(this)} href="#">歌词报错</a>
    return <div className="playing-lyrics">
      <Lyrics
        className={'lyrics'}
        lyric={this.state.lyric}
        douradio={douradio}
      ></Lyrics>
      <div className="lyrics-toolbar">
        <a onClick={this.onClose.bind(this)} href="#">关闭歌词</a>
      </div>
    </div>
  }
}

export default class FullPlayer extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      showLyric: false
    }
  }

  toggleLyric(status=null) {
    if(!isBoolean(status)) {
      status = !this.state.showLyric
    }

    this.setState({
      showLyric: status
    })
  }

  onContextMenu(e) {
    let rect = e.target.getBoundingClientRect()
    , pl = douradio.getCurrentPlaylist()
    , song = douradio.currentSong
    , props = {
      song: song
      , pl: pl
      , x: rect.left
      , y: rect.top
    }

    return window.app.displayContextMenu(
      <PlayingContextMenu {...props}></PlayingContextMenu>
    )
  }

  onA2SL (e) {
    e.preventDefault()
    return window.app.displayContextMenu(
      <SonglistChooser
        song={douradio.currentSong}
        x={e.pageX}
        y={e.pageY - getScrollY()}
      ></SonglistChooser>
    )
  }

  viewAlbum(url, event) {
    event.preventDefault()
    window.open(url, '_blank')
  }

  render() {
    let pl = douradio.getCurrentPlaylist()
    , song = douradio.currentSong
    , isChannel = pl ? pl.isChannel() : true

    if(!song) {return <Loading></Loading>}

    let ap = this.props.animationProgress
    , opacity = (1 - ap * 4)

    if(opacity < 0) {
      opacity = 0
    }

    let animationStyle = Object.assign(this.props.style, {
      opacity: opacity
    })

    let isLogin = douradio.isLogin()

    let bgad = pl.info && pl.info.bg_ad

    return <div className="fullplayer" style={animationStyle}>
      {!isChannel ?
        <PlayingSonglist songlist={pl}></PlayingSonglist> :
      bgad ? <div style={{
        backgroundImage: `url(${bgad.pic})`
        , backgroundSize: 'cover'
        , width:  170
        , height: 170
        , position: 'absolute'
        , top: '50%'
        , marginTop: -90
        , left: -180
      }}></div> : null}

      <PlayingInfo
        primaryColor={bgad && bgad.color}
        secondaryColor={bgad && bgad.bgColor}
        barColor={bgad && bgad.barColor}
        animationProgress={this.props.animationProgress}>
        <Icon
          className={this.state.showLyric ? 'on' : 'off'}
          i={'lyric'}
          onClick={this.toggleLyric.bind(this)}></Icon>
        {isLogin ?
          <Icon i={'add'} onClick={this.onA2SL.bind(this)}></Icon>
        : null}
        <Icon onClick={this.onContextMenu.bind(this)} i={'more'}></Icon>
      </PlayingInfo>

      <PlayingCover
        size={206}
        paused={!douradio.isPlaying()}
        loading={douradio.isLoading()}
        src={song.get('picture')}
        onClick={this.viewAlbum.bind(this, song.albumLink())}
        style={{
          transform: `scale(${1 - ap})`
          , opacity: this.state.showLyric ? 0.1 : 1
        }}
      >
        <span className="hover-tip">{lang('PLAYING_VIEW_ALBUM')}</span>
      </PlayingCover>

      {this.state.showLyric ?
        <PlayingLyrics onClose={this.toggleLyric.bind(this)}></PlayingLyrics> : null}

      <Tips>
        {tooltipGuide.hasTooltip ? <div style={{height: 30}}></div> : null}
        <NextTips></NextTips>
        {!isLogin ? <NoLoginTips
          redHeartCount={douradio.userinfo('liked_num')}
        ></NoLoginTips> : null}
      </Tips>

      {tooltipGuide.render({scrolled: ap === 1})}
    </div>
  }
}
