// Background
import React from "react"
import styles from "./background.module.css"
import clns from "classnames"
// import Blur from 'components/stackblur'
import {supportFilter} from 'components/BluredImage'

export default class Background extends React.Component {

  static defaultProps = {
    // src: 'http://img3.doubanio.com/lpic/s2808528.jpg'
    src: 'https://img1.doubanio.com/view/site/large/public/fc9d452c28600e9.jpg'
    , baseZindex: 0
    , mini: false
  }

  // componentWillReceiveProps(nextProps) {}

  renderImage(src, zindex) {
    if(supportFilter) {
      return <img
        className={clns(
          styles.cover,
          this.props.mini ? styles.coverMini : null
        )}
        src={src}
        style={{zIndex: zindex}}
      ></img>
    } else {
      return null
      // return <Blur
      //   className={styles.cover}
      //   src={src}
      //   blurRadius={20}
      //   style={{zIndex: zindex}}
      //   height={680}
      //   width={680}
      // ></Blur>
    }

  }

  render() {
    let baseZindex = this.props.baseZindex
    , src = this.props.src
    // src = 'https://img1.doubanio.com/view/site/large/public/fc9d452c28600e9.jpg'

    return <div className={styles.container}
      style={{
        zIndex: baseZindex
      }}
    >
      {this.renderImage(src, baseZindex)}
      <div className={styles.over} style={{zIndex: baseZindex + 1}}></div>
    </div>
  }

}
