import "./a2sl.scss"

import React from "react"
import request from "utils/request"
import Scroller from "ui/scrollbar"
import douradio from "douradio"
import Songlist from "douradio/songlist"
import classnames from "classnames"
import Overlay from "ui/overlay"
import Link from "ui/link"
import IconRight from "icons/icon-right"

const TITLEMAXLENGTH = 40

class QuickInput extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      value: ''
    }
  }

  onCreate() {
    return this.props.onCreate(this.refs.input.value)
  }

  clear() {
    this.state.value = ""
  }

  onChange() {

    this.setState({
      value: this.refs.input.value
    })
  }

  render() {
    let charLeft = TITLEMAXLENGTH - this.state.value.length
    , hasValue = this.state.value.length > 0

    return <div className={'create-songlist-input'}>
      <form action="#" onSubmit={hasValue ? this.onCreate.bind(this) : null}>
        <input
          onChange={this.onChange.bind(this)}
          ref={'input'}
          type="text"
          placeholder="+ 创建歌单"
          value={this.state.value}
          className={charLeft < 0 ? 'error' : null}
        />
        {charLeft < 0 ?  <span className="notice-error">{charLeft}</span> : <button
          className={classnames("button", hasValue ? "button-active" : "button-disable")}
          onClick={hasValue ? this.onCreate.bind(this) : null}>创建</button>}
      </form>
    </div>
  }
}


export class SonglistChooser extends React.Component {
  // needed props: merge(song, ContextMenu.props)

  constructor(props) {
    super(props)
    this.state = {
      songlists: []
      , done: false
      , err: null
    }
  }

  componentDidMount() {
    let CACHE_TIME = 1 * 60 * 60
    this.request = request({
      url: 'programme/creation'
    }, CACHE_TIME).then((response) => {
      if(!this.request) {
        return
      }
      let {total, programmes} = response
      this.setState({songlists: programmes, total: total})
    })
  }

  componentWillUnmount() {
    this.request = null
    window.clearTimeout(this.closeTimer)
  }

  onCreate(title) {
    // console.debug('[create] begin')
    return Songlist.create(douradio, {
      title: title
      , description: ''
      , is_public: true
    }).then((sl) => {
      this.state.songlists.unshift(sl.info)
      this.state.total = this.state.total + 1
      this.refs.input.clear()
      this.forceUpdate()
    })
  }

  addToProgramme(pl, comment=null) {
    let sl = douradio.getSonglist(pl.id)
    sl.addSong(this.props.song.id).then((result) => {
      this.setState({
        done: true
        , targetId: pl.id
      })
      this.closeTimer = window.setTimeout(function () {
        window.app.hideContextMenu()
      }, 5000)
    }, (err) => {
      let errMsg
      try {
        errMsg = JSON.parse(err.responseText)
      } catch (e) {
        errMsg = {}
      }
      // console.error(errMsg)
      if(errMsg.msg == 'duplicated_song_error') {
        this.setState({
          done: true
          , err: '歌曲已经存在歌单里了'
          , targetId: pl.id
        })
      } else {
        this.setState({
          done: true
          , err: err.msg
          , targetId: pl.id
        })
      }
    })
  }

  viewSonglist(url) {
    window.app.hideContextMenu()
    window.app.navigate(url, {
      trigger: true
    })
  }

  render() {
    return <Overlay
      className="songlist-chooser"
      {...this.props}
    >
    {this.state.done ? <span className="tooltip-success">
      <div className="container" style={{
        height: 336
      }}>
        {this.state.err ?
          this.state.err : <span>
            <IconRight color={'#59B36A'} size={13}></IconRight> 添加成功
          </span>}
        <p>
          <a
            href={"songlist/" + this.state.targetId}
            onClick={this.viewSonglist.bind(this, "songlist/" + this.state.targetId)}
          >查看歌单</a>
        </p>
      </div>
    </span> : <Scroller className="container" style={{maxHeight: 336}}>
        <QuickInput ref="input" onCreate={this.onCreate.bind(this)}></QuickInput>
        <ul>{this.state.songlists.map( (pl) =>
          <li
            key={'menu-sl-' + pl.id}
            onClick={this.addToProgramme.bind(this, pl)}
          >{pl.title}</li>
        )}</ul>
      </Scroller>}
    </Overlay>
  }
}
