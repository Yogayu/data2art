/**
 * this folder includes ui/actions
 *
 * @example buildContextMenu(
 * )
 *
 */

import {
  ContextMenu,
  ContextMenuItem,
  ContextMenuLine
} from "components/context-menu/"

// point, point, point

let buildContextMenu = () => {
  return <ContextMenu>
    <ContextMenuItem></ContextMenuItem>
    <ContextMenuLine></ContextMenuLine>
  </ContextMenu>
}

export default buildContextMenu
