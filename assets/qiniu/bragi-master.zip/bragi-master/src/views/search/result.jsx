import "./search-result.scss"

import isPlainObject from "lodash/isPlainObject"
import React from "react"
import douradio from "douradio"
import Cover from "components/cover"
import lang from "i18n"
import Link, {ChannelLink, SonglistLink} from "ui/link"
import Icon from "ui/icon"
import {IconRelated} from "icons"
import Song from "douradio/song"


let highlight = (text, keyword) => {
  if(!text || !keyword || text.indexOf(keyword) < 0) {
    return text
  }

  let splits = text.split(keyword)
  , children = []

  for(let i in splits) {
    let value = splits[i]
    if(value) {
      children.push(value)
    }
    if(i != (splits.length - 1)) {
      children.push(<span key={i} className="keyword">{keyword}</span>)
    }
  }

  return <span>{children}</span>
}


class SRSong extends React.Component {

  get song() {
    return this.props.result
  }

  render() {
    let song = this.song
    // @todo related_song_channel
    let isPlayable = song.playable

    return <li className="search-result search-result-song">
      <Cover
        rounded={false}
        src={song.cover}></Cover>
      <div className="bd">

        <div className="vertical-1-2">
          <Link href={"/song/" + Song.getObjectId(song.id, song.ssid)} className="song-title">
            {highlight(song.title, this.props.query)}
          </Link>
          {!isPlayable ? <span className="noplable">未上架</span> : null}
        </div>

        <div className="vertical-1-2">
          <span className="artist">
            {highlight(song.artist_name, this.props.query)}
          </span>
          <Icon size={9} i="point"></Icon>
          <span className="album">
            {highlight(song.album_title, this.props.query)}
          </span>
        </div>
      </div>
      <div className="fr">
        {song.channel ?
          isPlayable ?
            <ChannelLink id={song.channel}>单曲兆赫</ChannelLink> :
              <ChannelLink
                icon={<IconRelated size={16} color={'#8F8E94'}></IconRelated>}
                id={song.channel}
              >相似歌曲</ChannelLink>
        : '收听数据准备中'}
      </div>
    </li>
  }

}

export class SRArtist extends React.Component {

  navigate() {
    return window.app.navigate(
      '/artist/' + this.props.result.id,
       {trigger: true}
    )
  }

  toggleLike(e) {
    e.preventDefault()

    let model = this.props.result
    model.toggleLike(douradio.apiClient.request).then((success) => {
      this.forceUpdate()
    })
  }

  onShare(e) {
    e.preventDefault()
    e.stopPropagation()

    let artist = this.props.result
    if(isPlainObject(artist)) {
      artist = new Artist(artist)
    }
    window.app.share(artist)
  }

  render() {
    let artist = this.props.result
    , hasSubmenu = false
    , model

    if(!isPlainObject(artist)){
      // here, artist is a Artist Object
      hasSubmenu = true
      model = artist
      artist = artist.toJSON()
    }

    return <li className="search-result search-result-artist">
      <Cover
        src={artist.avatar}
        rounded={true}
        onClick={this.navigate.bind(this)}></Cover>

      <div className="bd">
        <Link
          href={'/artist/' + artist.id}
          onClick={this.navigate.bind(this)}
          className="title">
          {highlight(artist.name_usual, this.props.query)}
        </Link>
      </div>
      <div className="fr">
        {hasSubmenu ? <div className="hover-menu">
          <a href="" onClick={this.toggleLike.bind(this)}>{
            model.get('like') ? '取消喜欢' : '喜欢'
          }</a>
          <a href="" onClick={this.onShare.bind(this)}>分享</a>
        </div> : null}
        {artist.hot_songlist ?
          <SonglistLink id={artist.hot_songlist}>精选歌曲</SonglistLink>
          : null}
        {artist.channel ?
          <ChannelLink id={artist.channel}>艺术家兆赫</ChannelLink>
          : null}
      </div>
    </li>
  }
}

class SRChannel extends React.Component {
  render() {
    let channel = this.props.result
    return <li className="search-result search-result-channel">
      <ChannelLink id={channel.id}>
        {highlight(channel.title, this.props.query)}
        &nbsp;
        <small>MHz</small>
      </ChannelLink>
    </li>
  }
}

class SRSonglist extends React.Component {
  render() {
    let songlist = this.props.result

    return <div className="search-result search-result-songlist">
      <Cover
        size={46}
        src={songlist.cover}
        onPlay={douradio.switchSonglist.bind(douradio, songlist.id)}
      ></Cover>
      <div className="bd">
        <div className="vertical-1-2">
          <Link
            href={'/songlist/' + songlist.id}
            className="songlist-title">
            {highlight(songlist.title, this.props.query)}
          </Link>
        </div>
        <div className="vertical-1-2">
          <span className="songlist-detail">
            {songlist.collected_count} 收藏
          </span>
        </div>
      </div>
    </div>
  }
}

const BLOCKMAP = {
  'song': ['单曲', SRSong, 'search/song']
  , 'artist': ['艺术家', SRArtist, 'search/artist']
  , 'channel': ['兆赫', SRChannel, 'search/channel']
  // @todo change programme to songlist in the future
  , 'songlist': ['歌单', SRSonglist, 'search/programme']
}

export class SearchResult extends React.Component {

  static defaultProps = {
    limit: 5
    , title: null
    , results: null
  }

  constructor(props) {
    super(props)
    this.state = {
      extra: 0
    }
  }

  componentDidMount() {
    if(this.props.onLoadMore) {
      this.loadMore()
    }
  }

  getLimit() {
    return this.props.limit + this.state.extra
  }

  loadMore() {
    let {results, onLoadMore} = this.props
    , limit = this.getLimit()
    if(onLoadMore && limit && results && results.length < limit) {
      onLoadMore(results.length, (limit - results.length))
    }
  }

  /**
   * @param  {Event} e: dom event
   */
  onMore(e) {
    e.preventDefault()

    if(this.props.onLoadMore) {
      this.state.extra = this.state.extra + 10
      this.loadMore()
    } else if(this.props.onMore) {
      this.props.onMore()
    }
  }

  hasMore() {
    return this.getLimit() < this.props.total
  }

  render() {
    // blockMap
    let results = this.props.results

    if(results === null || results.length === 0) {
      // search result not loaded
      return null
    } else {
      results = results.slice(0, this.getLimit())
    }

    let title, Widget
    
    try {
      [title, Widget, ] = BLOCKMAP[this.props.type]
    } catch (e) {
      return null
    }

    if(this.props.title !== null) {
      title = this.props.title
    }

    return <div className="search-results">
      {title ? <h3>{title}</h3> : null}
      <ul>{results.map((result) => {
        if(!Widget) {
          console.debug(Widget)
          return null
        }
        return <Widget
          result={result}
          key={result.id}
          query={this.props.query}
        ></Widget>
      })}</ul>
      {this.hasMore() ?
        <a onClick={this.onMore.bind(this)}
          className="more-button"
          href="#more">{lang('SEARCH_MORE')}{title}</a> : null
      }
    </div>
  }

}
