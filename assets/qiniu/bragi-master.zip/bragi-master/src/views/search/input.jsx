import "./input.scss"

import React from "react"
import lang from "i18n"
import Icon from "ui/icon"
import {IconClose} from "icons"

export default class SearchInputBox extends React.Component {
  // static defaultProps = {onSearch: () => {}}

  constructor(props) {
    super(props)
    this.state = {focus: false}
  }

  get value() {
    return this.props.value || ''
  }

  focusSearch() {
    let node = this.refs.search
    let length = node.value.length
    if (document.selection) {
      // for ie
      node.focus()
      oSel = document.selection.createRange()
      oSel.moveStart('character', -length)
      oSel.moveStart('character', length)
      oSel.moveEnd('character', 0)
      oSel.select()
    } else if (node.setSelectionRange) {
      node.setSelectionRange(length, length)
      node.focus()
    }
  }

  componentDidMount() {
    this.focusSearch()
  }

  onFocus() {
    this.setState({focus: true})
  }

  onBlur() {
    this.setState({focus: false})

    // save history when onBlur
    app.searchHistory.push(
      this.refs.search.value
    )
  }

  onClick(e) {
    e.preventDefault()

    if(!this.state.focus) {
      this.refs.search.focus()
    }
  }

  onClear(e) {
    e.preventDefault()
    this.props.onSearch("")
  }

  onChange(e) {
    let value = e.target.value
    this.props.onSearch(value)
  }

  render() {
    return <div
      className="search-input-wrapper"
      onClick={this.onClick.bind(this)}
    >
      <Icon i={'search'} size={14} style={{
        verticalAlign: 'middle'
        , position: 'relative'
        , top: -2
      }}></Icon>
      <i className="icon-search"></i>
      <input
        ref="search"
        type="text"
        className="search"
        placeholder={lang('COMMON_SEARCH_PLACEHOLDER')}
        value={this.value}
        onFocus={this.onFocus.bind(this)}
        onBlur={this.onBlur.bind(this)}
        onChange={this.onChange.bind(this)}
      />

    {this.value ? <a
      className="button-close"
      onClick={this.onClear.bind(this)}
      href="#search">
        <IconClose
          size={13}
          color={'#ffffff'}
          center={true}
        ></IconClose>
      </a> : null}
    </div>
  }

}
