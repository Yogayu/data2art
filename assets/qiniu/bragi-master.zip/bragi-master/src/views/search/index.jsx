// Search Page
import "./search-result.scss"

import React from "react"
import Popup from "ui/popup"
import lang from "i18n"
import request from "utils/request"
import find from "lodash/find"
import some from "lodash/some"
import isEmpty from "lodash/isEmpty"
import union from "lodash/union"
import {SearchResult} from "./result"
import SearchInputBox from "./input"
import Icon from "ui/icon"

let NoResult = (props) => {
  let {children} = props

  return <div className="search-results">
    <p style={{textAlign: 'center'}}
      className="description">
      {children ? children : lang('SEARCH_NO_RESULT')}
    </p>
  </div>
}

let TypeFilter = ({
  onChange=null
  , curr=null
  , items=[]
}) => {
  return <div className="type-filter">{
  items.map((item) => {
    return <a
      className={curr == item.key ? 'curr' : ''}
      key={item.key}
      onClick={onChange.bind(null, item.key)}
    >{item.name}</a>
  })}</div>
}

class DefaultBlock extends React.Component {

  static defaultProps = {
    history: []
    , hot: []
  }

  onQuery(query) {
    return this.props.onQuery(query)
  }

  renderHotBlock() {
    return <div className="hot">
      <i className="icon-fire"></i>
      {this.props.hot.map((word) => {
        return <span
          key={word}
          onClick={this.onQuery.bind(this, word)}>
          {word}
        </span>
      })}
    </div>
  }

  renderSearchHistory() {
    return <div className="history">
      <Icon i={'clock'}></Icon>
      {this.props.history.map((word) => {
        return <span
          key={word}
          onClick={this.onQuery.bind(this, word)}>
          {word}
        </span>
      })}
    </div>
  }

  render() {
    return <div className="block-default">
      {this.props.history && this.props.history.length > 0 ?
        this.renderSearchHistory() : null}
    </div>
  }
}

export default class Search extends React.Component {

  static defaultProps = { q: '' }

  constructor(props) {
    super(props)
    this.state = {
      q: ''
      , section: 'default'
      , hidden: false
      , results: null

      , isFetching: false
    }
  }

  onSearch(q) {
    if(this.request) {
      this.request.abort()
    }
    this.request = request({
      url: 'query/all'
      , method: 'get'
      , data: {
        q: q
        , start: 0
        , limit: 5
      }
    }).then((response) => {
      this.setState({
        q: q
        , results: response
        , isFetching: false
      })
    }, (err) => {
      // set no-result if search is not unloaded
      if(this.request) {
        this.setState({
          q: q
          , result: []
          , isFetching: false
        })
      }
    })
    this.setState({q: q, isFetching: true})
  }

  loadMore(query, type, start, limit) {
    if(this.request) {
      this.request.abort()
    }

    this.request = request({
      url: 'query/' + type
      , method: 'get'
      , data: {
        q: query
        , start: start
        , limit: limit
      }}
    ).then(({items, total, type}) => {
      if(this.state.section !== type || this.state.q !== query) {
        return
      }
      let result = this.findCurrentResult()
      if (result) {
        result.items = union(result.items, items)
        this.forceUpdate()
      }
    })
  }

  componentWillUnmount() {
    if(this.request) {
      this.request.abort()
      this.request = null
    }
  }

  onClose(e) {
    e.preventDefault()
    this.setState({ hidden: true })
    // this.props.onClose && this.props.onClose()
    this.props.history.goBack()
  }

  getQuery() {
    return this.state.q || this.props.q
  }

  onSectionChange(type, e) {
    e && e.preventDefault()
    // console.log('<Event type=', type, 'event=', e, '/>')
    this.setState({section: type})
  }

  findCurrentResult() {
    if(!this.state.results) {
      return null
    }
    return find(this.state.results, (r) => {
      return r.type == this.state.section
    })
  }

  getSearchBlock() {
    let query = this.getQuery()

    if(!this.state.section || this.state.section !== 'default') {
      let result = this.findCurrentResult()
      if(!result || result.total === 0 || isEmpty(result.items)) {
        return <NoResult></NoResult>
      }
      return <SearchResult
        query={query}
        type={result.type}
        results={result.items}
        total={result.total}
        limit={10}
        onLoadMore={this.loadMore.bind(this, query, result.type)}
      ></SearchResult>
    } else {
      // check any of the results has item
      if(this.state.results && some(this.state.results, ({total}) => {
        return total > 0
      })) {
        return (this.state.results || []).map(({items, total, type}) => {
          if(total === 0 || isEmpty(items)) {
            return null
          }

          return <SearchResult
            results={items}
            total={total}
            query={query}
            key={type}
            type={type}
            onMore={this.onSectionChange.bind(this, type)}
          ></SearchResult>
        })
      } else {
        return <NoResult>
          {this.state.isFetching ? '正在搜索...' : null}
        </NoResult>
      }
    }
  }

  render() {
    let query = this.getQuery()
    , searchResults = this.getSearchBlock()

    // return <Popup hidden={this.state.hidden}></Popup>
    return <div
        className="container search-result-page"
        style={{
          paddingTop: 0
          , minHeight: window.innerHeight - 200
        }}

      >
        <div className="hd">
          <SearchInputBox
            onSearch={this.onSearch.bind(this)}
            value={query}></SearchInputBox>
          <a
            onClick={this.onClose.bind(this)}
            className="cancel"
            href="#back">取消</a>
        </div>

        {this.state.q ? <TypeFilter
          onChange={this.onSectionChange.bind(this)}
          curr={this.state.section}
          items={[{
            key: 'default'
            , name: '全部'
          },{
            key: 'artist'
            , name: '艺术家'
          }, {
            key: 'song'
            , name: '单曲'
          }, {
            key: 'channel'
            , name: '兆赫'
          }, {
            key: 'songlist'
            , name: '歌单'
          }]}></TypeFilter> : null}

        <div className="results">
          {this.state.q ?
            searchResults
            :
            <DefaultBlock
              history={app.searchHistory.get()}
              onQuery={this.onSearch.bind(this)}></DefaultBlock>
          }
        </div>
      </div>
  }

}
