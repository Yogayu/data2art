import React from "react"
import Button from 'components/button'

function GreenButton(props) {

  return <Button
    color={'#fff'}
    borderColor={'#4ca85d'}
    height={40}
    style={{
      background: '#59b36a'
      , margin: '0 15px'
      , width: 128
      , textAlign: 'center'
      , fontSize: 13
    }}

    {...props}
  ></Button>

}

export default class EmptyView extends React.Component {

  goLogin(e) {
    window.app.showLogin()
  }

  goRegister(e) {
    window.app.showLogin(true)
  }

  render () {
    return <div
      className="conatiner"
      style={{
        width: 800
        , margin: '0 auto'
        , marginTop: '10%'
        , textAlign: 'center'
      }}
    >
      <div className="btns">
        <GreenButton onClick={this.goLogin.bind(this)}>登 录</GreenButton>
        <GreenButton onClick={this.goRegister.bind(this)}>注 册</GreenButton>
      </div>

      <p style={{
        fontSize: 13
        , color: '#7c7b82'
        , marginTop: 30
      }}>{this.props.children}</p>
    </div>
  }

}
