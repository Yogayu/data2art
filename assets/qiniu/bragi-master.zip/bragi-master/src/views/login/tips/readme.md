This folder contains `Login` and `Nologin` tips
