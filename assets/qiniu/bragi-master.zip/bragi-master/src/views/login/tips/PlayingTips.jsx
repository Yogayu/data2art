import React from 'react'

function Link (props) {
  return <a onClick={function (e) {
    e.preventDefault()
    props.onClick()
  }} href="" style={{
    color: '#2f9842'
  }}>{props.children}</a>
}

let typoify = (...configs) => {
  return configs.map(([n, fn]) => {
    if(n) {
      return fn.call(null, n)
    }
    return null
  }).filter((n) => {
    return !!n
  }).join(' ')
}

export default function NoLoginTips(props) {
  let redHeartCount = props.redHeartCount
  , likedArtistsCount = props.likedArtistsCount

  return <div style={{
    height: 36
    , lineHeight: '36px'
    , borderRadius: 2
    , backgroundColor: '#e7e7e7'
    , display: 'inline-block'

    // , position: 'absolute'
    // , top: '50%'
    // , marginTop: 180

    , padding: '0 12px'

    , color: '#4a4a4a'
    , fontSize: 13
    , fontWeight: 500
  }}>
    <Link onClick={() => window.app.showLogin()}>登录</Link> / <Link
      onClick={() => window.app.showLogin(true)}
    >注册</Link> 后豆瓣FM将永久保留你的
    {typoify(
      [redHeartCount, (n) => `${n}首红心歌曲`]
      , [likedArtistsCount, (n) => `${n}个艺术家`]
    ) || '收听历史与喜好'}
  </div>
}
