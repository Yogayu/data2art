// it's a full Controlled Login Dialog which means it will handle login logical itself
// 1. one instance

import React from 'react'
import Dlg from 'components/dialog/simple'
import Login from './index'
import {IconClose} from 'icons'
import douradio from 'douradio'

export default class LoginDialog extends React.Component {
  // Dialog Controller

  constructor(props) {
    super(props)
    this.state = {close: false}
  }

  onClose() {
    // this function will play a close animation and then really close the dialog
    this.setState({
      close: true
    })

    window.setTimeout(() => {
      // hide overlay after animation is done
      window.app.root.hideOverlay('login')
    }, 200)
  }

  onLoginSuccess() {
    // force `getCurrentUser`
    return douradio.getCurrentUser(true)
    // what will do after login success?
  }

  render() {
    return <Dlg isClose={this.state.close}>
      <IconClose
        hasCircle={false}
        color={'#62646c'}
        size={18}
        style={{
          position: 'absolute'
          , right: 17
          , top: 17
        }}
        onClick={this.onClose.bind(this)}
      ></IconClose>

      <Login
        height={392}
        onFinish={this.onClose.bind(this)}
        onLoginSuccess={this.onLoginSuccess.bind(this)}
        register={this.props.register}
      ></Login>
  </Dlg>
  }

}
