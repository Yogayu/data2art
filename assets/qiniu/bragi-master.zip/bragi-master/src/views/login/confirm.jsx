// L`ogin Con'firm
import styles from './confirm.module.css'
import request from 'utils/request'
import React from 'react'
import douradio from 'douradio'

const animationDuration = 1

class LoadingProgress extends React.Component {

  componentDidMount() {
    window.setTimeout(() => {
      this.props.onSuccess()
    }, animationDuration * 1000 + 100)
  }

  render() {
    return <div style={{
      marginTop: 70
      , padding: '0px 97px'
    }}>
      <div className={styles.progress}>
        <div className={styles.progressInner} style={{
          animationDuration: `${animationDuration}s`
        }}></div>
      </div>

      <p>导入中...</p>
    </div>
  }

}

function ifText (value, fn) {
  if(value) {
    return fn.call(null, value)
  } else {
    return ''
  }
}

export default class LoginConfirm extends React.Component {

  constructor(props) {
    super(props)
    this.state = {progress: false}
  }

  onConfirm(e) {
    e.preventDefault()

    request({
      url: 'transfer_anonymous_data'
      , method: 'post'
    })

    this.setState({progress: true})
  }

  onSuccess() {
    // call this after animation is done
    this.props.onSuccess()
  }

  onCancel(e) {
    e.preventDefault()

    // 不保留匿名播放记录
    request({
      url: 'delete_anonymous_data'
      , method: 'post'
    })

    this.props.onCancel()
  }

  render() {
    return <div style={{
      textAlign: 'center'
      , background: 'white'
      , width: 478
      , height: 384

      , padding: '60px 39px 0 39px'
      , boxSizing: 'border-box'
    }}>
      <h1 className={styles.confirmTitle}>还想保留登录之前的收听历史吗？</h1>

      <p style={{marginTop: 20, fontSize: 14, color: '#8f8e94'}}>
        {[
          ifText(douradio.userinfo('liked_num'), (s) => `标记了${s}首红心歌曲`)
          , ifText(douradio.userinfo('banned_num'), (s) => `${s}首不再收听`)
          , ifText(douradio.userinfo('fav_artist_count'), (s) => `喜欢了${s}个艺术家`)
          , ifText(douradio.userinfo('channel_collected_num'), (s) => `收藏了${s}个兆赫`)
          , ifText(douradio.userinfo('programme_collected_num'), (s) => `收藏了${s}个歌单`)
        ].filter((x) => !!x).join(',')}
      </p>

      {this.state.progress ? <LoadingProgress
        onSuccess={this.onSuccess.bind(this)}
      ></LoadingProgress>
      : <div className="buttonGroup" style={{marginTop: 40}}>
        <div className="button-group" onClick={this.onConfirm.bind(this)}>
          <a href="#" className={styles.flatButton}>保留</a>
        </div>

        <div style={{marginTop: 20}}>
          <a onClick={this.onCancel.bind(this)} href="#" className={styles.flatButtonGrey}>不保留</a>
        </div>
      </div>}
    </div>
  }

}
