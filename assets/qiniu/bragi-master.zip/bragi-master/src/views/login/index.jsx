import React from 'react'
// import ReactDOM from 'react-dom'

import Confirm from './confirm'
import isObject from 'lodash/isObject'

let nof = function () {}

/**
 */
export default class LoginPage extends React.Component {
  // onLogin(userinfo)
  static defaultProps = {
    // height: 530
    // , width: 478
    // src: 'http://doubandev2.intra.douban.com:7878/popup/login?source=fm&use_post_message'
    // src: 'http://dae-pre53.dapps.douban.com/popup/login?use_post_message&source=fm'
    src: 'https://accounts.douban.com/popup/login?source=fm&use_post_message'

    // this method will be call after the login page has finish it's job
    , onFinish: nof

    // this method will be call after a user successfully login, but the login page didn't finish all it's job
    , onLoginSuccess: nof

    , register: false
  }

  constructor(props) {
    super(props)
    this.state = {
      needConfirm: false
      , width: this.props.width || 480
      , height: this.props.height || 480
    }
    this.onMessage = this.onMessage.bind(this)
  }

  onMessage(event) {
    if(isObject(event.data)) {
      if(event.data.type === 'resize') {
        // set iframe size
        let {width, height} = event.data.data
        this.setState({width, height})
      }
    }

    if(event.origin) {
      if(event.data == "LoginSuccess") {
        this.setState({needConfirm: true})
        this.props.onLoginSuccess()
      }
    }
  }

  onFinish() {
    this.props.onFinish()
  }

  componentDidMount() {
    // let node = ReactDOM.findDOMNode(this)
    window.addEventListener("message", this.onMessage, false)
  }

  componentWillUnmount() {
    window.removeEventListener("message", this.onMessage)
  }

  render() {
    if(this.state.needConfirm) {
      return <Confirm
        onSuccess={this.onFinish.bind(this)}
        onCancel={this.onFinish.bind(this)}></Confirm>
    }

    return <iframe
      {...this.props}
      src={
        this.props.src + (this.props.register ? '#popup_register' : '#popup_login')
      }
      width={this.state.width}
      height={this.state.height}
      frameBorder="0"
    ></iframe>
  }

}
