import "./share.scss"

import React from "react"
import douradio from "douradio"
import QRCode from "ui/qrcode"
import ShareKit from "./sharekit"
import Cover from "components/cover"
import Tooltip from "components/tooltip"
// import Clipboard from 'clipboard'
import Icon from "ui/icon"
import urlWithSource from "./urlWithSource"

const KIND_CHANNEL = 3072
const KIND_SONGLIST = 4006
const KIND_SONG = 3043
const KIND_ARTIST = 5500

// this must be call by Click
const copySelectedText = () => {
  let successed
  try {
    successed = document.execCommand('copy')
  } catch (err) {
    successed = false
  }
  return successed
}

class CopyableUrl extends React.Component {

  static defaultProps = {
    visiable: false
    , url: 'http://douban.fm/'
  }

  constructor(props) {
    super(props)
  }

  onSelect(e) {
    // this.refs.input.focus()
    this.refs.input.select()
    //return this.refs.input.setSelectionRange(0, this.props.url.length)
  }

  render() {
    let {url} = this.props
    return <div
      className="copyable-input"
      onClick={this.onSelect.bind(this)}
      style={this.props.visiable ? {
        marginLeft: 24
      } : {
        width: 1
        , height: 1
        , overflow: 'hidden'
        , display: 'inline-block'
      }}
    >
      <i className="icon-copy"></i>
      <input ref="input" type="text" defaultValue={url} onFocus={this.onSelect.bind(this)} />
    </div>
  }
}

class ShareDialog extends React.Component {

  constructor() {
    super()
    this.state = {
      tooltip: null
      , displayInput: false
    }
  }

  componentWillUnmount() {
    if(this.tooltipHandler) {
      window.clearTimeout(this.tooltipHandler)
      this.tooltipHandler = null
    }
  }

  static defaultProps = {
    title: '{SongName} - {Artist}'
    , subtitle: null
    , coverSrc: ''
    , coverRounded: true
    , url: 'http://douban.fm/'
  }

  share(target, e) {
    e.preventDefault()
    this.props.onShare(target)
  }

  preventClick(e) {
    e.preventDefault()
    e.stopPropagation()
  }

  /**
   * display a tooltip on the top of an element(target)
   * by default, it's the oncopy button
   * @param  {ReactElement|String} message to display
   * @param  {DOMNode} dom node
   */
  displayTooltip(message, target) {
    const TIMEOUT = 3000

    if(!target) {
      target = this.refs.buttoncopy
    }
    // position should be the /top, center/ corner of one element
    let pos = {
      x: target.offsetLeft + target.offsetWidth / 2
      , y: target.offsetTop
    }

    if(this.tooltipHandler) {
      window.clearTimeout(this.tooltipHandler)
      this.tooltipHandler = null
    }

    this.setState({
      tooltip: message
      , tooltipPosition: pos
    })

    this.tooltipHandler = window.setTimeout(() => {
      this.setState({
        tooltip: null
      })
    }, TIMEOUT)
  }

  onCopy(e) {
    this.refs.urlInput.onSelect()
    if(copySelectedText()) {
      this.displayTooltip('已复制')
    } else {
      this.displayTooltip('请按 Ctrl + C 拷贝下面的链接')
      this.setState({
        displayInput: true
      })
    }
  }

  render() {
    let {url, title, subtitle} = this.props
    // <QRCodeBox url={this.props.url}></QRCodeBox>

    let shareItem
    if(title && subtitle) {
      shareItem = <div className="share-item">
        <Cover
          className='item-cover'
          size={this.props.coverRounded ? 48 : 42}
          src={this.props.coverSrc}
          rounded={this.props.coverRounded}
        ></Cover>
        <div className="titles">
          <h3 className="title">{title}</h3>
          <p className="subtitle">{subtitle}</p>
        </div>
      </div>
    } else {
      // Only share channel
      shareItem = <div className="share-item">
        <h3 className="primary">
          {title} <span className="mhz-identity">MHz</span>
        </h3>
      </div>
    }

    return <div
      className="share-dialog"
      onClick={this.preventClick.bind(this)}
      style={{
        top: this.props.y
        , left: this.props.x
        , position: 'fixed'
      }}
    >
      <div className="inner">
        {shareItem}
        <div className="qrcode-wrapper">
          <QRCode height={120} width={120} text={urlWithSource(url, 'qrcode')}></QRCode>
          <p className="desc">扫码分享到微信</p>
        </div>

        <div className="services">
          {['douban', 'weibo', 'qq', 'copy'].map((key) => {
            let action
            if(key === 'copy') {
              action = this.onCopy.bind(this)
            } else {
              action = this.share.bind(this, key)
            }
            return <a
              href={url}
              onClick={action}
              key={key}
              ref={'button' + key}
              className={'share-' + key}>
              <Icon i={'share-' + key} size={30}></Icon>
            </a>
          })}
        </div>

        <Tooltip
          visiable={!!this.state.tooltip}
          {...this.state.tooltipPosition}>{this.state.tooltip}</Tooltip>

        <CopyableUrl
          ref={'urlInput'}
          visiable={!!this.state.displayInput}
          url={url}></CopyableUrl>

      </div>
    </div>
  }
}


export default new (class ShareService {

  constructor() {
    this.shareKit = new ShareKit({
      weibo: {
        appkey: '3163308509',
        ralateUid: '1665581307'
      },
      douban: {
        apikey: '079055d6a0d5ddf816b10183e28199e8',
        target_type: 'rec',
        target_action: 0,
        // object_kind: KIND_CHANNEL,
      },
      qq: {
        site: '豆瓣FM'
      },
      tencent: {
        appkey:801227714,
        site: 'douban'
      }
    })
  }

  onShare(info, service) {
    // close the dialog or not?
    app.root.hideOverlay('share')
    info.href = urlWithSource(info.href, service)

    if(service === 'weibo') {
      return this.shareKit.share('weibo', {
        title: info.text,
        url: info.href,
        pic: info.image,
      })
    } else if (service === 'qq') {
      return this.shareKit.share('qq', {
        url: info.href,
        pics: info.image,
        desc: `${info.text} - 来自${this.getSource()}`,
        summary: info.desc,
        site: '豆瓣FM'
      })
    } else {
      // FIXME: hack for FM's 7th anniversary
      let startDate = new Date('2016/11/4')
        , endDate = new Date('2016/11/7 12:00:00')
        , now = new Date(Date.now());

      let text = now >= startDate && now <= endDate ? '#豆瓣FM七周年# ' : '';
      // ENDFIXME
      return this.shareKit.share(
        'douban',
        Object.assign({}, info, {text: text})
      )
    }
  }

  render(props) {
    return {
      type: ShareDialog
      , props: props
    }
    // return app.root.displayOverlay(<ShareDialog
    //   {...props}
    //   onClose={app.root.hideOverlay.bind(app.root)}
    // ></ShareDialog>)
  }

  getSource() {
    return douradio.isPro() ? '豆瓣FM PRO' : '豆瓣FM'
  }

  shareSong(song, playlist) {
    let plName = playlist ? playlist.getTitle() : ''
    , url = song.shareUrl()

    let obj = {
      name: song.get('title'),
      href: url,
      image: song.get('picture'),
      text: `分享 ${song.get('artist')} 的单曲《${song.get('title')}》`,
      desc:`(来自${this.getSource()} ${plName})`,
      object_kind: KIND_SONG,
      object_id: song.id,
      action_props: JSON.stringify({
        "url": url,
        "title": song.get('title'),
        "artist": song.get('artist'),
        "curl": playlist ? playlist.shareUrl() : 'http://douban.fm/'
      })
    }

    // dialog info
    return this.render({
      title: `${song.get('title')} - ${song.get('artist')}`
      , subtitle: '单曲'
      , url: obj.href
      , coverSrc: song.get('picture')
      , coverRounded: false
      , onShare: this.onShare.bind(this, obj)
    })
  }

  getChannelInfo(chlModel) {
    let channel_url = chlModel.shareUrl()
    , channel = chlModel.info

    return {
      name: channel.name,
      desc: channel.intro,
      text: `分享兆赫 《${channel.name}》`,
      href: channel_url,
      image: channel.cover,
      object_kind: KIND_CHANNEL,
      object_id: Math.max(0, channel.id),
      action_props: JSON.stringify({
        channel_url: channel_url,
        channel_title: channel.name + ' - ' + this.getSource()
      })
    }
  }

  getSonglistInfo(sl) {
    let songlist_url = sl.shareUrl()
    , songlist = sl.info

    return {
      name: songlist.title,
      desc: songlist.description,
      text: `分享${songlist.creator.name}的歌单 《${songlist.title}》`,
      href: songlist_url,
      image: songlist.cover,
      object_kind: KIND_SONGLIST,
      object_id: songlist.id,
      action_props: JSON.stringify({
        songlist_url: songlist_url,
        songlist_owner: songlist.creator.name,
        songlist_title: songlist.title
      })
    }
  }

  sharePlaylist(pl) {
    let obj
    let info = {
      title: pl.getTitle()
      , url: pl.shareUrl()
      , coverRounded: false
    }

    if(pl.isChannel()) {
      obj = this.getChannelInfo(pl)
    } else {
      obj = this.getSonglistInfo(pl)
      info.subtitle = '歌单'
      info.coverSrc = pl.info.cover
    }

    info.onShare = this.onShare.bind(this, obj)

    return this.render(info)
  }

  shareArtist(ar) {
    let url = ar.shareUrl()
    let obj = {
      name: ar.get('name_usual'),
      href: url,
      image: ar.get('avatar'),
      text: `分享艺术家 - ${ar.get('name_usual')}`,
      desc:`(来自${this.getSource()})`,
      // object_kind: KIND_ARTIST,
      // object_id: ar.id,
      // object_kind: KIND_CHANNEL,
      // object_id: ar.related,
      // action_props: JSON.stringify({
      //   "channel_url": url,
      //   "channel_title": ar.get('name_usual')
      // })
    }

    // artist
    return this.render({
      title: ar.get('name_usual')
      , subtitle: '艺术家'
      , url: url
      , coverSrc: ar.get('avatar')
      , coverRounded: true
      , onShare: this.onShare.bind(this, obj)
    })
  }
})
