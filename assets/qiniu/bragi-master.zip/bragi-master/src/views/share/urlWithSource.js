export default function urlWithSource (url, source) {
  if(url.indexOf('?') > 0) {
    return `${url}&from_=${source}`
  } else {
    return `${url}?from_=${source}`
  }
}
