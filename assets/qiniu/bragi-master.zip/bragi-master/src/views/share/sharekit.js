import extend from "lodash/extend"
import map from "lodash/map"
import clone from "lodash/clone"
import merge from "lodash/merge"

const defaultOptions = {
  qq: {
    baseurl: 'http://connect.qq.com/widget/shareqq/index.html',
    height: 627,
    width: 805
  },
  weibo: {
    baseurl: 'http://service.weibo.com/share/share.php',
    height: 520,
    width: 650
  },
  douban: {
    baseurl: 'http://www.douban.com/share/recommend'
  },
  renren: {
    baseurl: 'http://widget.renren.com/dialog/share'
  },
  tencent: {
    baseurl: 'http://share.v.t.qq.com/index.php',
    c: 'share',
    a: 'index'
  }
}

export default class DoubanShareKit {

  constructor(options) {
    this.options = merge(defaultOptions, options)
  }

  buildUrl(baseUrl, params) {
    return baseUrl + '?' + map(params, (v, k) => {
      return encodeURIComponent(k) + '=' + encodeURIComponent(v)
    }).join('&')
  }

  openWindow(url, options = {}) {
    options = extend({
      width: 600,
      height: 300
    }, options)

    let top = (screen.height - options.height) / 2
    , left = (screen.width - options.width) / 2
    , win = window.open(url, 'fm', map({
      toolbar: 0,
      status: 0,
      resizeable: 1,
      width: options.width,
      height: options.height,
      left: left,
      top: top
    }, (value, key) => {
      return key + '=' + value
    }).join(','))
    if(win) {
      win.focus()
    }
  }

  share(target, options) {
    let defaultOptions = this.options[target] || {}
    options = extend(defaultOptions, options)
    if(!this[target]) {
      let clonedOptions = clone(options)
      , {width, height, baseurl} = clonedOptions
      delete clonedOptions['width']
      delete clonedOptions['height']
      delete clonedOptions['baseurl']
      let url = this.buildUrl(baseurl, clonedOptions)
      this.openWindow(url, {
        width: width || 600,
        height: height || 300
      })
    } else {
      this[target].call(this, options)
    }
  }
}
