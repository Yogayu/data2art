import "./push.scss"

// push
import Overlay from "ui/overlay"
import React from "react"
import QRCode from "ui/qrcode"
import request from "utils/request"
import Cover from "components/cover"
import without from "lodash/without"

import IconAngle from 'icons/icon-angle'
import IconQRCode from 'icons/icon-qrcode'



class QRBox extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      showqr: false
    }
  }

  toggleQRCode() {
    this.setState({
      showqr: !this.state.showqr
    })
  }

  render() {
    let song = this.props.song

    return <div className="qrbox">
      <div className="desc" onClick={this.toggleQRCode.bind(this)}>
        <IconQRCode></IconQRCode>
        &nbsp;
        扫码离线这首歌
        {this.state.showqr ?
          <IconAngle direction={'top'}></IconAngle>
            : <IconAngle direction="bottom"></IconAngle>}
      </div>
      {this.state.showqr ?  <div>
        <QRCode height={94} width={94} text={song.shareUrl(true)}>
          <Cover size={20} src={song.get('picture')}></Cover>
        </QRCode>
        <p>
          打开豆瓣FM　App<br />
          进入搜索页面后扫码离线
        </p>
      </div> : null}
    </div>
  }
}

const FM_APP_QRCODE = "http://img3.douban.com/f/fm/3e0da79f7fe1a8c27dd48c40fbbba848c1399f3d/pics/fm/landingpage/qr.png"

function AppBox (props) {
  return <div style={{
    textAlign: 'center'
  }}>
    <h3 className="box-title">立即下载 App 离线歌曲</h3>
    <img
      className="fm-qrcode"
      src={FM_APP_QRCODE}
      alt="fm-app"
      height={94}
      width={94} />
  </div>
}

export default class PushBox extends React.Component {

  static defaultProps = {
    x: '50%'
    , y: '10%'
  }

  constructor(props) {
    super(props)
    this.state = {devices: []}
  }

  componentWillMount() {
    // test utils
    // return require(['./test-data'], (data) => {
    //   this.setState({
    //     devices: data.devices
    //   })
    // })

    this.request = request({
      url: '/j/song_to_phone/get_devices?category=prod'
    }).then(({devices}) => {
      if(!this.request) {
        // component already unmounted
        return
      }

      this.setState({
        devices: devices
      })
    })
  }

  componentWillUnmount() {
    this.request = null
  }

  toggleSelect(device) {
    return this.send(device).then(() => {
      device.selected = true
      device.tips = true

      window.setTimeout(() => {
        device.tips = false
        this.forceUpdate()
      }, 2000)

      return this.forceUpdate()
    })
  }

  send(device) {
    return request({
      url: '/j/song_to_phone/send'
      , method: 'post'
      , data: {
        token: device.token
        , udid: device.udid
        , apikey: device.apikey
        , song_id: this.props.song.id
        , category: 'prod'
      }
    })
  }

  onDelete(device, e) {
    e.preventDefault()
    e.stopPropagation()
    let confirmed = window.confirm('确定删除设备?')

    if(confirmed) {
      request({
        url: 'notification/deactivate'
        , method: 'post'
        , data: {
          device_token: device.token
        , apikey: device.apikey
        , udid: device.udid
        }
      }).then(() => {
        let devices = without(this.state.devices, device)
        this.setState({
          devices: devices
        })
      })
    }
  }

  render() {
    let hasDevice = this.state.devices && this.state.devices.length > 0

    return <Overlay
      className="push-dialog"
      {...this.props}>
      <div className="push-box">
        {hasDevice ? <div>
          <h3 className="box-title">离线歌曲到以下设备</h3>
          <ul>{this.state.devices.map((device) => {
            return <li key={device.id} onClick={this.toggleSelect.bind(this, device)}>
              <h3 className="title">{device.name}</h3>
              <p>{device.model} - {device.model} - {device.os_version}</p>
              {!!device.tips ?
                <span className="tips">已发送</span> : <a
                  onClick={this.onDelete.bind(this, device)}
                  className="delete">删除</a>}
            </li>
          })}</ul>
        </div> : <AppBox></AppBox>}
        <div className="line"><span>or</span></div>
        <QRBox song={this.props.song}></QRBox>
      </div>
    </Overlay>
  }

}
