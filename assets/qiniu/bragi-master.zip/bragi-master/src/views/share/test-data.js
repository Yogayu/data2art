module.exports = {
  devices: [
    {
      user_id: "2419751",
      name: "Keith的 iPad",
      udid: "0000000000000000000000000000000000000000",
      os_version: "8.3",
      token: "3e54eb9064a538e41646bc3a0d65f7685b90fda07c7deb60984121cfcc64dbce",
      create_time: "2014-11-13 00:26:41",
      model: "iPad",
      app_version: "401051",
      id: "2622551"
    },
    {
      user_id: "2419751",
      name: "Keith的 iPad",
      udid: "0000000000000000000000000000000000000000",
      os_version: "8.3",
      token: "17818507ccdd630c4f31ec6b0c1ccaa0d800914b745abee65ca1c643fdb0ed46",
      create_time: "2015-05-15 17:48:15",
      model: "iPad",
      app_version: "403000",
      id: "6350101"
    },
    {
      user_id: "2419751",
      name: "Air2",
      udid: "0000000000000000000000000000000000000000",
      os_version: "9.1",
      token: "b691be610ddcb330ef9756d54370c01c17daa3026131c50a11ff1a7341ce3b0e",
      create_time: "2015-10-02 17:58:00",
      model: "iPad",
      app_version: "404000",
      id: "9392935"
    },
    {
      user_id: "2419751",
      name: "KeithDeAir2",
      udid: "0000000000000000000000000000000000000000",
      os_version: "9.1",
      token: "b81b20c2a93dc8ba4a2c6ff26294d1a62b366448a1e03c97c4ae0ed07efa66d4",
      create_time: "2015-11-19 01:27:27",
      model: "iPad",
      app_version: "404000",
      id: "10562387"
    }
  ]
}
