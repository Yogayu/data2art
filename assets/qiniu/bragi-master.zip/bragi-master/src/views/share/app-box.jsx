import Overlay from "ui/overlay"
import React from 'react'
import IconAngle from 'icons/icon-angle'


export default class AppBox extends React.Component {

  jump() {
    window.open('https://douban.fm/app', '_blank')
  }

  render () {
    let styles = Object.assign({}, this.props.styles || {}, {
      padding: '32px 32px 20px 32px'
      , background: '#fff'
      , textAlign: 'center'
    })

    return <Overlay
      className="push-dialog"
      style={styles}
      {...this.props}
    >
      <div className="push-box">
        <img
          width={135}
          height={135}
          src="https://img3.doubanio.com/f/fm/1e89298732fbf090aea0812f7fb2af30ad82ab61/pics/fm/landingpage/qr_2@2x.png"
          alt=""/>
        <div style={{fontSize: 12, color: '#b1b1b1'}}>iPhone • Android</div>

        <div style={{height: 30}}></div>

        <a style={{
          fontSize: 12
          , color: '#9b9b9b'
        }}
        href="https://douban.fm/app"
        onClick={this.jump.bind(this)}
        target="_blank">
          去了解一下豆瓣FM APP
          <IconAngle direction="right" style={{
            position: 'relative'
            , top: -2
          }}></IconAngle></a>
      </div>
    </Overlay>
  }
}
