import React from "react"
import Wheel from "components/wheel"

import {PlayerView} from "views/playing"
import Explorer from "./explore"
import createFragment from "react-addons-create-fragment"
import PopupManager from "./common/popup-manager"
import log from 'utils/log'

import tooltipGuide from './tooltip-guide'

// full player inline, scroll < player-height
export const PLAYER_INITIAL = 0b00
// mini-player fixed, scroll > player-height
export const PLAYER_MINI = 0b01
// full player fixed, scroll > player-height
export const PLAYER_FIXED = 0b10
export const MINI_PLAYER_HEIGHT = 101

import douradio from 'douradio'
import {NO_PERMISSION_TO_SWITCH_PLAYLIST} from 'douradio/consts'

// async component
class UserGuide extends React.Component {

  constructor(props) {
    super(props)
    this.state = {component: null}
  }

  componentWillMount() {
    // sub app
    require.ensure(['userguide'], (require) => {
      let initUserguide = require('userguide')
      this.setState({component: initUserguide(this.props)})
    })
  }

  render() {
    if(this.state.component) {
      return this.state.component
    } else {
      return null
    }
  }
}

// async component 2


export default class Root extends React.Component {

  constructor(props) {
    super()

    this.state = {
      page: null
      // , message: null
      // , focusExplorer: false
      , ap: 0
      , hasPopup: false

      , showUserGuide: props.showUserGuide
    }

    this.hideOverlay = this.hideOverlay.bind(this)
    this.displayOverlay = this.displayOverlay.bind(this)
    this.displayContextMenu = this.displayContextMenu.bind(this)
    this.hideContextMenu = this.hideContextMenu.bind(this)
  }

  componentDidMount() {
    this.props.router.on('route:search', function (args) {
      this.setPlayerStatus(PLAYER_MINI)

      let query = args ? args.q : null
      require(['views/search'], (SearchPage) => {
        this.displayOverlay(<SearchPage
          q={query}
          onClose={this.hideOverlay.bind(this, 'search')}
        ></SearchPage>, 'search')
      })
    }, this)

    douradio.on(NO_PERMISSION_TO_SWITCH_PLAYLIST, function () {
      log('userguide', 'start_by_click')
      this.setState({showUserGuide: true})
    }, this)
  }

  componentWillUnmount() {
    this.props.router.off(null, null, this)
  }

  componentDidUpdate(prevProps, prevState) {}

  /*
  # display a global tooltip
  #
  # @param {string, React.Component} inner - the message, React Component or
  #        string are supported
  # @param {number} timeout - how long to display the message, in (ms)
  # @return {number}
  */
  displayMessage(inner, timeout = 1000) {
    this.setState({
      message: inner
    })
    return window.setTimeout(() =>
      this.setState({message: null})
    , timeout)
  }

  displayContextMenu(menu) {
    // return this.displayOverlay(menu, 'context-menu')
    return this.displayOverlay(menu)
  }

  hideContextMenu() {
    return this.hideOverlay()
    // return this.hideOverlay('context-menu')
  }

  hideOverlay(name="default") {
    if(!this.state.overlay) {
      return
    }

    if(name === "*") {
      // hide all overlay
      this.state.overlay = {}
    } else {
      if(!this.state.overlay[name]) {
        // not in, just return
        return
      }
      delete this.state.overlay[name]
    }

    this.forceUpdate()
  }

  displayOverlay(element, name="default") {
    // this.prevFragment = Backbone.history.fragment
    if(!this.state.overlay) {
      this.state.overlay = {}
    }
    this.state.overlay[name] = element
    this.forceUpdate()
    // let attr = '-moz-scrollbars-none'
    // document.body.style.overflow = attr
  }

  hasOverlay() {
    return this.state.overlay && this.state.overlay.default
  }

  onWheel() {
    this.hideOverlay('default')
  }

  onClickBody(e) {
    e.preventDefault()
    this.hideOverlay('default')
  }

  hasPopup() {
    let popup = this.refs.popup
    return popup.isActive() || (this.state.overlay && !!this.state.overlay.search)
  }

  closePopup() {
    let popup = this.refs.popup
    return popup.close()
  }

  /**
  * global page navigation
  * @param {ReactElement}
  */
  switchPage(nextPage) {
    // if overlay exists
    // React.cloneElement(this.state.overlay, {hidden: true})
    this.setState({
      page: nextPage
      , overlay: {}
    })
  }

  setPlayerStatus(status) {
    // console.warn('setPlayerStatus:', status)

    if(status === PLAYER_MINI) {
      this.setAp(1)
    } else if(status === PLAYER_INITIAL) {
      this.setAp(0)
    }
  }

  onClickExplorer() {
    this.setAp(1)
    // this.refs.wheel.wheelDown()
  }

  togglePlayer() {
    if(this.getAp() < 0.01) {
      this.setAp(1)
    } else {
      this.setAp(0)
    }
  }

  getGapHeight() {
    return this.refs.wheel.gapHeight
  }

  fullPlayerHeight() {
    return this.refs.wheel.layerHeight
  }

  scrollTo(pos) {
    return this.refs.wheel.scrollTo(pos)
  }

  setAp(ap) {
    return this.refs.wheel.dealWithTargetAp(ap)
  }

  getAp() {
    let ap = this.refs.wheel ? this.refs.wheel.state.ap : 0
    return ap
  }

  onFinishUserguide(showUserTips) {
    if(showUserTips) {
      tooltipGuide.display()
    }

    this.setState({
      showUserGuide: false
    })
  }

  render() {
    if(this.state.showUserGuide) {
      return <UserGuide
        onFinish={this.onFinishUserguide.bind(this)}
      ></UserGuide>
    }

    let hasPopup = this.state.hasPopup
    , ap = this.getAp()

    return <div
      className="app"
      onClick={this.onClickBody.bind(this)}
      onWheel={this.onWheel.bind(this)}
    >
      <Wheel
        ref={'wheel'}
        useFixed={hasPopup}
        cover={<PlayerView
          ref="player"
          className="cl-player"
          togglePlayer={this.togglePlayer.bind(this)}
        ></PlayerView>}
      >
        <Explorer
          router={this.props.router}
          focus={ap === 1}
          onClickExplorer={this.onClickExplorer.bind(this)}
        ></Explorer>
      </Wheel>

      {createFragment(this.state.overlay || {})}

      {this.hasOverlay() ? <div
        onClick={this.onClickBody.bind(this)}
        style={{
          zIndex: 9000
          , position: 'fixed'
          , top: 0
          , left: 0
          , right: 0
          , bottom: 0
        }} className="overlay-clickable"></div> : null}

      <PopupManager
        ref="popup"
        router={this.props.router}
        root={this}
      ></PopupManager>
    </div>
  }
}
