require('./wall.scss')

let React = require('react')
  , douradio = require('douradio')
  , Header = require('../common/header');

//
// # 红心歌单
//
// # [yesterday]
// # [last week]
// # [last month]
// # [last year]
// # 2014
// # 2013
// # 2012

module.exports = React.createClass({

  getInitialState: function () {
    return {songs: [], total: 0};
  },

  componentDidMount: function () {
    douradio.apiClient.request({
      url: 'user_play_record',
      data: {
        type: 'liked',
        start: 0
      }
    }).then((response) => {
      this.setState(response)
    });
  },

  renderSong: function (song) {
    return <div key={song.id} className="song" style={{
      background: "url(" + song.cover + ")"
    }}>
      <i className="icon-heart liked"></i>

      <span className="info">{song.title} - {song.artist}</span>
    </div>
  },

  render: function () {
    return <div className="heart-page">
      <Header douradio={douradio} url="hearts"></Header>
      <div className="heart-wall container">{
          this.state.songs.map(this.renderSong)
      }</div>

    </div>
  }

});
