import "./guide.scss"

import range from "lodash/range"
import classnames from "classnames"

import React from "react"

import IconAngle from "icons/icon-angle"
import Icon from "ui/icon"

import Popup from "ui/popup"

// import 'gsap/TweenLite'
// import 'gsap/TimelineLite'
// import 'gsap/plugins/ScrollToPlugin'
// import 'gsap/easing/EasePack'
// import 'utils/gsap-react-plugin'


class SliderPage extends React.Component {

  componentDidMount() {
  }

  render() {
    return <div className="slider-page">
      <h1>{this.props.title}</h1>
      <img
        width={800}
        src={this.props.img}
        alt={this.props.title}
        style={{
          position: 'absolute'
          , bottom: 2
        }}
      />
    </div>
  }

}


export default class GuideDialog extends React.Component {
  // props.sliders = []
  constructor(props) {
    super(props)
    this.state = {
      i: 0
      , hidden: false
    }
  }

  goToSlider(i) {
    this.setState({
      i: i
    })
  }

  nextShow() {
    this.setState({
      i: this.state.i + 1
    })
  }

  prevShow() {
    this.setState({
      i: this.state.i - 1
    })
  }

  onClose() {
    // this.setState({hidden: true})
    this.props.onClose && this.props.onClose()
  }

  renderPoints(total, current) {
    return <ul className="points">{range(0, total).map((i) => {
      return <li key={i}>
        <i className={
          classnames({'point': true, 'on': current == i})
        }></i>
      </li>
    })}</ul>
  }

  render() {
    const WIDTH = 800

    let root = window.__webpack_public_path__ || '/deploy/'
    , sliders = [{
      title: '红心歌曲，按照喜欢的方式收听'
      , img: root + 'guide/1.png'
    }, {
      title: '有趣主题，动听歌单'
      , img: root + 'guide/2.png'
    }, {
      title: '搜索想听的，听到更好的'
      , img: root + 'guide/3.png'
    }, {
      title: '简单易用，听歌才畅快'
      , img: root + 'guide/4.png'
    }]
    , i = this.state.i
    , hasNext = i < (sliders.length - 1)
    , hasPrev = i > 0

    return <Popup
      onClose={this.onClose.bind(this)}
      baseZIndex={10000}
      hidden={this.state.hidden}
    >
      <div className="guide-dialog">

        <div
          className="wrapper"
        >
          <div
            className="sliders"
            style={{marginLeft: -1 * WIDTH * i}}
          >
            {sliders.map((attrs, i) => {
              return <SliderPage
                key={'slider-' + i}
                {...attrs}
              />
            })}
          </div>

          {hasNext ? this.renderPoints(sliders.length, i)
            : null}

          <button onClick={this.onClose.bind(this)}
            style={hasNext ? {
              opacity: 0
            } : {
              opacity: 1
              , transitionDelay: '0.3s'
            }}
            className="button button-primary">开启新版FM</button>

        </div>

        <a href="#" className={'link-close'} onClick={this.onClose.bind(this)}>
          <Icon i={'close'}></Icon>
        </a>

        {hasNext ?
          <a className="bn bn-next" onClick={this.nextShow.bind(this)}>
            <IconAngle direction="right" size={36} color="#6BBD7A"></IconAngle>
          </a>: null}

        {hasPrev ?
          <a className="bn bn-prev" onClick={this.prevShow.bind(this)}>
            <IconAngle direction="left" size={36} color="#6BBD7A"></IconAngle>
          </a> : null}

      </div>
    </Popup>
  }
}
