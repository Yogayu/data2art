import "views/songlist/dialog-create.scss"
import "./feedback.scss"

import React from "react"
import Dialog from "components/dialog"
import TextArea from "react-textarea-autosize"
import request from "utils/request"


export default class DialogFeedback extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      feedback: this.props.feedback
      , title: ''
    }
  }

  handleCancel() {
    return this.props.onClose()
  }

  handleSubmit() {
    let title = this.refs.title.value
    , content = this.refs.context.value

    this.setState({
      loading: true
    })

    this.handleCancel()
    return request({
      url: 'feedback'
      , data: {
        title: title
        , content: content
      }
      , method: 'post'
    })
  }

  showFeedback() {
    this.setState({
      feedback: true
    })
  }

  onSwitchVersion(e) {
    e.preventDefault()
    location.href = '/account/switch_version?san=0'
  }

  renderChooser() {
    return <Dialog
      showMask={true}
      onClose={this.props.onClose}
      className="dialog-feedback dialog-chooser"
      width={400}
      height={220}
    >
      <button
        className="button button-primary button-green"
        onClick={this.showFeedback.bind(this)}
      >我要吐槽</button>

      <button
        className="button button-primary button-grey"
        onClick={this.onSwitchVersion.bind(this)}
      >直接回旧版</button>
    </Dialog>
  }

  onChange(e) {
    return this.setState({
      title: this.refs.title.value
      , context: this.refs.context.value
    })
  }

  render() {

    if(!this.state.feedback) {
      return this.renderChooser()
    }

    let ftr = <div className="controls">
      {this.state.title || this.state.context ?
        <button
          className="button button-submit fr"
          type="submit"
          onClick={this.handleSubmit.bind(this)}>提交
        </button> : <button
          className="button button-submit button-disable fr"
          type="submit"
        >
          提交
        </button>
      }
      <button onClick={this.handleCancel.bind(this)} className="button fr" type="cancel">取消</button>
    </div>

    return <Dialog
      baseZIndex={20000}
      title={'我要吐槽'}
      showMask={true}
      width={660}
      height={443}
      onClose={this.props.onClose}
      footer={ftr}
      className="dialog-feedback"
    >
      <form className="pure-form pure-form-stacked form-popup" onSubmit={this.handleSubmit.bind(this)}>
        <fieldset className="pure-group field-group">
          <input
            ref="title"
            type="text"
            name="title"
            placeholder="标题"
            maxLength={40}
            value={this.state.title}
            onChange={this.onChange.bind(this)}
          />
          <TextArea
            ref="context"
            name="context"
            placeholder="有什么槽想吐呢？不说出来多难受啊..."
            onChange={this.onChange.bind(this)}
            cols={30}
            rows={5}
          ></TextArea>
        </fieldset>
      </form>
    </Dialog>
  }

}
