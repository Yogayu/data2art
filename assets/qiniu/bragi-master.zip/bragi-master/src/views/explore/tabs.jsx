import React from "react"

let NavList = ({onClick, tabs, className="nav", currentTab}) => {
  return <ul className={className}>{tabs.map((tab, index) => {
    let href = '#', title, isCurrent = (tab == currentTab)
    if(typeof tab === 'string') {
      title = tab
    } else {
      href = tab.href
      title = tab.title
    }
    return <li key={'tab-' + index} className={isCurrent ? 'active' : null}>
      <a href={href} onClick={onClick.bind(null, tab, index)}>{title}</a>
    </li>
  })}</ul>
}

export class NavTabs extends React.Component {

  static defaultProps = {
    tabs: [],
    currentTab: null
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  onClick(tab, index, e) {
    e.preventDefault()
    return this.props.onSwitch(tab)
  }

  render() {
    return <NavList
      className="nav nav-tabs"
      onClick={this.onClick.bind(this)}
      tabs={this.props.tabs}
      currentTab={this.props.currentTab}
    ></NavList>
  }
}


export class DropdownNav extends NavTabs {
  constructor(props) {
    super(props)
    this.state = {
      fold: true
    }
  }

  onUnfold(e) {
    e.preventDefault()
    this.setState({
      fold: false
    })
  }

  onClick(tab, index, e) {
    e.preventDefault()
    this.setState({fold: true})
    return this.props.onSwitch(tab)
  }

  render() {
    return <div className="nav" style={{
      position: 'fixed'
      , left: 0
      , right: 0
      , top: 120
      , height: 54
      , lineHeight: '54px'
      , fontSize: 14
      , color: '#45A156'
      , background: 'rgba(255, 255, 255, 1)'
    }}>
      <div
        style={{width: 1024}}
        className="container"
      >
        {this.state.fold ? <a
          onClick={this.onUnfold.bind(this)}
          className="" href="#"
        >
          {this.props.currentTab.title}
          <i className="icon-angle-down"></i>
        </a> : <NavList
          className="nav nav-dropdown"
          onClick={this.onClick.bind(this)}
          tabs={this.props.tabs}
          currentTab={this.props.currentTab}
        ></NavList>}
      </div>
    </div>
  }

}
