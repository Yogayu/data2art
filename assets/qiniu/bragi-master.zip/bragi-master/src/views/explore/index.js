// this is for the new design
import React from "react"
import {ExploreChannels} from "./channels"
import ExploreSonglists from "./songlists"
import SectionSwitcher from "ui/section-switcher"
// import mixin from 'utils/mixins'
// import PureRenderMixin from 'react/lib/ReactComponentWithPureRenderMixin'
import shallowCompare from "react/lib/shallowCompare"
import MinePage from "views/mine"
import classnames from "classnames"
import Icon from "ui/icon"

// logger for explore
function log(action, label, value) {
  // console.log('send-event-explore:',Array.prototype.join.call(arguments, ' '))
  return ga('send', 'event', 'explore', action, label, value)
}

export default class Explorer extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      page : null
      , currentIndex: null
    }

    this.sections = [{
      component: ExploreChannels
      , title: '兆赫'
      , url: 'explore/channels'
      , name: 'channels'
    }, {
      component: ExploreSonglists
      , title: '歌单'
      , url: 'explore/songlists'
      , name: 'songlists'
    }, {
      component: MinePage
      , title: '我的FM'
      , url: 'mine'
      , name: 'mine'
    }]
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.focus && this.state.currentIndex === null) {
      // console.log('currentIndex')
      this._switchPage(0)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  _switchPage(index, subpage=null) {
    let section = this.sections[index]

    // swtich 2 mini player
    this.props.onClickExplorer()
    log('explore', 'SwitchPage', section.name)

    // inspect
    this.setState({
      page: React.createElement(section.component, {
        subpage: subpage
      })
      , currentIndex: index
    })
  }

  componentDidMount() {
    this.sections.map((section, sectionIndex) => {
      this.props.router.on(
        `route:${section.name}`,
        this._switchPage.bind(this, sectionIndex),
        this)
    })
  }

  componentWillUnmount() {
    this.props.router.off(null, null, this)
  }

  onSwitch(section) {
    // Switch Channel
    window.app.navigate(
      section.url,
      {trigger: true}
    )
  }

  onSearch(e) {
    e.preventDefault()
    window.app.navigate("search", {trigger: true})
  }

  render() {
    let cls = classnames('section-switcher', 'section-switcher-explore', {
      'focus': this.props.focus
    })

    return <div className="page-explorer" style={this.props.style || {}}>
      <SectionSwitcher
        onSwitch={this.onSwitch}
        className={cls}
        sections={this.sections}
        page={this.state.page}
        currentIndex={this.state.currentIndex}
      >
        <li className="section-search" key="section-search">
          <a
            onClick={this.onSearch.bind(this)}
            href="#search">
            <Icon i={"search"}></Icon>
          </a>
        </li>
      </SectionSwitcher>
    </div>
  }
}
