import "./songlists.scss"

import React from "react"
import douradio from "douradio"
import request from "utils/request"
import {NavTabs, } from "./tabs"
import shallowCompare from "react/lib/shallowCompare"
import Cover from "components/cover"
import classnames from "classnames"
import IconHeart from "icons/icon-heart"
import Loading from "ui/loading"
import DailySonglistCover from "views/songlist/daily-songlist-cover"
import {getScrollY} from "utils/domutils"
import PlaceHolder, { PlaceHolderAlbumCover } from 'components/place-holder'

import range from "lodash/range"

function log(action, label, value) {
  // console.log('send-event-explore:',Array.prototype.join.call(arguments, ' '))
  return ga('send', 'event', 'explore', action, label, value)
}

export class Songlist extends React.Component {

  onPlay(e) {
    e.preventDefault()
    let songlistId = this.props.songlist.id

    log('SonglistPlay', null, songlistId)
    // play the SongList
    return douradio.switchSonglist(songlistId)
  }

  onOpenSonglist(e) {
    e.preventDefault()
    let songlistId = this.props.songlist.id

    log('SonglistTitleSel', null, songlistId)

    window.app.navigate(
      '/songlist/' + songlistId,
       {trigger: true}
     )
  }

  componentDidMount() {
    douradio.on('switch_songlist switch_channel', function () {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  render() {
    let sl = this.props.songlist

    let creatorAvatar = sl.creator.picture
     || "http://img3.douban.com/icon/u" + sl.creator.id + ".jpg"

    let sampleSongs = sl.sample_songs || []
    , isPlaying = (
      douradio._playlist
      && !douradio._playlist.isChannel()
      && douradio._playlist.id == sl.id
    )
    , isUserDaily = (sl.id == 'user_daily' || sl.type == 1)

    return <li className="explore-songlist">
      {isUserDaily ? <DailySonglistCover
        size={144}
        src={sl.cover}
        onPlay={this.onPlay.bind(this)}
        isPlaying={isPlaying}
      ></DailySonglistCover> : <Cover
        size={144}
        src={sl.cover}
        onPlay={this.onPlay.bind(this)}
        isPlaying={isPlaying}
      ></Cover>}

      <div className="content">
        <h3 onClick={this.onOpenSonglist.bind(this)}>{sl.title}</h3>
        <p>
          <i className="creator-avatar" style={{
            backgroundImage: 'url(' + creatorAvatar + ')'
          }}></i>
          <span className="username">{sl.creator.name}</span>
          &nbsp;
          创建
        </p>

        <ul className="sample-songs">{sampleSongs.slice(0, 3).map((song, index) => {
          let isLiked = song.like === '1'
          return <li key={'song-' + song.sid}>
            {song.title + ' - ' + song.artist}
            &nbsp;
            {isLiked ? <IconHeart
              className="icon icon-heart"
              size={7}
              liked={true}
            ></IconHeart> : null}
          </li>
        })}</ul>

        <p className="extra-info">
          曲目 {sl.songs_count}
          &nbsp;
          收藏 {sl.collected_count}
        </p>

      </div>

    </li>
  }
}


class PList extends React.Component {

  static defaultProps = {
    requestCacheTime: 1000 * 60 * 60
    , requestOptions: null
  }

  constructor(props) {
    super(props)
    this.state = {
      songlists: []
    }
  }

  componentWillMount() {
    if(!this.props.requestOptions) {
      return
    }

    this.request = request(
      this.props.requestOptions
      // , this.props.requestCacheTime || 1000 * 60 * 60
    ).then((response) => {
      if(!this.request) {
        return
      }

      let songlists = response.map(function (sl) {
        let isUserDaily = sl.type == 1
        if(isUserDaily) {
          sl.id = 'user_daily'
        }
        return sl
      })

      this.setState({
        songlists: songlists
      })
    })
  }

  componentWillUnmount() {
    if(this.request) {
      this.request.abort && this.request.abort()
      this.request = null
    }

  }

  render() {
    let songlists = this.state.songlists || this.props.songlists

    if(songlists.length === 0) {
      return <div className="items">
        {range(0, 15).map(function () {
          return <li className="explore-songlist">
            <PlaceHolderAlbumCover></PlaceHolderAlbumCover>

            <div style={{
              marginTop: 20
            }}>
              <PlaceHolder
                width={108}
                height={14}
              ></PlaceHolder>
            </div>
          </li>
        })}
      </div>
    }

    return <div className="items">{songlists.map((sl) => {
      return <Songlist key={'songlist-' + sl.id} songlist={sl}></Songlist>
    })}</div>
  }

}

class ExploreSonglists extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      genres: []
      , currentTab: 0
    }
  }

  componentDidMount() {
    // load all genres
    this.request = request({
      url: 'songlist/explore/genres'
    }, 1000 * 60 * 60).then((response) => {
      if(!this.request) {
        this.request = null
        return
      }

      this.setState({
        genres: response.map((genre) => {
          return {
            href: 'genre/' + genre.id
            , title: genre.name
            , id: genre.id
          }
        })
      })
      return this.onSwitchTab(this.state.genres[0])
    })
  }

  componentWillUnmount() {
    this.request = null
  }

  onSwitchTab(tab) {

    log('SonglistSwitchTab', null, tab.title)

    this.props.onSwitchTab(tab)
    return this.setState({
      currentTab: tab
    })
  }

  render() {
    let currentTabId = this.state.currentTab ? this.state.currentTab.id : '-1'

    return <div className="songlists-block" style={{
      paddingTop: this.props.sticky ? 40 : 0
    }}>
      <div className={classnames("nav-place-holder", {
        'fixed': this.props.sticky
      })}>
        <NavTabs
          tabs={this.state.genres}
          onSwitch={::this.onSwitchTab}
          currentTab={this.state.currentTab}
        ></NavTabs>
      </div>

      <PList key={'plist-' + currentTabId} requestOptions={this.state.currentTab ? {
        url: 'songlist/explore'
        , data: {
          "type": 'hot'
          , "genre": currentTabId
          , "limit": 20
          , "sample_cnt": 5
        }
      } : null}></PList>
    </div>
  }

}


export default class PageExploreSonglists extends React.Component {

  constructor(props) {
    super(props)
    this.state = {sticky: false}
    this.onScroll = this.onScroll.bind(this)
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState)
  }

  componentWillMount() {
    window.addEventListener('scroll', this.onScroll)
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll)
  }

  getStickyPosition() {
    // let fph = window.app.root.fullPlayerHeight()
    // return fph - 100 + 62
    return 64
  }

  onScroll(e) {
    let isSticky = getScrollY() > this.getStickyPosition()
    if(this.state.sticky === isSticky) {
      return
    }
    this.setState({
      sticky: isSticky
    })
  }

  onSwitchTab() {
    let root = window.app.root
    , pos = this.getStickyPosition()
    if(getScrollY() > pos) {
      root.scrollTo(pos)
    }
  }

  render() {
    return <div className="container" style={{
      maxWidth: 1024
    }}>
      <ExploreSonglists
        onSwitchTab={this.onSwitchTab.bind(this)}
        sticky={this.state.sticky}
      ></ExploreSonglists>
    </div>
  }

}


export class CollectedSonglists extends React.Component {
  // programme/collection, start, limit
  // 我收藏的歌单

  constructor(props) {
    super(props)
    this.state = {
      collectedSls: []
    }
  }

  componentDidMount() {
    request({
      url: 'programme/collection'
    }, 1000).then((response) => {
      this.setState({
        'collectedSls': response.programmes
      })
    })
  }

  render() {
    return <div className="container block">
      <h1>我收藏的歌单</h1>

      <ul className={'pl-list'}>
      {this.state.collectedSls.map((sl) =>{
        return <li
          key={"songlist-" + sl.id}
          className="link-collected link-songlist-collected">
          <h3>{sl.title}</h3>
          <p>
            曲目 {sl.songs_count}
            &nbsp;
            收藏 {sl.collected_count}
          </p>
          <a onClick={this.toggleCollect} href="#">
            <i className="icon-star"></i> 已收藏
          </a>
          <div className="cover" style={{
            backgroundImage: 'url(' + sl.cover + ')'
          }}></div>
        </li>
      })}
      </ul>
    </div>
  }

}
