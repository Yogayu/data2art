import "./channels.scss"

import request from "utils/request"
import React from "react"
import Loading from "ui/loading"
import TitleWithTooltip from "components/tooltip/TitleWithTooltip"
import douradio from "douradio"
import get from "lodash/get"
import range from "lodash/range"

import {
  Channel
  , TextChannel
  , RoundedChannel
  , SpecialChannel
} from "./channel"

function log(action, label, value) {
  // console.log('send-event-explore:',Array.prototype.join.call(arguments, ' '))
  return ga('send', 'event', 'explore', action, label, value)
}

// let CACHE_TIME = 60 * 60 * 1000


export class ChannelList extends React.Component {

  static defaultProps = {
    channels: null
    , PlaceHolder: 'div'
  }

  constructor(props) {
    super(props)
    this.state = {
      channels: []
      , loading: false
      , limit: this.props.limit || 10
    }
  }

  get channels() {
    return this.props.channels || this.state.channels
  }

  componentDidMount() {
    if(this.props.channels) {
      return
    }

    this.setState({
      loading: true
    })

    this.request = request({
      url: this.props.url
      , data: {}
    }).then((response) => {
      if(!this.request) {
        return console.debug('Component already unmounted!')
      }
      this.request = null

      // channels, total
      if(response.total && response.channels) {
        return this.setState({
          channels: response.channels
          , loading: false
        })
      } else if(response.status){
        return this.setState({
          channels: response.data.channels
          , loading: false
        })
      }
    })
  }

  componentWillUnmount() {
    this.request && this.request.abort && this.request.abort()
    this.request = null
  }

  onLoadMore() {
    let total = this.channels.length
    if(this.state.limit + 10 <= total) {
      this.setState({
        limit: this.state.limit + 10
      })
    } else {
      // need to load
    }
  }

  hasMore() {
    return this.props.showMore && (
      this.state.limit < this.channels.length)
  }

  renderLoading() {
    return range(0, 10).map(i => React.createElement(this.props.ChannelClass, {
      key: 'loading-' + i
      , channel: null
    }))
  }

  render() {
    let channels = this.channels.slice(0, this.state.limit)

    // console.log('Channels', channels)

    if(this.state.isLoading ) {
      return React.createElement(this.props.PlaceHolder, {})
    }

    if(!channels || channels.length === 0) {
      return React.createElement(this.props.EmptyView || 'div', {})
    }

    return <div className={"channels-block " + this.props.className || ""}>
      {this.props.title}
      {this.props.children}
      <ul>
      {channels.size === 0 ? this.renderLoading() : channels.map((channel) => {
        return React.createElement(this.props.ChannelClass, {
          channel: channel
        , key: 'channel-' + channel.id
        , onClick: () => {
            log('ChannelSel', this.props.url)
          }
        })
      })}
      </ul>
      {this.hasMore() ?
        <div className="more">
          <button
            onClick={() => {
              log('ChannelsMore', this.props.url)
              this.onLoadMore()
            }}
            className="button button-more">加载更多兆赫</button>
        </div>
        : null
      }
      <div className="clear"></div>
    </div>
  }

}

export class ExploreChannels extends React.Component {

  // constructor(props) {
  //   super(props)
  // }

  componentDidMount() {
    this.props.requestChannels()
  }

  render() {
    // if(!this.state.channels) {
    //   return <div className="container">
    //     <Loading></Loading>
    //   </div>
    // }
    const getChannels = (k) => {
      return this.props.channels.get(k).toObject()
    }

    return <div className="container" style={{width: 1025}}>
      <div className="specialChannel" style={{
        margin: '10px 0 40px 0'
      }}>
        <SpecialChannel
          hasPermission={douradio.hasPersonalService()}
          channel={{
            id: 0
            , cover: get(douradio, ['options', 'userinfo', 'icon']) || ""
            , name: '我的私人兆赫'
            , description: '豆瓣FM会根据你的喜好来推荐歌曲，让你与喜欢的音乐不期而遇'
          }}
        ></SpecialChannel>

        <SpecialChannel
          channel={{
            id: -10
            , cover: 'https://img3.doubanio.com/f/fm/c1f6362114965225752341e9291a4b2f39f78cfb/pics/fm/channel_selected_cover.png'
            , name: '豆瓣精选兆赫'
            , description: '汇聚各种音乐风格的精选兆赫，从这里开始音乐漫游吧'
          }}
        ></SpecialChannel>

      </div>

      <ChannelList
        ChannelClass={RoundedChannel}
        title={<TitleWithTooltip
          title={'从艺术家出发'}
          tooltip={'包含和该艺术家相似的一些艺术家的歌曲'}
          icon="cat-artist"
        ></TitleWithTooltip>}
        url="rec_channels?specific=artist"
        showMore={true}
        {...getChannels('artist')}
      ></ChannelList>

      <ChannelList
        ChannelClass={Channel}
        title={
          <TitleWithTooltip
            title={'从单曲出发'}
            tooltip={'包含和该单曲相似的一些歌曲'}
            icon="cat-track"
          ></TitleWithTooltip>
        }
        description="播放该首歌及其相似的歌曲"
        url="rec_channels?specific=track"
        showMore={true}
        {...getChannels('track')}
      ></ChannelList>

      <ChannelList
        className="text-channels"
        ChannelClass={TextChannel}
        title={<h3>心情 / 场景</h3>}
        showMore={false}
        url="rec_channels?specific=scenario"
        limit={30}
        {...getChannels('scenario')}
      ></ChannelList>

      <ChannelList
        className="text-channels"
        ChannelClass={TextChannel}
        title={<h3>语言 / 年代</h3>}
        showMore={false}
        url="rec_channels?specific=language"
        limit={30}
        {...getChannels('language')}
      ></ChannelList>

      <ChannelList
        className="text-channels"
        ChannelClass={TextChannel}
        title={<h3>风格 / 流派</h3>}
        showMore={false}
        url="rec_channels?specific=genre"
        limit={30}
        {...getChannels('genre')}
      ></ChannelList>

      <ChannelList
        className="text-channels"
        ChannelClass={TextChannel}
        title={<h3>品牌兆赫</h3>}
        showMore={false}
        url="rec_channels?specific=brand"
        limit={30}
        {...getChannels('brand')}
      ></ChannelList>

    </div>
  }

}
