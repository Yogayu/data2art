import React from "react"
import douradio from "douradio"
import Cover from "components/cover"
import Link from "ui/link"
import classnames from "classnames"
import Song from "douradio/song"
import styles from "./channel.module.css"
// import ChannelModel from 'douradio/channel'

import PlaceHolder from 'components/place-holder'

export class Channel extends React.Component {

  static defaultProps = {
    className: 'channel'
    , coverSize: 84
    , coverRounded: false
  }

  componentDidMount() {
    douradio.on('switch_songlist switch_channel', function () {
      this.forceUpdate()
    }, this)
  }

  componentWillUnmount() {
    douradio.off(null, null, this)
  }

  isCurrent() {
    let currentPl = douradio.getCurrentPlaylist()
    , channelId = this.props.channel.id

    return currentPl && currentPl.type === 'channel' &&
      currentPl.id == channelId
  }

  onClick(e) {
    if(this.isCurrent()) {
      return
    }
    e.preventDefault()
    douradio.switchChannel(this.props.channel.id)
    this.props.onClick && this.props.onClick()
  }

  renderArtists(artists) {
    return artists.map((artist, index, list) => {
      let link = <Link key={'link-' + artist.id} id={artist.id} href={'artist/' + artist.id}>{artist.name}</Link>
      if(index == list.length - 1) {
        return link
      } else {
        return <span key={'span-' + artist.id}>{link}/</span>
      }
    })
  }

  channelLink() {
    let channel = this.props.channel
    if(channel.song_id) {
      // @todo use song object_id
      let song = channel.song
      return '/song/' + Song.getObjectId(song.id, song.ssid)
    } else if (channel.artist_id) {
      return '/artist/' + channel.artist_id
    }
  }

  render() {
    let channel = this.props.channel

    if(!channel) {
      return <li className={this.props.className}>
        <PlaceHolder
          width={this.props.coverSize}
          height={this.props.coverSize}
          style={{
            borderRadius: this.props.coverRounded ? '50%' : ''
            , marginTop: 40
          }}
        ></PlaceHolder>
        <div style={{marginTop: 20}}>
          <PlaceHolder
            width={108} height={14}
          ></PlaceHolder>
        </div>
      </li>
    }

    let cover = channel.cover
    , link = this.channelLink()
    , recReason

    if(channel.rec_reason) {
      recReason = <p className="subtitle">{channel.rec_reason}</p>
    } else if(channel.related_artists) {
      recReason = <p className="subtitle">
        包括的艺术家有 {this.renderArtists(channel.related_artists)} 等
      </p>
    }

    return <li
      className={this.props.className}
    >
      <Cover
        src={cover}
        isPlaying={this.isCurrent()}
        onPlay={this.onClick.bind(this)}
        size={this.props.coverSize}
        rounded={this.props.coverRounded}
      ></Cover>
      <div>
        {link ? <Link className="title" href={link}>{channel.name}</Link> : <a
          className='title'
          onClick={this.onClick.bind(this)}
          href={"#/channel/" + channel.id}>
          {channel.name}
        </a>}
        {recReason}
        {channel.artists ? <p className="subtitle">{this.renderArtists(channel.artists)}</p> : null}
      </div>
    </li>
  }

}

export class RoundedChannel extends Channel {
  static defaultProps = {
    className: 'channel channel-rounded'
    , coverSize: 108
    , coverRounded: true
  }
}

export class CollectedChannel extends Channel {
  static defaultProps = {
    className: 'channel channel-collected'
    , coverSize: 48
    , coverRounded: false
  }

  constructor(props) {
    super(props)
    this.channel = new douradio.Channel(
      this.props.channel, {douradio: douradio}
    )
  }

  toggleCollect(e) {
    e.preventDefault()
    this.channel.toggleCollect().then(() => {
      this.forceUpdate()
    })
  }

  _render({rounded, cover, title, subtitle, cat}) {
    let channel = this.props.channel

    return <li className={classnames(this.props.className, cat)}>
      {cover ? <Cover
        size={this.props.coverSize}
        src={cover}
        rounded={rounded}
        isPlaying={this.isCurrent()}
        onPlay={this.onClick.bind(this)}></Cover> : null}
      <div className="context">
        {title ? <a
          className='title'
          title={title}
          onClick={this.onClick.bind(this)}
          href={"#/channel/" + channel.id}>
          {title}
          <span className="mhz">MHz</span>
        </a> : null}
        <p className="subtitle">{subtitle || " "}</p>

        <a onClick={this.toggleCollect.bind(this)}
          className="action"
          href="">{this.channel.isCollect() ? '取消收藏' : '收藏'}</a>
      </div>
    </li>
  }

  render() {
    let channel = this.props.channel
    , cover = channel.cover
    , title = channel.name

    if(channel.intro.indexOf('以及相似的艺术家') >= 0) {
      // 艺术家兆赫
      return this._render({
        rounded: true
        , cover: cover
        , title: title
        , cat: 'artist'
      })
    } else if (channel.intro.indexOf('相似的歌曲') >= 0) {
      // 单曲兆赫
      return this._render({
        rounded: false
        , cover: cover
        , title: title
        , subtitle: channel.artist
        , cat: 'song'
      })
    } else if (channel.id < 1000) {
      // 公共兆赫
      return this._render({
        title: title
        , cover: cover
        , cat: 'public'
      })
    } else {
      // 其他
      return this._render({
        rounded: false
        , cover: cover
        , title: title
        , cat: 'other'
      })
    }
  }
}

export class TextChannel extends Channel {
  render() {
    let channel = this.props.channel

    if(!channel) {
      return <li className="channel channel-text">
        <a className={'title'} href="">
          <PlaceHolder
            width={108}
            height={14}
          ></PlaceHolder>
        </a>
      </li>
    }

    return <li
      style={this.props.style}
      className="channel channel-text"
      onClick={this.onClick.bind(this)}
    >
      <a href={"#/channel/" + channel.id} className="title">
        {channel.name}
        <span className="mhz">MHz</span>
      </a>
    </li>
  }
}

export class ChannelButton extends Channel {

  render() {
    let channel = this.props.channel

    return <button
      onClick={this.onClick.bind(this)}
      className="button button-primary button-play-channel">
      {this.isCurrent() ?
        <i className="icon-playing"></i>
        : <i className="icon-play"></i>
      }
      {channel.name}
      <small>MHz</small>
    </button>
  }

}

export class SpecialChannel extends Channel {

  static defaultProps = {
    hasPermission: true
  }

  openUserGuide(e) {
    e.preventDefault()
    douradio.canSwitchPlaylist('channel', 0)
  }

  render() {
    let channel = this.props.channel
    , cover = channel.cover
    , hasPermission = this.props.hasPermission

    return <li
      style={this.props.style}
      className={styles.channelSpecial}
    >
      <Cover
        src={cover}
        isPlaying={this.isCurrent()}
        onPlay={this.onClick.bind(this)}
        size={50}
        rounded={true}
        className={styles.specialCover}
      ></Cover>

      <a
        onClick={this.onClick.bind(this)}
        href={"/channel/" + channel.id}
        className={styles.title}
      >
        {channel.name}
      </a>

      <p className={styles.desc}>{channel.description}</p>

      {!hasPermission ? <div className={styles.noPermissionOverlay} style={{
      }}>
        <a href="" className={styles.buttonOpen} onClick={this.openUserGuide.bind(this)}>去开启</a>
      </div> : null}

    </li>
  }

}
