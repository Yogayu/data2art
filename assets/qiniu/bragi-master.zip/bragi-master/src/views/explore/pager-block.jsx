let React = require('react');

var PagerBlock = React.createClass({
  displayName: 'PagerBlock',

    componentDidMount: function () {
    let cacheTime = 10 * 60 * 1000; // 10 minutes

    this.request = request({
      url: this.props.url,
      data: {
        limit: this.props.limit
      }
    }, cacheTime).then((response) => {
      if(response.status){
        this.setState({
          channels: response.data.channels
        });
      }
    });
  },

  componentDidUpdate: function () {},

  getDefaultProps: function () {
    return {
      limit: 15,
      limitPerPage: 5,
      url: 'rec_channels?specific=track',
      renderChannel: null // pass a function(channel)
    };
  },

  getInitialState: function () {
    return {
      items: [],
      pageIndex: 0
    };
  },

  _switchPage: function (offset, event) {
    event.preventDefault();
    let pageLimit = this._getPageLimit();
    let toPageIndex = this.state.pageIndex + offset;
    if((toPageIndex + 1) > pageLimit) {
      toPageIndex = pageLimit - 1;
    } else if(toPageIndex < 0) {
      toPageIndex = 0;
    }
    this.setState({
      pageIndex: toPageIndex
    });
  },

  _getPageLimit: function () {
    return Math.ceil(this.props.limit / this.props.limitPerPage);
  },

  renderChannel: function (channel) {
    return <MHz
       onClick={douradio.switchChannel.bind(douradio, channel.id)}
       key={"channel" + channel.id} coverSrc={channel.banner || channel.cover}
    >
      <h5>{channel.name}<span className="mhz-identity">MHz</span></h5>
      <h6>{channel.intro}</h6>
    </MHz>;
  },

  render: function() {
    let itemStart = this.state.pageIndex * this.props.limitPerPage;
    let items = this.state.items.slice(
      itemStart, itemStart + this.props.limitPerPage
    );
    let isLastPage = (this.state.pageIndex + 1) === this._getPageLimit();

    return <div className="block">
      <h1>
        {this.props.title}

        <button className={"slider-control" + (isLastPage ? ' disable' : '')}
           onClick={this._switchPage.bind(this, 1)}>
          <i className="icon-angle-right"></i>
        </button>

        <button className={"slider-control" + (this.state.pageIndex === 0 ? ' disable' : '')}
           onClick={this._switchPage.bind(this, -1)}>
          <i className="icon-angle-left"></i>
        </button>

      </h1>
      <div className="items" style={{
        display: 'flex',
        flexWrap: 'nowrap',
        justifyContent: 'space-between',
        alignItems: 'stretch'
      }}>
        {items.map(this.props.renderItem || this.renderItem)}
      </div>
    </div>;
  }

});
