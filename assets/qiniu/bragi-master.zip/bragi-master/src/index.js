//
//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||// \
//                / _||||| -:- |||||- \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='
//
//
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
//               佛祖保佑         永无BUG
//
//
//

/**
 *  set __webpack_public_path__ as a free var in your `entry-point`
 *  @see http://webpack.github.io/docs/configuration.html#output-publicpath
 */
__webpack_public_path__ = window.__webpack_public_path__ || "/"; // eslint-disable-line

import "babel-polyfill"
import "utils/console-polyfill"

// promsie defer
import promiseDefer from "promise-defer"
import _Promise from "babel-runtime/core-js/promise"
_Promise.defer = function () {
  console.warn('defer called!')
  return promiseDefer()
}

let global = window

// import BragiApp from "./app"
// import defaults from "lodash/defaults"
import BragiApp from './app'

global.app = new BragiApp()
global.app.start()
