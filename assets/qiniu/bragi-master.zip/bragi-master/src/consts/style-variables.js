// this file containes custom variable for global css value

module.exports = {
  colorBlack: '#000'
}
