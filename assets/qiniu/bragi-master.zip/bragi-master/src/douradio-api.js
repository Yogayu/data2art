/**
 * api build for douradio
 */

import Douradio from "douradio/init"
import ApiClient from "douradio/apiclient.oauth"
import reqwest from "reqwest"
import domready from "domready"
import Backbone from "backbone"
import simpleStorage from "simplestorage"

const KEY_AUTHINFO = 'douradio-authinfo'

// always use flash to play audio, except Chrome and Safari.
// @todo authinfo only use for api based auth
let authinfo = simpleStorage.get(KEY_AUTHINFO) || {}

authinfo.icon = `http://img3.douban.com/icon/u${authinfo.douban_user_id}.jpg`

let apiClient = new ApiClient({
  ajax: reqwest
  , apikey: '0eef34cf917527f02ccd9e6eb45f77d0'
  , apisecret: '92cacfd72dca7885'
  , apiroot: '/v2/fm/'
  , authinfo: simpleStorage.get(KEY_AUTHINFO)
})

let d = new Douradio({
  domready: domready
  , Events: Backbone.Events
  , apiClient: apiClient
  , soundmanager: {
    url: '/node_modules/soundmanager2/swf/'
    , preferFlash: false
    , useHTML5Audio: true

    , debugFlash: false
    , debugMode: true
    , consoleOnly: true

    , flashVersion: 9
    , useHighPerformance: true
  }
  , autoplay: true,
})

d.on('logout', () => simpleStorage.flush())

d.on('token:update', (authinfo) => simpleStorage.set(KEY_AUTHINFO, authinfo))

window.dr = d

export default d
