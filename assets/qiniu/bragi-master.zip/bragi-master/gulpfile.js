var _ = require('lodash')
, gulp = require('gulp')
// var notify = require('gulp-notify');
, urllib = require('url')
, gutil = require('gulp-util')
, fs = require('fs')
, path = require('path')
, argv = require('yargs').argv

try {
  var localConfig = require('./local_config.json') || {}
} catch (e) {
  var localConfig = {}
}

var config = _.extend({
  'api_root': 'https://api.douban.com'
  , 'auth_url': 'https://www.douban.com'
  , 'host': 'localhost'
  , 'port': 8080
}, localConfig)

// webpack loader 2 gulp
var through = require('through2')

function webpackLoader(loaderName, options) {
  var loader, packageName = loaderName + '-loader'

  return through.obj(function (file, encoding, callback) {
    try {
      loader = require(packageName)
    } catch (e) {
      callback(new gutil.PluginError('WebpackLoaderPlugin', 'loader not found:' + packageName))
    }

    if (file.isNull()) {
      callback(null, file)
      return
    }

    if (file.isStream()) {
      callback(new gutil.PluginError('WebpackLoaderPlugin', 'Streaming not supported'))
    }

    var loaderContext = {
      cacheable() {}
    , addDependency() {}
    , async() {
        return function(err, result) {
          if (err){
            this.emit('error', new gutil.PluginError('WebpackLoaderPlugin', result))
            console.log(file, err)
          } else {
            file.contents = new Buffer(result)
            file.path = gutil.replaceExtension(file.path, '.jsx')
            callback(err, file)
          }
        }
      }
    }
    return loader.apply(loaderContext, [file.contents.toString()])
  })
}

function getLocalIpAddress() {
  var os = require('os')
  , interfaces = os.networkInterfaces()
  , intf = interfaces.en0 || interfaces.en1 || interfaces.WLAN

  for(var info of intf) {
    if(info.family === 'IPv4') {
      return info.address
    }
  }

  return '0.0.0.0'
}

gulp.task('dori', function (finish) {
  var http = require('http')
  , querystring = require('querystring')
  , ip = getLocalIpAddress()
  , postData = querystring.stringify({
    domain: 'fm'
    , ip: ip
  })
  , req = http.request({
    host: 'dori.intra.douban.com'
    , path: '/'
    , port: 5000
    , method: 'POST'
    , headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
      , 'Content-Length': postData.length
    }
  }, function (res){
    res.setEncoding('utf8')
    res.on('data', (chunk) => {
      console.log(`BODY: ${chunk}`)
    })
    res.on('end', () => {
      finish()
    })
  })

  req.write(postData)
  req.end()
})

gulp.task('jest', function () {
  var jest = require('gulp-jest')
  return gulp.src('src').pipe(jest({
    scriptPreProcessor: 'support/preprocessor.js'
    , rootDir: ''
    , unmockedModulePathPatterns: [
      'node_modules/react'
    ]
    , testDirectoryName: '__tests__'
    , testPathIgnorePatterns: [
      'node_modules'
      , ''
    ]
  }))
})

gulp.task('svg2react', function () {
  var iconName = argv.icon
  if(!iconName) {
    throw new gulp.PluginError('svg2react', 'iconName not defined')
  }

  gulp.src('./assets/icons/icon-' + iconName + '.svg')
    // .pipe(webpackLoader('svgo'))
    .pipe(webpackLoader('react-svg'))
    .pipe(gulp.dest('./src/icons'))
})

gulp.task('deploy', function (finishWebpack) {
  var webpack = require('webpack')
  , webpackConfig = require('./webpack.production.config')

  process.env["NODE_ENV"] = JSON.stringify("production")

  webpack(webpackConfig, function(err, stats) {
    gutil.log('[webpack:build:bragi]', stats.toString({
      colors: true
    }))
    if(err) throw new gutil.PluginError('webpack', err)
    finishWebpack()
  })
})

gulp.task('deploy-upgrade-bar', function (finishWebpack) {
  process.env["NODE_ENV"] = JSON.stringify("production")

  var webpack = require('webpack')
  , config = Object.assign({}, require('./webpack.production.config'), {
    entry: './src/pages/upgrade/index'
    , output: {
     path: __dirname + "/deploy"
    , filename: "upgrade.js"
    }
  })

  var compiler = webpack(config)

  compiler.run(function (err, stats) {
    gutil.log('[webpack:build:upgrade]', stats.toString({
      colors: true
    }))
    if(err) throw new gutil.PluginError('webpack', err)
    finishWebpack()
  })

})

gulp.task('oss', function (done) {
  var OSS = require('ali-oss')
  , client = new OSS.Wrapper({
    region: 'oss-cn-beijing'
  , bucket: 'bragi'
  , accessKeyId: 'LTAIK835vcbY7o7S'
  , accessKeySecret: '4U0po9BF5J8nmUttiFuGMXruvnjWNY'
  })
  , files = fs.readdirSync('./deploy')
  , promises = files.map(function (filename) {
    var filePath = path.join('./deploy', filename)
    , stats = fs.statSync(filePath)

    if(stats.isFile()) {
      return client
        .put('dev/' + filename, filePath)
        .then(function (r1) {
          console.log('put success:', r1)
        })
      // return Promise.resolve()
    } else {
      return Promise.resolve()
    }
  })

  Promise.all(promises).then(function () {
    done()
  })
})

gulp.task('default', function() {
  var webpack = require('webpack')
  , webpackConfig = (!! argv.debug) ? require(
    './webpack.debug.config'
  ) : require('./webpack.config')
  , WebpackDevServer = require('webpack-dev-server')

  if(argv.debug) {
    process.env["NODE_ENV"] = JSON.stringify("production")
  }

  var compiler = webpack(webpackConfig)

  var getProxyOptions = function (url) {
    parsedUrl = urllib.parse(url)
    return {
      target: parsedUrl.href
      , forward: parsedUrl.href
      , headers: {
        host: parsedUrl.host
      }
    }
  }

  var server = new WebpackDevServer(compiler, {
    contentBase: './'
    , headers: { 'Access-Control-Allow-Origin': '*' }
    , hot: true
    , proxy: {
      "/j/*": getProxyOptions('http://douban.fm/')
      , "/v2/*": getProxyOptions(config.api_root)
      , "/service/*": getProxyOptions(config.auth_url)
    }
    , historyApiFallback: true

    // dev middleware options
    , stats: { color: true }
  })

  server.listen(config.port, config.host, function (err, result) {
    if(err) console.log(err)
    console.log('Listening at ', config.host + ':' + config.port)
  })

})
