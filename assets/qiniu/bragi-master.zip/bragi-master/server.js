'use strict'
// const port = 80

var path = require('path')
var express = require('express')
var webpack = require('webpack')

var argv = require('yargs').argv

var webpackConfig = (!! argv.debug) ? require(
  './webpack.debug.config'
) : require('./webpack.config')

if(argv.debug) {
  process.env["NODE_ENV"] = JSON.stringify("production")
}

var configs

try {
  configs = require('./local_config.json')
} catch(e) {
  configs = require('./local_config.json.example')
}

var app = express()
var compiler = webpack(webpackConfig)
// var url = require('url')

if(argv.debug) {
  app.use(function (req, res, next) {
    console.log('%d %s %s', Date.now(), req.method, req.url)
    next()
  })
}

var cookieParser = require('cookie-parser')
app.use(cookieParser())

// begin proxy config
var httpProxy = require('http-proxy')
, proxyServer = httpProxy.createProxyServer({
  target: configs.fm_url || 'https://douban.fm'
  , host: 'douban.fm'
  , autoRewrite: true
  , changeOrigin: true
})

proxyServer.on('proxyReq', function (proxyReq, req, res, options) {
  proxyReq.setHeader('Referer', 'https://douban.fm/')
  // proxyReq.setHeader('set-cookie')
})

proxyServer.on('proxyRes', function (proxyRes, req, res) {
  let cookies = proxyRes.headers['set-cookie']
  if(cookies) {
    let newCookies = cookies.map((cookie) => {
      let nc = cookie.replace('douban.fm', 'douban.com')
      // if(nc != cookie) {console.log(nc)}
      return nc
    })

    proxyRes.headers['set-cookie'] = newCookies
  }
})

proxyServer.on('error', function (e, req, res) {
  res.writeHead(500, {
    'Content-Type': 'application/json'
  })
  res.end(JSON.stringify({
    type: 'error'
    , reason: 'proxy error'
  }))
})

app.all('/j/*', function (req, res) {
  proxyServer.web(req, res)
})
// end proxy config

app.use(require('webpack-dev-middleware')(compiler, {
  noInfo: true
  , publicPath: "http://fm.me.douban.com/"
  , stats: {
    colors: true
  }
}))

app.use(require('webpack-hot-middleware')(compiler))

app.get('/dev', function (req, res) {
  res.sendFile(path.join(__dirname, 'dev.html'))
})

app.use('/assets', express.static('assets'))
app.use('/node_modules', express.static('node_modules'))

app.get('*', function(req, res) {
  // hack for douban.fm
  if(!req.cookies.flag) {
    let nof = function (s) { return s }
    res.cookie('flag', '"ok"', {
      encode: nof
    })
    res.cookie('ac', '"1467865420"', {
      encode: nof
    })
  }

  res.set('Access-Control-Allow-Origin', '*')

  // console.log('user-agent', req.headers['user-agent'])

  res.sendFile(path.join(__dirname, 'index.html'))
})

// start http(s) server
var https = require('https')
, http = require('http')
, fs = require('fs')

if(configs.https_port) {
  https.createServer({
    key: fs.readFileSync('./server/certificate/files/web/fm.me.douban.com.key')
    , cert: fs.readFileSync('./server/certificate/files/web/fm.me.douban.com.cer')
  }, app).listen(configs.https_port)
}

http.createServer(app).listen(configs.port)
