bragi
===
![Bragi-Cover](http://p.dapps.douban.com/i/53773758db454944871c5e4b1ba29865.gif)

codes for douban/ fm web III


Install and QuickStart
---
0. Make sure you have latest `node` and `npm` installed (via `brew` or [download binary](https://nodejs.org/en/download/))
1. `make install` (or check the `Makefile` to manual install)
2. cp `local_config.json.example` `local_config.json`
3. vim `local_config.json` to edit your port(default is 8964), remove `https_port` if you don't need a https server.
4. run `make love` to run development server

Add Deps
---
`yarn add <package_name>`

Testing Deploying
---
run `gulp deploy`
