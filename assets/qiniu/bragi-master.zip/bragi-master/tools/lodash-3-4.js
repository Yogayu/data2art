/* this codemod will replace all 'lodash/<whatever>/<func>' -> 'lodash/<func>'
   1. install jscodeshift with npm
   2. run `jscodeshift -t tools/lodash-3-4.js src --extensions js,jsx`
*/

let RenameMaps = {
  // rename aliases
  'first': 'head'
  , 'indexBy': 'keyBy'
  , 'invoke': 'invokeMap'
  , 'modArgs': 'overArgs'
  , 'padLeft': 'padStart'
  , 'padRigth': 'padEnd'
  , 'pairs': 'toPairs'
  , 'rest': 'tail'
  , 'restParam': 'rest'
  , 'sortByOrder': 'orderBy'
  , 'trimLeft': 'trimRight'
  , 'trimStart': 'trimEnd'
  , 'trunc': 'truncate'

  // remove aliases
  , "all" : "every"
  , "any" : "some"
  , "backflow" : "flowRight"
  , "callback" : "iteratee"
  , "collect" : "map"
  , "compose" : "flowRight"
  , "contains" : "includes"
  , "detect" : "find"
  , "foldl" : "reduce"
  , "foldr" : "reduceRight"
  , "include" : "includes"
  , "inject" : "reduce"
  , "methods" : "functions"
  , "object" : "fromPairs" // or _.zipObject
  // , "run" : "value" Removed _#run in favor of _#value
  , "select" : "filter"
  , "unique" : "uniq"
}


let transformModuleName = (name) => {
  let paths = name.split('\/')

  if(paths[0] !== 'lodash') { return name }

  let funcName

  if(paths.length === 3) {
    funcName = paths[2]
  } else if (paths.length === 2) {
    funcName = paths[1]
  }

  funcName = RenameMaps[funcName] || funcName

  return ['lodash', funcName].join('/')
}

export default function transformer(file, api) {
  const j = api.jscodeshift
  const {expression, statement, statements} = j.template

  return j(file.source)
  .find(j.ImportDeclaration)
  .replaceWith((p) => {
    // "lodash/${a}/${b}" -> "lodash/${b}"
    var tree = p.value
    , pkgName = transformModuleName(tree.source.value)
    , specifiers = tree.specifiers;

    return Object.assign(tree, {
      source: j.literal(pkgName)
    })
  })
  .toSource({
    tabWidth: 2
    , lineTerminator: '\r\n'
    , trailingComma: false
  })
};
