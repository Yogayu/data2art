var config = require('./webpack.config')
, webpack = require('webpack')
, path = require('path')

config.debug = false
config.entry = {
  'bragi': './src/index',
  //'redeem_mobile': './src/pages/redeem',
  //'redeem_gap': './src/pages/redeem/gap',
  // 'redeem_gap_mobile': './src/pages/redeem/gap.mobile'
}

config.output = {
  path: __dirname + "/deploy/",
  filename: "[name].js",
  chunkFilename: "[id]-bragi.js",
  sourceMapFilename: "[id]-bragi.js.map",
  // publicPath: "window.__webpack_public_path__"
}

// pop the hot-replace-plugin, make sure this plugin is in the last position
config.plugins.pop()

config.plugins.push(
  new webpack.DefinePlugin({
    // This has effect on the react lib size.
    "process.env": {
      "NODE_ENV": JSON.stringify("production")
    }
  })
)

config.plugins.push(new webpack.optimize.DedupePlugin())
config.plugins.push(new webpack.optimize.UglifyJsPlugin({}))

// config.resolve.alias['soundmanager'] = path.join(
//   __dirname, 'node_modules/soundmanager2/script/soundmanager2-nodebug.js'
// )

config.resolve.alias['douradio$'] = "douradio.js"
config.devtool = "source-map"

module.exports = config
