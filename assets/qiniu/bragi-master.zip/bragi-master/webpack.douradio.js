var commonConfigs = require('./webpack.config');

module.exports = {

  debug: false,

  entry: './src/douradio/xbox.coffee',

  output: {
    path: __dirname + '/../DoubanFM_XboxoneApp/DouFM/js/',
    library: 'douradio',
    libraryTarget: 'umd',
    filename: 'douradio.js'
  },

  module: commonConfigs.module,

  resolve: {
    root: commonConfigs.resolve.root,
    extensions: commonConfigs.resolve.extensions
  },
  externals: {
    'jquery': 'window'
  }

}
