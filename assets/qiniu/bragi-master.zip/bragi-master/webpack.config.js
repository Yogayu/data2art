var webpack = require('webpack')
, _ = require('lodash')
, path = require('path')
// , combineLoaders = require('webpack-combine-loaders')

// @todo
// const publicPath = 'http://fm.me.douban.com/'

var buildSrc = function (app) {
  // return app

  var devConfig = [
    'webpack-hot-middleware/client'
  ]

  if(_.isArray(app)) {
    devConfig.concat(app)
  } else {
    devConfig.push(app)
  }
  return devConfig
}

module.exports = {
  // devtool: 'source-map',
  devtool: 'eval'
  , debug: true

  , entry: {
    'bragi': buildSrc('./src/index')
    , 'upgrade': './src/pages/upgrade/index'
    // ,
    // 'dev': buildSrc('./src/dev')
    // , 'service': buildSrc('./src/service')
    // , 'test': 'mocha!./src/douradio/audio/test.js'
    // 'shim': ['./src/shim'],
    // 'widget': buildSrc('./src/widget-player'),
    // 'gap': buildSrc('./src/pages/redeem/gap'),
    // 'gap.mobile': buildSrc('./src/pages/redeem/gap.mobile'),
    // 'redeem': buildSrc('./src/pages/redeem')
  }

  , output: {
    path: path.join(__dirname, '/devapp/js/')
    , filename: '[name].js'
    , publicPath: 'http://fm.me.douban.com/'
    , chunkFilename: '[id].bragi.js'
  }
  , module: {
    loaders: [{
      test: /\.(js|jsx)$/
      , exclude: /(node_modules|bower_components)/
      , loader: 'babel'
    }, {
      test: /\qrcode\.js\/qrcode\.js$/
      , loader: 'exports?QRCode'
    }, {
      test: /\.module\.(scss|css)$/
      , loaders: [
        'style-loader', 'css-loader?module', 'postcss-loader'
        , 'sass-loader'
      ]
    }, {
      test: /\.(scss|css)$/
      , exclude: /\.module\.(scss|css)$/
      , loader: 'style-loader!css-loader!autoprefixer-loader!sass-loader' +
            '?includePaths[]=' + __dirname + '/src/scss' +
            '&includePaths[]=' + __dirname + '/node_modules/bourbon/app/assets/stylesheets/' +
            '&includePaths[]=' + __dirname + '/node_modules/bourbon-neat/app/assets/stylesheets/'
    }, {
      test: /\.(svg)$/
      , loader: 'svg-url?limit=1024'
    }]
  }

  , resolve: {
    alias: {
      'underscore': path.join(__dirname, 'src/underscore.js')
      , 'gsap': path.join(__dirname, 'node_modules/gsap/src/uncompressed')
      , 'TweenLite': path.join(__dirname, 'node_modules/gsap/src/uncompressed/TweenLite.js')
      , 'simplestorage': path.join(__dirname, 'node_modules/simplestorage.js/simpleStorage.js')
      , 'soundmanager': path.join(__dirname, 'node_modules/soundmanager2/script/soundmanager2.js')
      // 'soundmanager': path.join(__dirname, 'node_modules/soundmanager2/script/soundmanager2-nodebug.js'),
      , 'assets': path.join(__dirname, 'assets')
      // only in debug mode
      // , 'douradio$': 'douradio-api.js'
    }
    , root: [
      path.join(__dirname, 'src')
    ]
    , extensions: ["", ".js", ".jsx"]
  }

  , externals: {
    'jquery': 'window'
  }

, postcss: function () {
    return [
      require('postcss-cssnext')({
        features: {
          customProperties: {
            variables: require('./src/consts/style-variables')
          }
        }
      })
    ]
  }

  , plugins: [
    // new ExtractTextPlugin("[name].css"),
    new webpack.NoErrorsPlugin()
    // , new webpack.ProvidePlugin({'Promise': 'shim/promise'})
    // keep this the last one
    , new webpack.HotModuleReplacementPlugin()
  ]
}
