// the debug config is only used in production-like environment

var config = require('./webpack.production.config')

console.log('[Loading the debug config...]')

config.debug = true
// config.devtool = 'source-map'
config.devtool = 'eval'

//config.entry = {
//  'bragi': './src/dev'
//}

config.output = {
  path: __dirname + '/debug/'
  , filename: '[name].js'
  , chunkFilename: '[id].bragi.js'
  , sourceMapFilename: "[id].bragi.js.map"
  , publicPath: '/'
}

// pop UglifyJsPlugin
config.plugins.pop()

module.exports = config
