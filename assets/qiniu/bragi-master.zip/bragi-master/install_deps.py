#!/bin/env python
import hashlib
from subprocess import call
import os
import zipfile
import tempfile

PACKS_DIR = tempfile.gettempdir() + '/staticng_packs/'
YARN_COMMAND = './bin/node_modules/.bin/yarn'

# _env = os.environ.copy()
# _env['PATH'] = './bin/node_modules/.bin:' + _env['PATH']


def hash_file(filename):
    hasher = hashlib.md5()

    with open(filename, 'rb') as lock_file:
        buf = lock_file.read()
        hasher.update(buf)

    return hasher.hexdigest()


def pack_file(filename):
    # yarn pack --filename <filename>
    print "PACKING to:", filename
    # return call([YARN_COMMAND, 'pack', '--filename', filename])
    # it yarn pack is not stable, so do it myself
    if not os.path.exists(PACKS_DIR):
        os.makedirs(PACKS_DIR)

    zipf = zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED)

    for root, dirs, files in os.walk('./node_modules'):
        for file in files:
            zipf.write(os.path.join(root, file))

    zipf.close()


def unpack_file(filename):
    print "found cache, unzip it:", filename
    zip_ref = zipfile.ZipFile(filename, 'r')
    zip_ref.extractall('./')
    zip_ref.close()


def install_deps():
    if not os.path.exists(YARN_COMMAND):
        call(['npm', 'install', '--prefix',  './bin', 'yarn'])
    call([YARN_COMMAND, 'install'])


def main():
    filename = PACKS_DIR + hash_file('yarn.lock') + '.gz'

    if os.path.exists(filename):
        unpack_file(filename)
    else:
        install_deps()
        pack_file(filename)

if __name__ == '__main__':
    install_deps()
