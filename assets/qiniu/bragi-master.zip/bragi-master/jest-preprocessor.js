var coffee = require('coffee-script');
// @todo for now, test is only support in coffee-script and pure-javascript
// cjsx, jsx are not support here, keep it simple.

module.exports = {
  process: function (src, path) {
    if(coffee.helpers.isCoffee(path)) {
      return coffee.compile(src, {'bare': true})
    }
    return src;
  }
};
